#!/bin/sh
BLACK='\e[0;30m'
BLUE='\e[0;34m'
GREEN='\e[0;32m'
CYAN='\e[0;36m'
RED='\e[0;31m'
PURPLE='\e[0;35m'
BROWN='\e[0;33m'
LIGHTGRAY='\e[0;37m'
DARKGRAY='\e[1;30m'
LIGHTBLUE='\e[1;34m'
LIGHTGREEN='\e[1;32m'
LIGHTCYAN='\e[1;36m'
LIGHTRED='\e[1;31m'
LIGHTPURPLE='\e[1;35m'
YELLOW='\e[1;33m'
ULG='\e[4;1;32m'
WHITE='\e[1;37m'
NC='\e[0m'
echo -n -e "${WHITE}Booting Up GCB Menu.. \r"
sleep 1.5
echo -n -e "${WHITE}Loading Menu [${GREEN}##                       ${WHITE}(8%)\r"
sleep 1
echo -n -e "${WHITE}Loading Menu [${GREEN}########                 ${WHITE}(38%)\r"
sleep 1
echo -n -e "${WHITE}Loading Menu [${GREEN}##########               ${WHITE}(49%)\r"
sleep 1
echo -n -e "${WHITE}Loading Menu [${GREEN}################         ${WHITE}(80%)\r"
sleep 1
echo -n -e "${WHITE}Loading Menu [${GREEN}#######################${WHITE}] (100%) Finished"
sleep 2
#
tput clear
trap ctrl_c INT

function ctrl_c() {
        echo "**You pressed Ctrl+C...Exiting"
        exit 0;
}
show_menu(){

normal=`echo "\033[m"`
menu=`echo "\033[36m"` #Blue
number=`echo "\033[33m"` #yellow
bgred=`echo "\033[41m"`
fgred=`echo "\033[31m"`
	
echo -e "#########################################################################"
echo -e "#########################################################################"
echo "                                                                          ## ";
echo "            _____ _               _       _____  _____ ____               ## ";
echo "           / ____| |             | |     / ____|/ ____|  _ \              ## ";
echo "          | |    | |__   ___  ___| | __ | |  __| |    | |_) |             ## ";
echo "          | |    | '_ \ / _ \/ __| |/ / | | |_ | |    |  _ <              ## ";
echo "          | |____| | | |  __/ (__|   <  | |__| | |____| |_) |             ## ";
echo "           \_____|_| |_|\___|\___|_|\_\  \_____|\_____|____/  ...         ## ";
echo "                                                                          ## ";
echo "v3.2.0 for Red Hat Enterprise Linux 9.4 NTP & YUM                         ## ";
echo "by CHT Dong Alan 2024/12/08                                               ## ";
echo "############################################################################"
echo "Script for your GCB Check installation"
echo "############################################################################"
echo
echo "This script will collect and analyze info about GCB."
echo "It can help you harden your security, and check if your GCB configuration"
echo "is correct. It is designed for a Alan installation, but can be used"
echo "on other setups, for security checks only."
echo 
echo "GCB for Red Hat Enterprise Linux"
echo "(重要!! (0)可在新RedHat 8.10 & 9.4環境使用 (1)請先確認YUM服務正常 (2)1-14項目請勿執行2次 (3)請先快照備份VM)"
printf "${menu}**${number} 1)${menu} TWGCB-01-012-0001~0031 ${normal} ${menu}**${number} 8)${menu}  TWGCB-01-012-0132~0184 ${normal}\n"
printf "${menu}**${number} 2)${menu} TWGCB-01-012-0032~0091 ${normal} ${menu}**${number} 9)${menu}  TWGCB-01-012-0185~0191 ${normal}\n"
printf "${menu}**${number} 3)${menu} TWGCB-01-012-0092~0101 ${normal} ${menu}**${number} 10)${menu} TWGCB-01-012-0192~0207 ${normal}\n"
printf "${menu}**${number} 4)${menu} TWGCB-01-012-0102~0107 ${normal} ${menu}**${number} 11)${menu} TWGCB-01-012-0208~0243 ${normal}\n"
printf "${menu}**${number} 5)${menu} TWGCB-01-012-0108~0131 ${normal} ${menu}**${number} 12)${menu} TWGCB-01-012-0171~0171 ${normal}\n"
printf "${menu}**${number} 6)${menu} TWGCB-01-012-0145~0145 ${normal} ${menu}**${number} 13)${menu} TWGCB-01-012-0037~0037 ${normal}\n"
printf "${menu}**${number} 7)${menu} TWGCB-01-012-0244~0248 ${normal} ${menu}**${number} 14)${menu} TWGCB-01-012-0249~0292 ${normal}\n"
printf "${menu}**${number} 15)${menu} TWGCB-04-007-0001~0066 Setup Red Hat Enterprise Linux 9.4 + Apache HTTP Server 2.4 GCB(2024/12/08)\n"
printf "${menu}**${number} 88)${menu} GCB Check for Red Hat Enterprise Linux 9.4 + Apache HTTP Server 2.4 (2024/12/08)\n"
printf "${menu}**${number} 99)${menu} GCB Check for Red Hat Enterprise Linux 9.4 (2024/12/01)\n"
printf "${menu}**${number} 77)${menu} GCB Check for Red Hat Enterprise Linux 8.10 (2024/12/08)\n"
echo "############################################################################"
echo
printf "Please enter a menu option and enter or ${fgred}x to exit.? ${normal}"

    read opt
}

option_picked(){
    msgcolor=`echo "\033[01;31m"` # bold red
    normal=`echo "\033[00;00m"` # normal white
    message=${@:-"${normal}Error: No message passed"}
    printf "${msgcolor}${message}${normal}\n"
}

clear
show_menu
while [ $opt != '' ]
    do
    if [ $opt = '' ]; then
      exit;
    else
      case $opt in
        1) clear;
            option_picked "Option 1 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo
			#TWGCB-01-008-0001~0003
[ -f /etc/modprobe.d/cramfs.conf ] || echo -e 'install cramfs /bin/true\nblacklist cramfs' >> /etc/modprobe.d/cramfs.conf && rmmod cramfs
[ -f /etc/modprobe.d/squashfs.conf ] || echo -e 'install squashfs /bin/true\nblacklist squashfs' >> /etc/modprobe.d/squashfs.conf && rmmod squashfs
[ -f /etc/modprobe.d/udf.conf ] || echo -e 'install udf /bin/true\nblacklist udf' >> /etc/modprobe.d/udf.conf  && rmmod udf

#TWGCB-01-008-0004~7
#mkdir -p /etc/systemd/system/local-fs.target.wants
#[ -f /etc/systemd/system/local-fs.target.wants/tmp.mount ] || echo -e '[Mount]\nWhat=tmpfs\nWhere=/tmp\nType=tmpfs\nOptions=mode=1777,strictatime,noexec,nodev,nosuid\n' >> /etc/systemd/system/local-fs.target.wants/tmp.mount
#systemctl unmask tmp.mount
#systemctl enable tmp.mount
#mount -o remount,nosuid /tmp
#manual todo
##vim /etc/fstab
#/tmp的掛載設定範例如下：
#tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0


#TWGCB-01-008-0010~12
#/var/tmp無獨立磁碟空間
#grep -iw "/var/tmp                   xfs     defaults,nodev" /etc/fstab ||  sed -i "/\/var\/tmp/s/defaults/defaults,nodev,nosuid,noexec/" /etc/fstab

#TWGCB-01-008-0016, 23,24,25
grep -iw "/home                   xfs     defaults,nodev,nosuid,noexec" /etc/fstab ||  sed -i "/\/home/s/defaults/defaults,nodev/" /etc/fstab

#TWGCB-01-008-0017~19
sed -i '/\/shm/s/^tmpfs/#tmpfs/' /etc/fstab && echo -e 'tmpfs /dev/shm tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0' >> /etc/fstab && mount -a && mount -o remount /dev/shm

#TWGCB-01-008-0029
df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null | xargs -I '{}' chmod o+t '{}'

#TWGCB-01-008-0030
systemctl --now disable autofs

#TWGCB-01-008-0031
[ -f /etc/modprobe.d/usb-storage.conf ] || echo -e 'install usb-storage /bin/true\nblacklist usb-storage' >> /etc/modprobe.d/usb-storage.conf && rmmod usb-storage

echo '##TWGCB-01-008-0001~0003 check' >> 1-1.log
echo 'cat /etc/modprobe.d/cramfs.conf' >> 1-1.log
cat /etc/modprobe.d/cramfs.conf >> 1-1.log
echo "">> 1-1.log 
echo 'cat /etc/modprobe.d/squashfs.conf' >> 1-1.log
cat /etc/modprobe.d/squashfs.conf >> 1-1.log
echo "">> 1-1.log
echo 'cat /etc/modprobe.d/udf.conf' >> 1-1.log
cat /etc/modprobe.d/udf.conf >> 1-1.log
echo "">> 1-1.log
echo 'cat /etc/modprobe.d/usb-storage.conf' >> 1-1.log
cat /etc/modprobe.d/usb-storage.conf >> 1-1.log
echo "">> 1-1.log
echo '##TWGCB-01-008-0004~0007 check' >> 1-1.log
echo 'cat /etc/systemd/system/local-fs.target.wants/tmp.mount' >> 1-1.log
cat /etc/systemd/system/local-fs.target.wants/tmp.mount >> 1-1.log
echo "">> 1-1.log
echo '##TWGCB-01-008-0004~0007，0010~0012，0016~0019，0023-25 check' >> 1-1.log
echo 'cat /etc/fstab|grep 'var\|home\|swap\|shm'' >> 1-1.log
cat /etc/fstab|grep 'var\|home\|swap\|shm\|tmp'  >> 1-1.log

echo '##TWGCB-01-008-0029 check' >> 1-1.log 
echo 'systemctl --now disable autofs' >> 1-1.log

#####################alan###########
dnf install -y aide	audit-libs
aide --init 
mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz
		
######################################################################################################

sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
###################################################################################################### 
 
 
 
 
 
           show_menu;
        ;;
        88) clear;
            option_picked "Option 88 Picked";

######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 88. GCB Check for Apache HTTP Server 2.4 (2024/12/08)/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo




echo "ing...."





######################################################################################################

sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
###################################################################################################### 


            show_menu;
        ;;
        2) clear;
            option_picked "Option 2 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo
			
#TWGCB-01-008-0032
sed -i '/gpgcheck/s/0/1/' /etc/yum.conf
sed -i '/gpgcheck/s/0/1/' /etc/yum.repos.d/*.repo

#TWGCB-01-008-0033
dnf install sudo

#TWGCB-01-008-0034~35
sed -i '/use_pty/s/^Defaults/#Defaults/' /etc/sudoers && sed -i '$a\Defaults     use_pty' /etc/sudoers
sed -i '/logfile/s/^Defaults/#Defaults/' /etc/sudoers&& sed -i '$a\Defaults     logfile="/var/log/sudo.log"' /etc/sudoers

#TWGCB-01-008-0037

#
echo '定義全局變數或全局目標檔案路徑' &> /dev/null
backup_dir="/root/scripts/gcb/1_Basic_Disks-and-FileSystems_v1.2/backup/TWGCB-01-008-0027/$(date +"%Y%m%d")"
FILE=/etc/fstab


echo '創建備份目錄' &> /dev/null
if [ ! -d "$backup_dir" ]; then
	mkdir -p "$backup_dir"
fi


echo '檢查' &> /dev/null
# 遍历提取的行
nfs_lines=$(awk '$3=="nfs"' "$FILE")
missing_nosuid=0

while IFS= read -r line; do
	if [ -n "$line" ]; then
		if ! echo "$line" | grep -q '\bnosuid\b'; then
			((missing_nosuid++))
		fi
	fi
done <<< "$nfs_lines"

if [ "$missing_nosuid" -eq 0 ]; then
	echo "TWGCB-01-008-0027 OK (沒有設定改變)"
	echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0027：沒有設定改變。" >> "$backup_dir"/gcb.log
	echo -e " 結果：TWGCB-01-008-0027 OK\n" >> "$backup_dir"/gcb.log
	exit 0
fi


echo '備份檔案函數' &> /dev/null
backup_file() {
	local file="$1"
	cp -i "$file" "$backup_dir/$(basename $file).$(date +%Y-%m-%d-%H%M%S)"
}


echo '備份目標檔案' &> /dev/null
if [ -f "$FILE" ]; then
	backup_file $FILE &> /dev/null
	echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0004：\n - 備份$FILE檔案於$backup_dir目錄。" >> "$backup_dir"/gcb.log
fi


echo '設定' &> /dev/null
while IFS= read -r line; do
	if ! echo "$line" | grep -q '\bnosuid\b'; then
		modified_line=$(echo "$line" | awk '{ $4 = $4 ",nosuid"; print }')
		sed -ri "s#$line#$modified_line#" /etc/fstab
		mount -o remount,nosuid $(awk '$3=="nfs"' "$FILE"|awk '{print $2}')
		echo -e " - 在$FILE檔案設定$modified_line。" >> "$backup_dir"/gcb.log
	fi
done <<< "$nfs_lines"


echo '設定後檢查' &> /dev/null
# 遍历提取的行
nfs_lines=$(awk '$3=="nfs"' "$FILE")
missing_nosuid=0

while IFS= read -r line; do
	if [ -n "$line" ]; then
		if ! echo "$line" | grep -q '\bnosuid\b'; then
			((missing_nosuid++))
		fi
	fi
done <<< "$nfs_lines"

if [ "$missing_nosuid" -eq 0 ]; then
	echo "TWGCB-01-008-0027 OK (設定成功)"
	echo -e " 結果：TWGCB-01-008-0027 OK (設定成功)\n" >> "$backup_dir"/gcb.log
	exit 0
else
	echo -e "\x1b[31;1mTWGCB-01-008-0027 FAIL (設定失敗)\x1b[0m"
	echo -e " \x1b[31;1m結果：TWGCB-01-008-0027 FAIL (設定失敗)\x1b[0m\n" >> "$backup_dir"/gcb.log
	exit 1
fi


#TWGCB-01-008-0038~39
chown root:root /boot/grub2/grub.cfg
chown root:root /boot/grub2/grubenv
chmod 600 /boot/grub2/grub.cfg
chmod 600 /boot/grub2/grubenv

#TWGCB-01-008-0040 -- 暫不套用避免開機問題
#printf '%s\n' "P@ssw0rd" "P@ssw0rd" | script -qf -c 'grub2-setpassword' /dev/null
#grub2-mkconfig -o /boot/grub2/grub.cfg

#TWGCB-01-008-0041 -- 暫不套用避免開機問題
#sed -i '/ExecStart=/s/rescue/emergency/' /usr/lib/systemd/system/rescue.service

#TWGCB-01-008-0042 
sed -i '/hard    core/s/^*/#*/' /etc/security/limits.conf && sed -i '$a\*               hard    core            0' /etc/security/limits.conf
sed -i '/fs\.suid_dumpable/s/^fs\.suid_dumpable/#fs\.suid_dumpable/' /etc/sysctl.conf && sed -i '$a\fs\.suid_dumpable=0' /etc/sysctl.conf
sysctl -w fs.suid_dumpable=0
sed -i '/Storage=none/s/^Storage/#Storage/' /etc/systemd/coredump.conf && sed -i '$a\Storage=none' /etc/systemd/coredump.conf
sed -i '/ProcessSizeMax=0/s/^ProcessSizeMax/#ProcessSizeMax/' /etc/systemd/coredump.conf && sed -i '$a\ProcessSizeMax=0' /etc/systemd/coredump.conf
systemctl daemon-reload

#TWGCB-01-008-0043 
sed -i '/kernel\.randomize_va_space=2/s/^kernel\.randomize_va_space=2/#kernel\.randomize_va_space=2/' /etc/sysctl.conf && sed -i '$a\kernel\.randomize_va_space=2' /etc/sysctl.conf
sysctl -w kernel.randomize_va_space=2

#TWGCB-01-008-0044
update-crypto-policies --set FUTURE
update-crypto-policies

#TWGCB-01-008-0045~60
chown root:root /etc/passwd
chmod 644 /etc/passwd
chown root:root /etc/shadow
chmod 000 /etc/shadow
chown root:root /etc/group
chmod 644 /etc/group
chown root:root /etc/gshadow
chmod 000 /etc/gshadow
chown root:root /etc/passwd-
chmod 600 /etc/passwd-
chown root:root /etc/shadow-
chmod 000 /etc/shadow-
chown root:root /etc/group-
chmod 644 /etc/group-
chown root:root /etc/gshadow-
chmod 000 /etc/gshadow-

#TWGCB-01-008-0074
chmod o-w /usr/local/sbin
chmod g-w /usr/local/sbin
chmod o-w /usr/local/bin
chmod g-w /usr/local/bin
chmod o-w /usr/sbin
chmod g-w /usr/sbin
chmod o-w /usr/bin
chmod g-w /usr/bin
chmod o-w /root/bin
chmod g-w /root/bin

#TWGCB-01-008-0083~84 
userline=($(awk -F":" '{if($3>=1000 && $3<=10000){print $1}}' /etc/passwd)) ; usernumber=`awk -F":" '{if($3>=1000 && $3<=10000){print $1}}' /etc/passwd | wc -l` ; for (( a=0;a<$usernumber;a++ )) ; do rm -rf /home/${userline[$a]}/.forward ; rm -rf /home/${userline[$a]}/.netrc ; rm -rf /home/${userline[$a]}/.rhosts ; done

echo "" > 1-2.log
echo '##TWGCB-01-008-0032 check' >> 1-2.log
echo 'cat /etc/yum.conf|grep gpgcheck' >> 1-2.log
cat /etc/yum.conf|grep gpgcheck >> 1-2.log
echo "" >> 1-2.log
echo 'cat /etc/yum.repos.d/*|grep gpgcheck' >> 1-2.log
cat /etc/yum.repos.d/*|grep gpgcheck  >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0033 check' >> 1-2.log
echo 'rpm -qa|grep sudo' >> 1-2.log
rpm -qa|grep sudo >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0034~0035 check' >> 1-2.log
echo 'cat /etc/sudoers|grep 'pty\|logfile'' >> 1-2.log
cat /etc/sudoers|grep 'pty\|logfile' >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0038~0039 check' >> 1-2.log
echo 'ls -l /boot/grub2/*' >> 1-2.log
ls -l /boot/grub2/* >> 1-2.log
echo "" >> 1-2.log
echo 'ls -l /boot/efi/EFI/redhat/grubenv' >> 1-2.log
ls -l /boot/efi/EFI/redhat/grubenv >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0041 check' >> 1-2.log
echo 'cat /usr/lib/systemd/system/rescue.service|grep sulogin-shell' >> 1-2.log
cat /usr/lib/systemd/system/rescue.service|grep sulogin-shell >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0042~0043 check' >> 1-2.log
echo 'cat /etc/security/limits.conf|grep hard|grep core' >> 1-2.log
cat /etc/security/limits.conf|grep hard|grep core >> 1-2.log
echo "" >> 1-2.log
echo 'cat /etc/sysctl.conf|grep 'suid\|randomize'' >> 1-2.log
cat /etc/sysctl.conf|grep 'suid\|randomize' >> 1-2.log
echo "" >> 1-2.log
echo 'cat /etc/systemd/coredump.conf|grep 'Storage\|ProcessSizeMax'' >> 1-2.log
cat /etc/systemd/coredump.conf|grep 'Storage\|ProcessSizeMax' >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0044 check' >> 1-2.log
echo "grep -E -i '^\s*(FUTURE|FIPS)\s*(\s+#.*)?$' /etc/crypto-policies/config" >> 1-2.log
grep -E -i '^\s*(FUTURE|FIPS)\s*(\s+#.*)?$' /etc/crypto-policies/config >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0045~0060 check' >> 1-2.log
echo 'ls -l /etc/|grep 'passwd\|group\|shadow'' >> 1-2.log
ls -l  /etc/|grep 'passwd\|group\|shadow' >> 1-2.log
echo "" >> 1-2.log

echo '##TWGCB-01-008-0061 check' >> 1-2.log
target="/"
cnt=0
echo "find "${target}" -xdev -type f -perm -0002" >> 1-2.log
for i in `find "${target}" -xdev -type f -perm -0002`
do
	let cnt+=1
done
echo cnt:$cnt >> 1-2.log
echo "" >> 1-2.log

echo '##TWGCB-01-008-0062 check' >> 1-2.log
target="/"
cnt=0
echo "find "${target}" -xdev -nouser" >> 1-2.log
for i in `find "${target}" -xdev -nouser`
do
	let cnt+=1
done
echo cnt:$cnt >> 1-2.log
echo "" >> 1-2.log

echo '##TWGCB-01-008-0063 check' >> 1-2.log
target="/"
cnt=0
echo "find "${target}" -xdev -nogroup" >> 1-2.log
for i in `find "${target}" -xdev -nogroup`
do
	let cnt+=1
done
echo cnt:$cnt >> 1-2.log
echo "" >> 1-2.log

echo '##TWGCB-01-008-0064 check' >> 1-2.log
target="/"
cnt=0
echo "find "${target}" -xdev -type d -perm -0002 -uid +999 -print" >> 1-2.log
for i in `find "${target}" -xdev -type d -perm -0002 -uid +999 -print`
do
	let cnt+=1
done
echo cnt:$cnt >> 1-2.log
echo "" >> 1-2.log

echo '##TWGCB-01-008-0065 check' >> 1-2.log
target="/"
cnt=0
echo "find "${target}" -xdev -type d -perm -0002 -gid +999 -print" >> 1-2.log
for i in `find "${target}" -xdev -type d -perm -0002 -gid +999 -print`
do
	let cnt+=1
done
echo cnt:$cnt >> 1-2.log
echo "" >> 1-2.log

echo '##TWGCB-01-008-0066 check' >> 1-2.log
echo 'find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin -perm /0022 | xargs ls -al'  >> 1-2.log
find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin -perm /0022 | xargs ls -al >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0067 check' >> 1-2.log
echo 'find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -user root | xargs ls -al' >> 1-2.log
find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -user root | xargs ls -al >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0068 check' >> 1-2.log
echo 'find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -user root | xargs ls -al'  >> 1-2.log
find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -user root | xargs ls -al >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0069 check' >> 1-2.log
echo 'find -L /lib /lib64 /usr/lib /usr/lib64 -perm /0022 -type f | xargs ls -al' >> 1-2.log
find -L /lib /lib64 /usr/lib /usr/lib64 -perm /0022 -type f | xargs ls -al >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0070 check' >> 1-2.log
echo 'find -L /lib /lib64 /usr/lib /usr/lib64 ! -user root | xargs ls -al' >> 1-2.log
find -L /lib /lib64 /usr/lib /usr/lib64 ! -user root | xargs ls -al >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0071 check' >> 1-2.log
echo 'find -L /lib /lib64 /usr/lib /usr/lib64 ! -group root | xargs ls -al'  >> 1-2.log
find -L /lib /lib64 /usr/lib /usr/lib64 ! -group root | xargs ls -al >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0072 check' >> 1-2.log
echo "awk -F: '($2 == "" ) { print $1 " does not have a password "}' /etc/shadow"   >> 1-2.log
awk -F: '($2 == "" ) { print $1 " does not have a password "}' /etc/shadow  >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0073 check' >> 1-2.log
echo 'echo $PATH'  >> 1-2.log
echo $PATH >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0074 check' >> 1-2.log
echo 'ls -l /usr/local|grep bin'  >> 1-2.log
ls -l /usr/local|grep bin >> 1-2.log
echo "" >> 1-2.log
echo 'ls -l /usr|grep bin' >> 1-2.log
ls -l /usr|grep bin >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0075 check' >> 1-2.log
echo 'grep '^\+:' /etc/passwd'  >> 1-2.log
grep '^\+:' /etc/passwd >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0076 check' >> 1-2.log
echo 'grep '^\+:' /etc/shadow'  >> 1-2.log
grep '^\+:' /etc/shadow  >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0077 check' >> 1-2.log
echo 'grep '^\+:' /etc/group'  >> 1-2.log
grep '^\+:' /etc/group  >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0078 check' >> 1-2.log
echo "awk -F: '($3 == 0) { print $1 }' /etc/passwd"   >> 1-2.log
awk -F: '($3 == 0) { print $1 }' /etc/passwd  >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0079 check'  >> 1-2.log
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 !="/bin/false") { print $1 " " $6 }' | while read user dir; do
if [ ! -d "$dir" ]; then
echo "The home directory ($dir) of user $user does not exist."
else
dirperm=$(ls -ld $dir | cut -f1 -d" ")
if [ $(echo $dirperm | cut -c6) != "-" ]; then
echo "Group Write permission set on the home directory ($dir) of user
$user"
fi
if [ $(echo $dirperm | cut -c8) != "-" ]; then
echo "Other Read permission set on the home directory ($dir) of user
$user"
fi
if [ $(echo $dirperm | cut -c9) != "-" ]; then
echo "Other Write permission set on the home directory ($dir) of user
$user"
fi
if [ $(echo $dirperm | cut -c10) != "-" ]; then
echo "Other Execute permission set on the home directory ($dir) of user
$user"
fi
fi
done  >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0080 check'  >> 1-2.log
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir; do
if [ ! -d "$dir" ]; then
echo "The home directory ($dir) of user $user does not exist."
else
owner=$(stat -L -c "%U" "$dir")
if [ "$owner" != "$user" ]; then
echo "The home directory ($dir) of user $user is owned by $owner."
fi
fi
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0081 check'  >> 1-2.log
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $4 " " $6 }' | while read user gid dir; do
if [ ! -d "$dir" ]; then
echo "The home directory ($dir) of user $user does not exist."
else
owner=$(stat -L -c "%g" "$dir")
if [ "$owner" != "$gid" ]; then
echo "The home directory ($dir) of group $gid is owned by group $owner."
fi
fi
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0082 check'  >> 1-2.log
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 !="'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir; do
if [ ! -d "$dir" ]; then
echo "The home directory ($dir) of user $user does not exist."
else
for file in $dir/.[A-Za-z0-9]*; do
if [ ! -h "$file" -a -f "$file" ]; then
fileperm=$(ls -ld $file | cut -f1 -d" ")
if [ $(echo $fileperm | cut -c6) != "-" ]; then
echo "Group Write permission set on file $file"
fi
if [ $(echo $fileperm | cut -c9) != "-" ]; then
echo "Other Write permission set on file $file"
fi
fi
done
fi
done  >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0083 check '  >> 1-2.log
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir; do
if [ ! -d "$dir" ]; then
echo "The home directory ($dir) of user $user does not exist."
else
if [ ! -h "$dir/.forward" -a -f "$dir/.forward" ]; then
echo ".forward file $dir/.forward exists"
fi
fi
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0084 check '  >> 1-2.log
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir; do
if [ ! -d "$dir" ]; then
echo "The home directory ($dir) of user $user does not exist."
else
if [ ! -h "$dir/.netrc" -a -f "$dir/.netrc" ]; then
echo ".netrc file $dir/.netrc exists"
fi
fi
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0085 check '  >> 1-2.log
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir; do
if [ ! -d "$dir" ]; then
echo "The home directory ($dir) of user $user does not exist."
else
for file in $dir/.rhosts; do
if [ ! -h "$file" -a -f "$file" ]; then
echo ".rhosts file in $dir"
fi
done
fi
done  >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0086 check'  >> 1-2.log
for i in $(cut -s -d: -f4 /etc/passwd | sort -u ); do
grep -q -P "^.*?:[^:]*:$i:" /etc/group
if [ $? -ne 0 ]; then
echo "Group $i is referenced by /etc/passwd but does not exist in /etc/group"
fi
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0087 check'  >> 1-2.log
cut -f3 -d":" /etc/passwd | sort -n | uniq -c | while read x ; do
[ -z "$x" ] && break
set - $x
if [ $1 -gt 1 ]; then
users=$(awk -F: '($3 == n) { print $1 }' n=$2 /etc/passwd | xargs)
echo "Duplicate UID ($2): $users"
fi
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0088 check '  >> 1-2.log
cut -d: -f3 /etc/group | sort | uniq -d | while read x ; do
echo "Duplicate GID ($x) in /etc/group"
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0089 check '  >> 1-2.log
cut -d: -f1 /etc/passwd | sort | uniq -d | while read x
do echo "Duplicate login name ${x} in /etc/passwd"
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0090 check '  >> 1-2.log
cut -d: -f1 /etc/group | sort | uniq -d | while read x
do echo "Duplicate group name ${x} in /etc/group"
done >> 1-2.log
echo "" >> 1-2.log
echo '##TWGCB-01-008-0091 check '  >> 1-2.log
awk -F: '($1=="shadow") {print $NF}' /etc/group >> 1-2.log
echo "" >> 1-2.log

##0040
#
echo '定義全局變數或全局目標檔案路徑' &> /dev/null
backup_dir="/root/scripts/gcb/1_Basic_SystemSetup-and-Maintenance_v1.2/backup/TWGCB-01-008-0040/$(date +"%Y%m%d")"


echo '創建備份目錄' &> /dev/null
if [ ! -d "$backup_dir" ]; then
        mkdir -p "$backup_dir"
fi


echo '檢查' &> /dev/null
echo -e "TWGCB-01-008-0040 \x1b[33;1m(需手動設定開機載入程式之密碼及重開機測試：\n1.執行grub2-setpassword指令設定密碼。\n2.執行grub2-mkconfig -o \"\$(dirname \"\$(find /boot -type f \( -name 'grubenv' -o -name 'grub.conf' -o -name 'grub.cfg' \) -exec grep -Pl '^\h*(kernelopts=|linux|kernel)' {} \;)\")/grub.cfg\")。\x1b[0m"
echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0040：需手動設定及重開機測試：\n 1.執行grub2-setpassword指令設定密碼。\n 2.執行grub2-mkconfig -o \"\$(dirname \"\$(find /boot -type f \( -name 'grubenv' -o -name 'grub.conf' -o -name 'grub.cfg' \) -exec grep -Pl '^\h*(kernelopts=|linux|kernel)' {} \;)\")/grub.cfg\")。" >> "$backup_dir"/gcb.log
echo -e " 結果：TWGCB-01-008-040 \x1b[31;1m(需手動設定及重開機測試)\x1b[0m\n" >> "$backup_dir"/gcb.log
exit 0


echo '備份檔案函數' &> /dev/null


echo '備份目標檔案' &> /dev/null


echo '設定' &> /dev/null


echo '設定後檢查' &> /dev/null			
          
 
 

 
sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
###################################################################################################### 
 
 
 
 
 
           show_menu;
        ;;
        3) clear;
            option_picked "Option 3 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo




#TWGCB-01-008-0092
dnf remove xinetd -y

#TWGCB-01-008-0094~0101
systemctl --now disable rsyncd
systemctl --now disable avahi-daemon
systemctl --now disable squid
systemctl --now disable smb
systemctl --now disable vsftpd
systemctl --now disable ypserv
systemctl --now enable kdump.service


echo 'TWGCB-01-008-0092 check' >> 1-3.log
echo 'rpm -qa|grep xinetd' >> 1-3.log
rpm -qa|grep xinetd >> 1-3.log
echo "" >> 1-3.log
echo 'TWGCB-01-008-0093 check' >> 1-3.log
echo 'cat /etc/chrony.conf|grep 'server\|pool'' >> 1-3.log
cat /etc/chrony.conf|grep 'server\|pool' >> 1-3.log
echo "" >> 1-3.log
echo 'TWGCB-01-008-0094~0101 check' >> 1-3.log
echo 'systemctl status rsyncd' >> 1-3.log
systemctl status rsyncd  >> 1-3.log
echo "" >> 1-3.log
echo 'systemctl status avahi-daemon' >> 1-3.log
systemctl status avahi-daemon >> 1-3.log
echo "" >> 1-3.log
echo 'systemctl status avahi-daemon' >> 1-3.log
systemctl status avahi-daemon >> 1-3.log
echo "" >> 1-3.log
echo 'systemctl status squid' >> 1-3.log
systemctl status squid >> 1-3.log
echo "" >> 1-3.log
echo 'systemctl status smb' >> 1-3.log
systemctl status smb >> 1-3.log
echo "" >> 1-3.log
echo 'systemctl status vsftpd' >> 1-3.log
systemctl status vsftpd >> 1-3.log
echo "" >> 1-3.log
echo 'systemctl status ypserv' >> 1-3.log
systemctl status ypserv >> 1-3.log
echo "" >> 1-3.log
echo 'systemctl status kdump.service' >> 1-3.log
systemctl status kdump.service >> 1-3.log
echo "" >> 1-3.log


sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################




            show_menu;
        ;;
        4) clear;
            option_picked "Option 4 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo


#TWGCB-01-008-0102~0106
dnf remove ypbind
dnf remove telnet -y
dnf remove telnet-server -y
dnf remove rsh-server -y
dnf remove tftp-server –y

#TWGCB-01-008-0107
dnf remove xinetd -y
sed -i '/clean_requirements_on_remove/s/False/True/' /etc/yum.conf
sed -i '/clean_requirements_on_remove/s/False/True/' /etc/dnf/dnf.conf


echo 'TWGCB-01-008-0102~0106 check' >> 1-4.log
echo 'rpm -qa|grep ypbind' >> 1-4.log
rpm -qa|grep ypbind >> 1-4.log
echo "" >> 1-4.log
echo 'rpm -qa|grep telnet' >> 1-4.log
rpm -qa|grep telnet >> 1-4.log
echo "" >> 1-4.log
echo 'rpm -qa|grep rsh-server' >> 1-4.log
rpm -qa|grep rsh-server >> 1-4.log
echo "" >> 1-4.log
echo 'rpm -qa|grep tftp-server' >> 1-4.log
rpm -qa|grep tftp-server >> 1-4.log
echo "" >> 1-4.log
echo 'TWGCB-01-008-0107 check' >> 1-4.log
echo 'cat /etc/yum.conf|grep clean_requirements' >> 1-4.log
cat /etc/yum.conf|grep clean_requirements  >> 1-4.log
echo "" >> 1-4.log

sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################






            show_menu;
        ;;
        5) clear;
            option_picked "Option 5 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo



#TWGCB-01-008-0108
sed -i '/net\.ipv4\.ip_forward/s/^net\.ipv4\.ip_forward/#net\.ipv4\.ip_forward/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.ip_forward=0' /etc/sysctl.conf
sed -i '/net\.ipv6\.conf\.all\.forwarding/s/^net\.ipv6\.conf\.all\.forwarding/#net\.ipv6\.conf\.all\.forwarding/' /etc/sysctl.conf && sed -i '$a\net\.ipv6\.conf\.all\.forwarding=0' /etc/sysctl.conf

#TWGCB-01-008-0109~0110
sed -i '/net\.ipv4\.conf\.all\.send_redirects/s/^net\.ipv4\.conf\.all\.send_redirects/#net\.ipv4\.conf\.all\.send_redirects/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.all\.send_redirects=0' /etc/sysctl.conf
sed -i '/net\.ipv4\.conf\.default\.send_redirects/s/^net\.ipv4\.conf\.default\.send_redirects/#net\.ipv4\.conf\.default\.send_redirects/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.default\.send_redirects=0' /etc/sysctl.conf

#TWGCB-01-008-0111~0112
sed -i '/net\.ipv4\.conf\.all\.accept_source_route/s/^net\.ipv4\.conf\.all\.accept_source_route/#net\.ipv4\.conf\.all\.accept_source_route/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.all\.accept_source_route=0' /etc/sysctl.conf
sed -i '/net\.ipv6\.conf\.all\.accept_source_route/s/^net\.ipv6\.conf\.all\.accept_source_route/#net\.ipv4\.conf\.all\.accept_source_route/' /etc/sysctl.conf && sed -i '$a\net\.ipv6\.conf\.all\.accept_source_route=0' /etc/sysctl.conf
sed -i '/net\.ipv4\.conf\.default\.accept_source_route/s/^net\.ipv4\.conf\.default\.accept_source_route/#net\.ipv4\.conf\.all\.accept_source_route/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.default\.accept_source_route=0' /etc/sysctl.conf
sed -i '/net\.ipv6\.conf\.default\.accept_source_route/s/^net\.ipv6\.conf\.default\.accept_source_route/#net\.ipv4\.conf\.all\.accept_source_route/' /etc/sysctl.conf && sed -i '$a\net\.ipv6\.conf\.default\.accept_source_route=0' /etc/sysctl.conf

#TWGCB-01-008-0113~0114
sed -i '/net\.ipv4\.conf\.all\.accept_redirects/s/^net\.ipv4\.conf\.all\.accept_redirects/#net\.ipv4\.conf\.all\.accept_redirects/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.all\.accept_redirects=0' /etc/sysctl.conf
sed -i '/net\.ipv6\.conf\.all\.accept_redirects/s/^net\.ipv6\.conf\.all\.accept_redirects/#net\.ipv6\.conf\.all\.accept_redirects/' /etc/sysctl.conf && sed -i '$a\net\.ipv6\.conf\.all\.accept_redirects=0' /etc/sysctl.conf
sed -i '/net\.ipv4\.conf\.default\.accept_redirects/s/^net\.ipv4\.conf\.default\.accept_redirects/#net\.ipv4\.conf\.default\.accept_redirects/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.default\.accept_redirects=0' /etc/sysctl.conf
sed -i '/net\.ipv6\.conf\.default\.accept_redirects/s/^net\.ipv6\.conf\.default\.accept_redirects/#net\.ipv6\.conf\.default\.accept_redirects/' /etc/sysctl.conf && sed -i '$a\net\.ipv6\.conf\.default\.accept_redirects=0' /etc/sysctl.conf

#TWGCB-01-008-0115~0116
sed -i '/net\.ipv4\.conf\.all\.secure_redirects/s/^net\.ipv4\.conf\.all\.secure_redirects/#net\.ipv4\.conf\.all\.secure_redirects/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.all\.secure_redirects=0' /etc/sysctl.conf
sed -i '/net\.ipv4\.conf\.default\.secure_redirects/s/^net\.ipv4\.conf\.default\.secure_redirects/#net\.ipv4\.conf\.default\.secure_redirects/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.default\.secure_redirects=0' /etc/sysctl.conf

#TWGCB-01-008-0117~0118
sed -i '/net\.ipv4\.conf\.all\.log_martians/s/^net\.ipv4\.conf\.all\.log_martians/#net\.ipv4\.conf\.all\.log_martians/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.all\.log_martians=1' /etc/sysctl.conf
sed -i '/net\.ipv4\.conf\.default\.log_martians/s/^net\.ipv4\.conf\.default\.log_martians/#net\.ipv4\.conf\.default\.log_martians/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.default\.log_martians=1' /etc/sysctl.conf

#TWGCB-01-008-0119
sed -i '/net\.ipv4\.icmp_echo_ignore_broadcasts/s/^net\.ipv4\.icmp_echo_ignore_broadcasts/#net\.ipv4\.icmp_echo_ignore_broadcasts/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.icmp_echo_ignore_broadcasts=1' /etc/sysctl.conf

#TWGCB-01-008-0120
sed -i '/net\.ipv4\.icmp_ignore_bogus_error_responses/s/^net\.ipv4\.icmp_ignore_bogus_error_responses/#net\.ipv4\.icmp_ignore_bogus_error_responses/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.icmp_ignore_bogus_error_responses=1' /etc/sysctl.conf

#TWGCB-01-008-0121~0122
sed -i '/net\.ipv4\.conf\.all\.rp_filter/s/^net\.ipv4\.conf\.all\.rp_filter/#net\.ipv4\.conf\.all\.rp_filter/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.all\.rp_filter=1' /etc/sysctl.conf
sed -i '/net\.ipv4\.conf\.default\.rp_filter/s/^net\.ipv4\.conf\.default\.rp_filter/#net\.ipv4\.conf\.default\.rp_filter/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.conf\.default\.rp_filter=1' /etc/sysctl.conf

#TWGCB-01-008-0123
sed -i '/net\.ipv4\.tcp_syncookies/s/^net\.ipv4\.tcp_syncookies/#net\.ipv4\.tcp_syncookies/' /etc/sysctl.conf && sed -i '$a\net\.ipv4\.tcp_syncookies=1' /etc/sysctl.conf

#TWGCB-01-008-0124
sed -i '/net\.ipv6\.conf\.all\.accept_ra/s/^net\.ipv6\.conf\.all\.accept_ra/#net\.ipv6\.conf\.all\.accept_ra/' /etc/sysctl.conf && sed -i '$a\net\.ipv6\.conf\.all\.accept_ra=0' /etc/sysctl.conf
sed -i '/net\.ipv6\.conf\.default\.accept_ra/s/^net\.ipv6\.conf\.default\.accept_ra/#net\.ipv6\.conf\.default\.accept_ra/' /etc/sysctl.conf && sed -i '$a\net\.ipv6\.conf\.default\.accept_ra=0' /etc/sysctl.conf

#TWGCB-01-008-0125
sysctl -w net.ipv4.route.flush=1
sysctl -w net.ipv6.route.flush=1
sysctl -w net.ipv4.conf.all.accept_source_route=0
sysctl -w net.ipv6.conf.all.accept_source_route=0

#TWGCB-01-008-0126~0129
[ -f /etc/modprobe.d/dccp.conf ] || echo -e 'install dccp /bin/true\nblacklist dccp' >> /etc/modprobe.d/dccp.conf
[ -f /etc/modprobe.d/sctp.conf ] || echo -e 'install sctp /bin/true\nblacklist sctp' >> /etc/modprobe.d/sctp.conf
[ -f /etc/modprobe.d/rds.conf ] || echo -e 'install rds /bin/true\nblacklist rds' >> /etc/modprobe.d/rds.conf
[ -f /etc/modprobe.d/tipc.conf ] || echo -e 'install tipc /bin/true\nblacklist tipc' >> /etc/modprobe.d/tipc.conf

#TWGCB-01-008-0130
nmcli radio all off

#TWGCB-01-008-0131
netline=($(nmcli device status | awk -F" " '{if($3 == "connected"){print $1}}')) ; netnumber=`nmcli device status | awk -F" " '{if($3 == "connected"){print $1}}'| wc -l` ; for (( a=0;a<$netnumber;a++ )) ; do ip link set dev ${netline[$a]} multicast off promisc off ; done

echo 'TWGCB-01-008-0108 check' >> 1-5.log
echo 'grep -Els "^\s*net\.ipv4\.ip_forward\s*=\s*1" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf' >> 1-5.log
grep -Els "^\s*net\.ipv4\.ip_forward\s*=\s*1" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf >> 1-5.log
echo "" >> 1-5.log
echo 'grep -Els "^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*1" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf' >> 1-5.log
grep -Els "^\s*net\.ipv6\.conf\.all\.forwarding\s*=\s*1" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf >> 1-5.log
echo "" >> 1-5.log

echo '#TWGCB-01-008-0109~0125 check' >> 1-5.log
echo "cat /etc/sysctl.conf|grep 'forward\|redirects\|accept\|filter\|icmp\|martians\|syncookies'" >> 1-5.log
cat /etc/sysctl.conf|grep 'forward\|redirects\|accept\|filter\|icmp\|martians\|syncookies' >> 1-5.log
echo "" >> 1-5.log

echo '#TWGCB-01-008-0126 check' >> 1-5.log
echo 'cat /etc/modprobe.d/dccp.conf' >> 1-5.log
cat /etc/modprobe.d/dccp.conf >> 1-5.log
echo "" >> 1-5.log

echo '#TWGCB-01-008-0127 check' >> 1-5.log
echo 'cat /etc/modprobe.d/sctp.conf' >> 1-5.log
cat /etc/modprobe.d/sctp.conf >> 1-5.log
echo "" >> 1-5.log

echo '#TWGCB-01-008-0128 check' >> 1-5.log
echo 'cat /etc/modprobe.d/rds.conf' >> 1-5.log
cat /etc/modprobe.d/rds.conf >> 1-5.log
echo "" >> 1-5.log

echo '#TWGCB-01-008-0129 check' >> 1-5.log
echo 'cat /etc/modprobe.d/tipc.conf' >> 1-5.log
cat /etc/modprobe.d/tipc.conf >> 1-5.log
echo "" >> 1-5.log

echo '#TWGCB-01-008-0130 check' >> 1-5.log
echo 'nmcli radio all'>> 1-5.log
nmcli radio all >> 1-5.log
echo "" >> 1-5.log

echo '#TWGCB-01-008-0131 check' >> 1-5.log
echo 'ip link'>> 1-5.log
ip link>> 1-5.log
echo "" >> 1-5.log


sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################






            show_menu;
        ;;
        6) clear;
            option_picked "Option 6 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo


#TWGCB-01-008-0134~0135
grep "audit=1" /etc/default/grub ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/GRUB_CMDLINE_LINUX/s/"$/\ audit=1"/' /etc/default/grub ;fi
grep "audit_backlog_limit" /etc/default/grub ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/GRUB_CMDLINE_LINUX/s/"$/\ audit_backlog_limit=8192"/' /etc/default/grub ;fi

#TWGCB-01-008-0136
postmasterline=`grep 'postmaster:' /etc/aliases | awk -F' ' '{print $2}'` ; if [ $postmasterline == "root" ]; then sed -i "/postmaster:/s/$postmasterline/root/" /etc/aliases ; fi

#TWGCB-01-008-0137~0142
chown root:root /var/log/audit/audit.log
chmod 600 /var/log/audit/audit.log
chown root:root /var/log/audit
chmod 600 /var/log/audit
chmod 600 /etc/audit/rules.d/audit.rules
chmod 640 /etc/audit/auditd.conf

#TWGCB-01-008-0143~0144
chmod 750 /sbin/auditctl
chown root:root /sbin/auditctl
chmod 750 /sbin/aureport
chown root:root /sbin/aureport
chmod 750 /sbin/ausearch
chown root:root /sbin/ausearch
chmod 750 /sbin/autrace
chown root:root /sbin/autrace
chmod 750 /sbin/auditd
chown root:root /sbin/auditd
chmod 750 /sbin/audisp-remote
chown root:root /sbin/audisp-remote
chmod 750 /sbin/audisp-syslog
chown root:root /sbin/audisp-syslog
chmod 750 /sbin/augenrules
chown root:root /sbin/augenrules

#TWGCB-01-008-0146
auditlogline=`grep -iw 'max_log_file' /etc/audit/auditd.conf | awk -F' ' '{print $3}'` ; if [ $auditlogline != "32" ]; then sed -i "/max_log_file/s/$auditlogline/32/" /etc/audit/auditd.conf ; fi

#TWGCB-01-008-0147
auditlogline=`grep -iw 'max_log_file_action' /etc/audit/auditd.conf | awk -F' ' '{print $3}'` ; if [ $auditlogline != "keep_logs" ]; then sed -i "/max_log_file_action/s/$auditlogline/keep_logs/" /etc/audit/auditd.conf ; fi

#TWGCB-01-008-0148
grep -iw "/etc/sudoers" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-w /etc/sudoers -p wa -k scope\n-w /etc/sudoers.d/ -p wa -k scope' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0149
grep -iw "/var/run/faillock" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-w /var/run/faillock/ -p wa -k logins\n-w /var/log/lastlog -p wa -k logins' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0150
grep -iw "/var/run/utmp" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-w /var/run/utmp -p wa -k session\n-w /var/log/wtmp -p wa -k logins\n-w /var/log/btmp -p wa -k logins' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0151
grep -iw "\-k\ time-change" /etc/audit/rules.d/audit.rules ;tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change\n-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change\n-a always,exit -F arch=b64 -S clock_settime -k time-change\n-a always,exit -F arch=b32 -S clock_settime -k time-change\n-w /etc/localtime -p wa -k time-change' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0152
grep -iw "\-k\ MAC\-policy" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-w /etc/selinux/ -p wa -k MAC-policy\n-w /usr/share/selinux/ -p wa -k MAC-policy' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0153
grep -iw "\-k\ system\-locale" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale\n-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale\n-w /etc/issue -p wa -k system-locale\n-w /etc/issue.net -p wa -k system-locale\n-w /etc/hosts -p wa -k system-locale\n-w /etc/sysconfig/network-scripts/ -p wa -k system-locale' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0154
grep -iw "\-k\ perm_mod" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod\n-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod\n-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod\n-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod\n-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod\n-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0155
grep -iw "\-k\ access" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access\n-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access\n-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access\n-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0156
grep -iw "\-k\ identity" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-w /etc/group -p wa -k identity\n-w /etc/passwd -p wa -k identity\n-w /etc/gshadow -p wa -k identity\n-w /etc/shadow -p wa -k identity\n-w /etc/security/opasswd -p wa -k identity' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0157
grep -iw "\-k\ mounts" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts\n-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0158
find / -xdev \( -perm -4000 -o -perm -2000 \) -type f | awk '{print "-a always,exit -F path=" $1 " -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged" }' >> /etc/audit/rules.d/privileged.rules

#TWGCB-01-008-0159
grep -iw "\-k\ delete" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete\n-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0160、0170
grep -iw "\-k\ modules" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-w /sbin/insmod -p x -k modules\n-w /bin/kmod -p x -k modules\n-w /sbin/rmmod -p x -k modules\n-w /sbin/modprobe -p x -k modules\n-a always,exit -F arch=b64 -S init_module -S delete_module -k modules' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0161
sudolog=`grep -r logfile /etc/sudoers* | sed -e 's/.*logfile=//;s/,? .*//'|sed -e 's/"//g'` ;  grep -iw "\-k\ actions" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e "-w $sudolog -p wa -k actions" >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0162、0165、0169
grep -iw "\-k\ perm_chng" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F path=/usr/bin/chcon -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng\n-a always,exit -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng\n-a always,exit -F path=/usr/bin/chacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0163
grep -iw "\-k\ privileged\-ssh" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F path=/usr/bin/ssh-agent -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-ssh' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0164
grep -iw "\-k\ privileged\-unix\-update" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F path=/sbin/unix_update -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix-update' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0166
grep -iw "\-k\ module_chng" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b32 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng\n-a always,exit -F arch=b64 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0167
grep -iw "\-k\ perm_access" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access\n-a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access\n-a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access\n-a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0168
grep -iw "\-k\ privileged\-usermod" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-usermod' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0172
grep -iw "\-F\ key=execpriv" /etc/audit/rules.d/audit.rules ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e '-a always,exit -F arch=b32 -S execve -C uid!=euid -F key=execpriv\n-a always,exit -F arch=b64 -S execve -C uid!=euid -F key=execpriv\n-a always,exit -F arch=b32 -S execve -C gid!=egid -F key=execpriv\n-a always,exit -F arch=b64 -S execve -C gid!=egid -F key=execpriv' >> /etc/audit/rules.d/audit.rules ; fi

#TWGCB-01-008-0173
sed -i '/\-e\ 2/s/^\-e\ 2/#\-e\ 2/' /etc/audit/rules.d/audit.rules && echo -e "-e 2" >> /etc/audit/rules.d/audit.rules

#TWGCB-01-008-0174~0175
dnf install rsyslog -y
systemctl --now enable rsyslog

#TWGCB-01-008-0176
sed -i '/\$FileCreateMode/s/^\$FileCreateMode\ 0640/#\$FileCreateMode\ 0640/' /etc/rsyslog.conf && echo -e "\$FileCreateMode 0640" >> /etc/rsyslog.conf

#TWGCB-01-008-0177
grep -iw "auth.\*" /etc/rsyslog.conf ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e 'auth.*,authpriv.* /var/log/secure' >> /etc/rsyslog.conf ; fi
grep -iw "daemon.\*" /etc/rsyslog.conf ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e 'daemon.* /var/log/messages' >> /etc/rsyslog.conf ; fi
systemctl restart rsyslog.service

#TWGCB-01-008-0178~0179
chown root:root /var/log/messages
chown root:root /var/log

#TWGCB-01-008-0180
sed -i '/ForwardToSyslog/s/#ForwardToSyslog=no/ForwardToSyslog=yes/' /etc/systemd/journald.conf

#TWGCB-01-008-0181
sed -i '/Compress/s/#Compress=yes/Compress=yes/' /etc/systemd/journald.conf

#TWGCB-01-008-0182
sed -i '/Storage/s/#Storage=auto/Storage=persistent/' /etc/systemd/journald.conf

#TWGCB-01-008-0183~0184
find /var/log -type f -exec chmod g-wx,o-rwx "{}" +
find /var/log -type d -exec chmod g-w,o-rwx "{}" +

echo 'TWGCB-01-008-0132~0133 check' >> 1-6.log
echo 'systemctl status auditd' >> 1-6.log
systemctl status auditd >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0134~0135 check' >> 1-6.log
echo 'cat /etc/default/grub|grep GRUB_CMDLINE_LINUX' >> 1-6.log
cat /etc/default/grub|grep GRUB_CMDLINE_LINUX >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0136 check' >> 1-6.log
echo 'cat /etc/aliases |grep postmaster|grep root' >> 1-6.log
cat /etc/aliases |grep postmaster|grep root >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0137~0142 check' >> 1-6.log
echo 'ls -l /var/log/audit/audit.log  /etc/audit/rules.d/audit.rules /etc/audit/auditd.conf' >> 1-6.log
ls -l /var/log/audit/audit.log  /etc/audit/rules.d/audit.rules /etc/audit/auditd.conf >> 1-6.log
echo "" >> 1-6.log
echo 'ls -l /var/log|grep audit' >> 1-6.log
ls -l /var/log|grep audit >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0143 check' >> 1-6.log
echo 'stat -c "%a %n" /sbin/auditctl /sbin/aureport /sbin/ausearch /sbin/autrace /sbin/auditd /sbin/audisp-remote /sbin/audisp-syslog /sbin/augenrules' >> 1-6.log
stat -c "%a %n" /sbin/auditctl /sbin/aureport /sbin/ausearch /sbin/autrace /sbin/auditd /sbin/audisp-remote /sbin/audisp-syslog /sbin/augenrules >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0144 check' >> 1-6.log
echo 'ls -al /sbin/auditctl /sbin/aureport /sbin/ausearch /sbin/autrace /sbin/auditd /sbin/audisp-remote /sbin/audisp-syslog /sbin/augenrules' >> 1-6.log
ls -al /sbin/auditctl /sbin/aureport /sbin/ausearch /sbin/autrace /sbin/auditd /sbin/audisp-remote /sbin/audisp-syslog /sbin/augenrules >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0146~0147 check' >> 1-6.log
echo 'cat /etc/audit/auditd.conf|grep max_log' >> 1-6.log
cat /etc/audit/auditd.conf|grep max_log >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0148~0157，0159~0173 check' >> 1-6.log
echo 'cat /etc/audit/rules.d/audit.rules|grep '\w\|\-a\|\-e'' >> 1-6.log
cat /etc/audit/rules.d/audit.rules|grep '\-w\|\-a\|\-e' >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0158 check' >> 1-6.log
echo 'cat /etc/audit/rules.d/privileged.rules' >> 1-6.log
cat /etc/audit/rules.d/privileged.rules >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0174~0175 check' >> 1-6.log
echo 'systemctl status rsyslog' >> 1-6.log
systemctl status rsyslog >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0176~0177 check' >> 1-6.log
echo 'cat /etc/rsyslog.conf|grep 'auth\.\|daemon\|FileCreateMode'' >> 1-6.log
cat /etc/rsyslog.conf|grep 'auth\.\|daemon\|FileCreateMode'>> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0178~0179 check' >> 1-6.log
echo 'ls -l /var|grep log' >> 1-6.log
 ls -l /var|grep log >> 1-6.log
echo "" >> 1-6.log
echo 'ls -l /var/log/messages' >> 1-6.log
ls -l /var/log/messages >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0180~0182 check' >> 1-6.log
echo ' cat /etc/systemd/journald.conf|grep 'ForwardToSyslog\|Compress\|Storage'' >> 1-6.log
cat /etc/systemd/journald.conf|grep 'ForwardToSyslog\|Compress\|Storage' >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0183 check' >> 1-6.log
echo ' find /var/log -type f -exec chmod g-wx,o-rwx "{}" +' >> 1-6.log
find /var/log -type f -exec chmod g-wx,o-rwx "{}" + >> 1-6.log
echo "" >> 1-6.log

echo 'TWGCB-01-008-0183 check' >> 1-6.log
echo 'find /var/log -type d -exec chmod g-w,o-rwx "{}" +' >> 1-6.log
find /var/log -type d -exec chmod g-w,o-rwx "{}" + >> 1-6.log
echo "" >> 1-6.log



sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################






            show_menu;
        ;;
        7) clear;
            option_picked "Option 7 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo




#TWGCB-01-008-0185
dnf install libselinux -y

#TWGCB-01-008-0186
sed -i '/CMDLINE_LINUX/s/selinux=0//' /etc/default/grub
sed -i '/CMDLINE_LINUX/s/enforcing=0//' /etc/default/grub
grub2-mkconfig -o /boot/grub2/grub.cfg

#TWGCB-01-008-0187
#sed -i '/^SELINUXTYPE=/s/SELINUXTYPE=.*/SELINUXTYPE=targeted/' /etc/selinux/config

#TWGCB-01-008-0188
#sed -i '/^SELINUX=/s/SELINUX=.*/SELINUX=enforcing/' /etc/selinux/config

#TWGCB-01-008-0189
#ps -eZf | grep unconfined_service_t

#TWGCB-01-008-0190
dnf remove setroubleshoot –y

#TWGCB-01-008-0191
dnf remove mcstrans -y


echo 'TWGCB-01-008-0185、0190~0191 check' >> 1-7.log
echo 'rpm -qa|grep 'libselinux\|setroubleshoot\|mcstrans'' >> 1-7.log
rpm -qa|grep 'libselinux\|setroubleshoot\|mcstrans' >> 1-7.log
echo "" >> 1-7.log

echo 'TWGCB-01-008-0186 check' >> 1-7.log
echo 'cat /etc/default/grub|grep CMDLINE' >> 1-7.log
cat /etc/default/grub|grep CMDLINE >> 1-7.log
echo "" >> 1-7.log

echo 'TWGCB-01-008-0187~0188 check' >> 1-7.log
echo 'cat /etc/selinux/config|grep SELINUX' >> 1-7.log
cat /etc/selinux/config|grep SELINUX >> 1-7.log
echo "" >> 1-7.log

echo 'TWGCB-01-008-0189 check' >> 1-7.log
echo 'ps -eZf | grep unconfined_service_t|grep -v 'color\=auto'' >> 1-7.log
ps -eZf | grep unconfined_service_t|grep -v 'color\=auto' >> 1-7.log
echo "" >> 1-7.log




sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################







            show_menu;
        ;;
        8) clear;
            option_picked "Option 8 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo





#TWGCB-01-008-0192~0204
systemctl --now enable crond
chown root:root /etc/crontab
chmod 600 /etc/crontab
chown root:root /etc/cron.hourly
chmod 700 /etc/cron.hourly
chown root:root /etc/cron.daily
chmod 700 /etc/cron.daily
chown root:root /etc/cron.weekly
chmod 700 /etc/cron.weekly
chown root:root /etc/cron.monthly
chmod 700 /etc/cron.monthly
chown root:root /etc/cron.d
chmod 700 /etc/cron.d

#TWGCB-01-008-0205~0206
rm -rf /etc/cron.deny
rm -rf /etc/at.deny
touch /etc/cron.allow 
touch /etc/at.allow 
chown root:root /etc/cron.allow
chown root:root /etc/at.allow
chmod 600 /etc/cron.allow
chmod 600 /etc/at.allow
userline=($(awk -F":" '{if($3>=1000 && $3<=10000){print $1}}' /etc/passwd)) ; usernumber=`awk -F":" '{if($3>=1000 && $3<=10000){print $1}}' /etc/passwd | wc -l` ; for (( a=0;a<$usernumber;a++ )) ; do echo ${userline[$a]} >> /etc/cron.allow ; echo ${userline[$a]} >> /etc/at.allow  ; done

#TWGCB-01-008-0207
#grep -iw "cron.\*" /etc/rsyslog.conf ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e 'cron.* /var/log/cron.log' >> /etc/rsyslog.conf ; fi
#
echo '定義全局變數或全局目標檔案路徑' &> /dev/null
backup_dir="/root/scripts/gcb/1_Basic_CronSettings_v1.2/backup/TWGCB-01-008-0207/$(date +"%Y%m%d")"
FILE="/etc/rsyslog.conf /etc/rsyslog.d/*.conf"


echo '創建備份目錄' &> /dev/null
if [ ! -d "$backup_dir" ]; then
	mkdir -p $backup_dir
fi


echo '檢查' &> /dev/null
if grep -Eq "^cron.*\s+/var/log/cron.log" $FILE 2> /dev/null; then
	echo -e "TWGCB-01-008-0207 OK (沒有設定改變)"
	echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0207：沒有設定改變。" >> $backup_dir/gcb.log
	echo -e " 結果：TWGCB-01-008-0207 OK\n" >> $backup_dir/gcb.log
	exit 0
fi


echo '備份檔案函數' &> /dev/null
backup_file() {
	local file="$1"
	cp -i "$file" "$backup_dir/$(basename $file).$(date +%Y-%m-%d-%H%M%S)"
}


echo '備份目標檔案' &> /dev/null
for i in $(ls $FILE 2> /dev/null);do
	backup_file $i
done
echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0207：\n - 備份$(ls $FILE 2> /dev/null)檔案於$backup_dir目錄。" >> $backup_dir/gcb.log


echo '設定' &> /dev/null
for i in $(ls $FILE 2> /dev/null);do
	if grep -Eq "^\s*##GCB" $i; then
		sed -ri "/^\s*##GCB/a\\#TWGCB-01-008-0207" $i
		sed -ri "/^\s*#TWGCB-01-008-0207/a\\cron.*                                                  /var/log/cron.log" $i
	else
		echo "" >> $i
		echo "##GCB" >> $i
		echo "#TWGCB-01-008-0207" >> $i
		echo "cron.*                                                  /var/log/cron.log" >> $i
	fi
done
echo -e " - 在$(ls $FILE 2> /dev/null)文件設定cron.*                                                  /var/log/cron.log。" >> $backup_dir/gcb.log


echo '設定後檢查' &> /dev/null
if grep -Eq "^cron.*\s+/var/log/cron" $FILE 2> /dev/null; then
	echo -e "TWGCB-01-008-0207 OK (設定成功)"
	echo -e " 結果：TWGCB-01-008-0207 OK (設定成功)\n" >> $backup_dir/gcb.log
	exit 0
else
	echo -e "\x1b[31;1mTWGCB-01-008-0207 FAIL (設定失敗)\x1b[0m"
	echo -e " \x1b[31;1m結果：TWGCB-01-008-0207 FAIL (設定失敗)\x1b[0m\n" >> $backup_dir/gcb.log
	exit 1
fi
#####
echo 'TWGCB-01-008-0192 check' >> 1-8.log
echo 'systemctl status crond' >> 1-8.log
systemctl status crond >> 1-8.log
echo "" >> 1-8.log

echo 'TWGCB-01-008-0193~0204 check' >> 1-8.log
echo 'ls -l /etc|grep cron' >> 1-8.log
ls -l /etc|grep cron >> 1-8.log
echo "" >> 1-8.log

echo 'TWGCB-01-008-0205~0206 check' >> 1-8.log
echo 'ls -l /etc|grep allow' >> 1-8.log
ls -l /etc|grep allow >> 1-8.log
echo "" >> 1-8.log

echo 'TWGCB-01-008-0207 check' >> 1-8.log
echo 'grep cron /etc/rsyslog.conf /etc/rsyslog.d/*.conf' >> 1-8.log
grep cron /etc/rsyslog.conf /etc/rsyslog.d/*.conf >> 1-8.log
echo "" >> 1-8.log


sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################








            show_menu;
        ;;
        9) clear;
            option_picked "Option 9 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo




#TWGCB-01-008-0208
grep -iw "retry=" /etc/pam.d/password-auth ; tmp_fin=$? ; if [ $tmp_fin == 0 ] ;then sed -i '/pam_pwquality.so/s/retry=\S/retry=3/' /etc/pam.d/password-auth ;else sed  -i '/pam_pwquality.so/s/local_users_only/local_users_only\ retry=3/' /etc/pam.d/password-auth  ;fi
grep -iw "retry=" /etc/pam.d/system-auth ; tmp_fin=$? ; if [ $tmp_fin == 0 ] ;then sed -i '/pam_pwquality.so/s/retry=\S/retry=3/' /etc/pam.d/system-auth ;else sed  -i '/pam_pwquality.so/s/local_users_only/local_users_only\ retry=3/' /etc/pam.d/system-auth  ;fi

#TWGCB-01-008-0209
grep -iw "enforce_for_root" /etc/pam.d/password-auth ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/pam_pwquality.so/s/local_users_only/local_users_only\ enforce_for_root/' /etc/pam.d/password-auth ;fi
grep -iw "enforce_for_root" /etc/pam.d/system-auth ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/pam_pwquality.so/s/local_users_only/local_users_only\ enforce_for_root/' /etc/pam.d/system-auth ;fi

#TWGCB-01-008-0210
sed -i '/minlen/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\minlen = 12' /etc/security/pwquality.conf

#TWGCB-01-008-0211
sed -i '/minclass/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\minclass = 4' /etc/security/pwquality.conf

#TWGCB-01-008-0212~0215
sed -i '/dcredit/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\dcredit = -1' /etc/security/pwquality.conf
sed -i '/ucredit/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\ucredit = -1' /etc/security/pwquality.conf
sed -i '/lcredit/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\lcredit = -1' /etc/security/pwquality.conf
sed -i '/ocredit/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\ocredit = -1' /etc/security/pwquality.conf

#TWGCB-01-008-0216
sed -i '/difok/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\difok = 3' /etc/security/pwquality.conf

#TWGCB-01-008-0217
sed -i '/maxclassrepeat/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\maxclassrepeat = 4' /etc/security/pwquality.conf

#TWGCB-01-008-0218
sed -i '/maxrepeat/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\maxrepeat = 3' /etc/security/pwquality.conf

#TWGCB-01-008-0219
sed -i '/dictcheck/s/^/#/' /etc/security/pwquality.conf && sed -i '$a\dictcheck = 1' /etc/security/pwquality.conf

#TWGCB-01-008-0220~0221 (check_alan)
grep "pam\_faillock" /etc/pam.d/password-auth ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/pam_faildelay.so/s/.*/auth        required                                     pam_faildelay.so delay=900/' /etc/pam.d/password-auth ; sed -i '/pam_faildelay.so/a\auth        required                                     pam_faillock.so preauth silent deny=3 unlock_time=900' /etc/pam.d/password-auth ; sed -i '/^auth.*pam_deny.so$/a\auth        required                                     pam_faillock.so authfail audit deny=3 unlock_time=900' /etc/pam.d/password-auth  ;fi
grep "pam\_faillock" /etc/pam.d/system-auth ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/pam_faildelay.so/s/.*/auth        required                                     pam_faildelay.so delay=900/' /etc/pam.d/system-auth ; sed -i '/pam_faildelay.so/a\auth        required                                     pam_faillock.so preauth silent deny=3 unlock_time=900' /etc/pam.d/system-auth ; sed -i '/^auth.*pam_deny.so$/a\auth        required                                     pam_faillock.so authfail audit deny=3 unlock_time=900' /etc/pam.d/system-auth  ;fi

#TWGCB-01-012-0219
sed -i '/deny/s/^/#/' /etc/security/faillock.conf && sed -i '$a\deny = 5' /etc/security/faillock.conf

#TWGCB-01-012-0220
sed -i '/unlock_time/s/^/#/' /etc/security/faillock.conf && sed -i '$a\unlock_time = 900' /etc/security/faillock.conf

#TWGCB-01-008-0222
grep "pam\_pwhistory" /etc/pam.d/system-auth ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/pam_pwquality.so/a\password    required                                     pam_pwhistory.so use_authtok remember=3' /etc/pam.d/system-auth ;fi

#TWGCB-01-008-0223
grep "session\ \ \ required\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ pam\_lastlog\.so" /etc/pam.d/postlogin ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '4asession     required                   pam_lastlog.so showfailed' /etc/pam.d/postlogin; fi

#TWGCB-01-008-0224
sed -i '/^ENCRYPT_METHOD/s/ENCRYPT_METHOD\ .*/ENCRYPT_METHOD\ SHA512/' /etc/login.defs
grep -iw "sha512" /etc/pam.d/password-auth ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/password\ \ \ \ sufficient\ \ \ \ pam\_unix\.so/s/nullok/nullok\ sha512/' /etc/pam.d/password-auth  ;fi
grep -iw "sha512" /etc/pam.d/system-auth ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '/password\ \ \ \ sufficient\ \ \ \ pam\_unix\.so/s/nullok/nullok\ sha512/' /etc/pam.d/system-auth  ;fi

#TWGCB-01-008-0225~0227
sed  -i '/^PASS_MIN_DAYS/s/.*/PASS_MIN_DAYS\ \ \ 60/' /etc/login.defs
sed  -i '/^PASS_WARN_AGE/s/.*/PASS_WARN_AGE\ \ \ 14/' /etc/login.defs
sed -i '/^PASS_MAX_DAYS/s/.*/PASS_MAX_DAYS\ \ \ 90/' /etc/login.defs

#TWGCB-01-008-0228
userline=($(awk -F":" '{if($3>=1000 && $3<=10000){print $1}}' /etc/passwd)) ; usernumber=`awk -F":" '{if($3>=1000 && $3<=10000){print $1}}' /etc/passwd | wc -l` ; for (( a=0;a<$usernumber;a++ )) ; do chage --mindays 60 ${userline[$a]} ; chage --warndays 14 ${userline[$a]} ; chage --maxdays 90 ${userline[$a]} ; chage --inactive 30 ${userline[$a]} ; done

#TWGCB-01-008-0229 bug
#grep "FAIL_DELAY" /etc/login.defs ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then sed -i '$a\FAIL_DELAY 4' /etc/login.defs  ;fi
sed -i '/FAIL_DELAY/s/^/#/' /etc/login.defs && sed -i '$a\FAIL_DELAY 4' /etc/login.defs

#TWGCB-01-008-0230
sed -i '/^CREATE_HOME/s/CRWEATE_HOME\s+*.*/CREATE_HOME\ \ \ \ \ yes/' /etc/login.defs

#TWGCB-01-008-0231
sed -i '/NOPASSWD/s/^/#/' /etc/sudoers

#TWGCB-01-008-0232
sed -i '/maxlogins/s/^/#/' /etc/security/limits.conf && sed -i '$a\\*\ hard\  maxlogins\ 10' /etc/security/limits.conf

#TWGCB-01-008-0233
dnf install kbd.x86_64

#TWGCB-01-008-0234,0235
#/etc/dconf/db/local.d/00-screensaver
#[org/gnome/desktop/screensaver]
##Set this to true to lock the screen when the screensaver activates
#lock-enabled=true

#[org/gnome/desktop/session]
##Set the lock time out to 900 seconds before the session is considered idle
#idle-delay=uint32 900

#dconf update

#
echo '定義全局變數或全局目標檔案路徑' &> /dev/null
backup_dir="/root/scripts/gcb/1_Basic_Account-and-AccessControl_v1.2/backup/TWGCB-01-008-0234/$(date +"%Y%m%d")"


echo '創建備份目錄' &> /dev/null
if [ ! -d "$backup_dir" ]; then
        mkdir -p $backup_dir
fi


echo '檢查' &> /dev/null
CHECK=$(ls -l /etc/dconf/db/local.d/00-screensaver 2> /dev/null|wc -l)

if [ "$CHECK" == "0" ]; then
	echo -e "TWGCB-01-008-0234-0233 排除 (系統非圖形介面，不用設定)"
	echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0234-0233：系統非圖形介面，不用設定。" >> $backup_dir/gcb.log
        echo -e " 結果：TWGCB-01-008-0234-0233 排除\n" >> $backup_dir/gcb.log
	exit 0
else
	echo -e "TWGCB-01-008-0234 \x1b[33;1m(手動設定)\x1b[0m"
	echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0234-0233：需手動設定。" >> $backup_dir/gcb.log
	echo -e " 結果：TWGCB-01-008-0234-0233 \x1b[33;1m(手動設定)\x1b[0m\n" >> $backup_dir/gcb.log
	exit 0
fi


echo '備份檔案函數' &> /dev/null


echo '備份目標檔案' &> /dev/null


echo '設定' &> /dev/null


echo '設定後檢查' &> /dev/null



#TWGCB-01-008-0236 
	#編輯/etc/gdm/custom.conf檔案，在「daemon]」段落，新增或修改成以下內容：
	#[daemon]
	#AutomaticLoginEnable=false
	
#TWGCB-01-008-0237
awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $1!~/^\+/ && $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"' && $7!="'"$(which nologin)"'" && $7!="/bin/false") {print $1}' /etc/passwd | while read user; do usermod -s $(which nologin) $user; done
awk -F: '($1!="root" && $1!~/^\+/ && $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"') {print $1}' /etc/passwd | xargs -I '{}' passwd -S '{}' | awk '($2!="L" && $2!="LK") {print $1}' | while read user; do usermod -L $user; done

#TWGCB-01-008-0238
[ -f /etc/profile.d/tmout.sh ] || echo -e '#!/bin/bash\nreadonly TMOUT=900;export TMOUT' >> /etc/profile.d/tmout.sh

#TWGCB-01-008-0239
	#▪ 開啟終端機，執行以下指令，建立或編輯資料庫，設定防止修改圖形使用者介面(GUI)設定：
	##vim /etc/dconf/db/local.d/locks/session
	#▪ 編輯資料庫，新增或修改成以下內容：
	#/org/gnome/desktop/session/idle-delay
	#/org/gnome/desktop/screensaver/lock-enabled
	#/org/gnome/desktop/screensaver/lock-delay
	#/org/gnome/desktop/lockdown/disable-lock-screen
	# dconf update
#TWGCB-01-008-0240
usermod -g 0 root

#TWGCB-01-008-0241
grep -iw "umask\ 022" /etc/profile ; tmp_fin=$? ; if [ $tmp_fin == 0 ] ;then sed -i '/umask\ 022/s/022/027/' /etc/profile ; fi

#TWGCB-01-008-0242
grep -iw "^UMASK" /etc/login.defs ; tmp_fin=$? ; if [ $tmp_fin == 0 ] ;then sed -i '/^UMASK/s/022/027/' /etc/login.defs ; fi

#TWGCB-01-008-0243
grep -iw "pam\_wheel\.so\ use\_uid" /etc/pam.d/su ; tmp_fin=$? ; if [ $tmp_fin == 0 ] ;then sed -i '/pam\_wheel\.so\ use\_uid/s/^#//' /etc/pam.d/su ; fi



echo 'TWGCB-01-008-0208~0209、0220~0222、0224 check' >> 1-9.log
echo 'grep 'retry\|enforce_for_root\|deny\|unlock\|remember\|sha512' /etc/pam.d/system-auth /etc/pam.d/password-auth' >> 1-9.log
grep 'retry\|enforce_for_root\|deny\|unlock\|remember\|sha512' /etc/pam.d/system-auth /etc/pam.d/password-auth >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0210~0219 check' >> 1-9.log
echo 'cat /etc/security/pwquality.conf|grep 'minlen\|minclass\|dcredit\|ucredit\|lcredit\|ocredit\|difok\|maxclassrepeat\|maxrepeat\|dictcheck'' >> 1-9.log
cat /etc/security/pwquality.conf|grep 'minlen\|minclass\|dcredit\|ucredit\|lcredit\|ocredit\|difok\|maxclassrepeat\|maxrepeat\|dictcheck' >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0223 check' >> 1-9.log
echo 'cat /etc/pam.d/postlogin|grep pam_lastlog' >> 1-9.log
cat /etc/pam.d/postlogin|grep pam_lastlog >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0224~0230、0242 check' >> 1-9.log
echo 'cat /etc/login.defs|grep 'PASS_MIN_DAYS\|PASS_WARN_AGE\|PASS_MAX_DAYS\|FAIL_DELAY\|CREATE_HOME\|UMASK\|ENCRYPT'' >> 1-9.log
cat /etc/login.defs|grep 'PASS_MIN_DAYS\|PASS_WARN_AGE\|PASS_MAX_DAYS\|FAIL_DELAY\|CREATE_HOME\|UMASK\|ENCRYPT' >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0231 check' >> 1-9.log
echo 'cat /etc/sudoers|grep NOPASSWD' >> 1-9.log
cat /etc/sudoers|grep NOPASSWD >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0232 check' >> 1-9.log
echo 'cat /etc/security/limits.conf|grep maxlogins' >> 1-9.log
cat /etc/security/limits.conf|grep maxlogins >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0233 check' >> 1-9.log
echo 'rpm -qa|grep kbd' >> 1-9.log
rpm -qa|grep kbd >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0234,0235 check' >> 1-9.log
echo 'cat /etc/dconf/db/local.d/00-screensaver' >> 1-9.log
cat /etc/dconf/db/local.d/00-screensaver >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0236 check' >> 1-9.log
echo 'cat /etc/gdm/custom.conf' >> 1-9.log
cat /etc/gdm/custom.conf >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0237 check' >> 1-9.log
echo 'cat /etc/passwd|grep -v nologin' >> 1-9.log
cat /etc/passwd|grep -v nologin >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0238 check' >> 1-9.log
echo 'cat /etc/profile.d/tmout.sh' >> 1-9.log
cat /etc/profile.d/tmout.sh >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0239 check' >> 1-9.log
echo 'cat /etc/dconf/db/local.d/locks/session' >> 1-9.log
cat /etc/dconf/db/local.d/locks/session >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0240 check' >> 1-9.log
echo 'cat /etc/group|grep root' >> 1-9.log
cat /etc/group|grep root >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0241 check' >> 1-9.log
echo 'cat /etc/profile|grep umask' >> 1-9.log
cat /etc/profile|grep umask >> 1-9.log
echo "" >> 1-9.log

echo 'TWGCB-01-008-0243 check' >> 1-9.log
echo 'cat /etc/pam.d/su|grep wheel' >> 1-9.log
cat /etc/pam.d/su|grep wheel >> 1-9.log
echo "" >> 1-9.log






sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################








            show_menu;
        ;;
        10) clear;
            option_picked "Option 10 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo



#
echo '定義全局變數或全局目標檔案路徑' &> /dev/null
backup_dir="/root/scripts/gcb/1_Basic_Log-and-Audit_v1.2/backup/TWGCB-01-008-0171/$(date +"%Y%m%d")"
FILE=/etc/audit/rules.d/audit.rules
CHECK="^\s*-w\s+/var/log/faillock\s+-p\s+wa\s+-k\s+logins"


echo '創建備份目錄' &> /dev/null
if [ ! -d "$backup_dir" ]; then
	mkdir -p "$backup_dir"
fi


echo '檢查' &> /dev/null
if [ -f "$FILE" ]; then
	if grep -Eq "$CHECK" "$FILE"; then
		echo -e "TWGCB-01-008-0171 OK (沒有設定改變)"
		echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0171：沒有設定改變。" >> $backup_dir/gcb.log
		echo -e " 結果：TWGCB-01-008-0171 OK\n" >> $backup_dir/gcb.log
		exit 0
	fi
else
	echo -e "\x1b[31;1mTWGCB-01-008-0171 FAIL (沒有$FILE檔案)\x1b[0m"
        echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0171：沒有$FILE檔案。" >> $backup_dir/gcb.log
        echo -e " \x1b[31;1m結果：TWGCB-01-008-0171 FAIL\x1b[0m\n" >> $backup_dir/gcb.log
        exit 1
fi


echo '備份檔案函數' &> /dev/null
backup_file() {
	local file="$1"
	cp -i "$file" "$backup_dir/$(basename $file).$(date +%Y-%m-%d-%H%M%S)"
}


echo '備份目標檔案' &> /dev/null
if [ -f "$FILE" ]; then
	backup_file $FILE
fi
echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0171：\n - 備份$FILE檔案於$backup_dir目錄。" >> $backup_dir/gcb.log


echo '設定' &> /dev/null
if grep -Eq "^\s*##GCB" $FILE; then
	sed -ri "/^\s*##GCB/a\\#TWGCB-01-008-0171" $FILE
	sed -ri "/^\s*#TWGCB-01-008-0171/a\\-w /var/log/faillock -p wa -k logins" $FILE
	echo " - 在$FILE檔案中設定-w /var/log/faillock -p wa -k logins。" >> $backup_dir/gcb.log
else
	echo "" >> $FILE
	echo "##GCB" >> $FILE
	echo "#TWGCB-01-008-0171" >> $FILE
	echo "-w /var/log/faillock -p wa -k logins" >> $FILE
	echo " - 在$FILE檔案中設定-w /var/log/faillock -p wa -k logins。" >> $backup_dir/gcb.log
fi
augenrules --load > /dev/null
RESULT=$(auditctl -s|grep "enabled")
echo " - 執行augenrules --load" >> $backup_dir/gcb.log
echo " - 執行auditctl -s|grep "enabled"顯示$RESULT" >> $backup_dir/gcb.log


echo '設定後檢查' &> /dev/null
if grep -Eq "$CHECK" $FILE; then
	if [ "$RESULT" = "enabled 1" ]; then
		echo -e "TWGCB-01-008-0171 OK (設定成功)"
		echo -e " 結果：TWGCB-01-008-0171 OK (設定成功)\n" >> $backup_dir/gcb.log
		exit 0
	else
		echo -e "TWGCB-01-008-0171 OK \x1b[33;1m(設定成功，需重新開機使設定生效)\x1b[0m"
		echo -e " 結果：TWGCB-01-008-0171 OK \x1b[33;1m(設定成功，需重新開機使設定生效)\x1b[0m\n" >> $backup_dir/gcb.log
		exit 0
	fi
else
	echo -e "\x1b[31;1mTWGCB-01-008-0171 FAIL (設定失敗)\x1b[0m"
	echo -e " \x1b[31;1m結果：TWGCB-01-008-0171 FAIL (設定失敗)\x1b[0m\n" >> $backup_dir/gcb.log
	exit 1
fi



sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################







            show_menu;
        ;;
        11) clear;
            option_picked "Option 11 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo




echo '定義目標檔案路徑' &> /dev/null
backup_dir="/root/scripts/gcb/1_Basic_Log-and-Audit_v1.2/backup/TWGCB-01-008-0145/$(date +"%Y%m%d")"
FILE=/etc/aide.conf
CHECK=$(echo /usr/sbin/auditctl /usr/sbin/aureport /usr/sbin/ausearch /usr/sbin/autrace /usr/sbin/auditd /usr/sbin/audisp-remote /usr/sbin/audisp-syslog /usr/sbin/augenrules /usr/sbin/rsyslogd 2> /dev/null|wc -l)
COMMAND=$(echo /usr/sbin/auditctl /usr/sbin/aureport /usr/sbin/ausearch /usr/sbin/autrace /usr/sbin/auditd /usr/sbin/audisp-remote /usr/sbin/audisp-syslog /usr/sbin/augenrules /usr/sbin/rsyslogd 2> /dev/null)


echo '創建備份目錄' &> /dev/null
if [ ! -d "$backup_dir" ]; then
	mkdir -p $backup_dir
fi


echo '檢查' &> /dev/null
if [ -f "$FILE" ]; then
	num=0
	for i in $COMMAND; do
		if grep -Eq "^\s*$i\s+p\+i\+n\+u\+g\+s\+b\+acl\+xattrs\+sha512" "$FILE"; then
			((num++))
		fi
	done
else
	echo -e "\x1b[31;1mTWGCB-01-008-0145 FAIL (沒有$FILE檔案)\x1b[0m"
	echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0145：沒有$FILE檔案。" >> "$backup_dir"/gcb.log
	echo -e " \x1b[31;1m結果：TWGCB-01-008-0145 FAIL\x1b[0m\n" >> $backup_dir/gcb.log
	exit 1
fi

if [ "$num" == "$CHECK" ]; then
	echo -e "TWGCB-01-008-0145 OK (沒有設定改變)"
	echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0145：沒有設定改變。" >> $backup_dir/gcb.log
	echo -e " 結果：TWGCB-01-008-0145 OK\n" >> $backup_dir/gcb.log
	exit 0
fi


echo '備份檔案函數' &> /dev/null
backup_file() {
	local file="$1"
	cp -i "$file" "$backup_dir/$(basename $file).$(date +%Y-%m-%d-%H%M%S)"
}


echo '備份目標檔案' &> /dev/null
if [ -f "$FILE" ]; then
	backup_file $FILE
fi
echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0145：\n - 備份$FILE檔案於$backup_dir目錄。" >> $backup_dir/gcb.log


echo '設定' &> /dev/null
if grep -Eq "^\s*##GCB" $FILE; then
	sed -ri "/^\s*##GCB/a\\#TWGCB-01-008-0145" $FILE
	for i in $COMMAND; do
		if ! grep -Eq "^\s*$i\s+p\+i\+n\+u\+g\+s\+b\+acl\+xattrs\+sha512" $FILE; then
			sed -ri "/^\s*#TWGCB-01-008-0145/a\\$i p+i+n+u+g+s+b+acl+xattrs+sha512" $FILE
			echo "\'$i p+i+n+u+g+s+b+acl+xattrs+sha512\'" >> /tmp/TWGCB-01-008-0145.txt
		fi
	done
else
	echo "" >> $FILE
	echo "##GCB" >> $FILE
	sed -ri "/^\s*##GCB/a\\#TWGCB-01-008-0145" $FILE
	for i in $COMMAND; do
		if ! grep -Eq "^\s*$i\s+p\+i\+n\+u\+g\+s\+b\+acl\+xattrs\+sha512" $FILE; then
			sed -ri "/^\s*#TWGCB-01-008-0145/a\\$i p+i+n+u+g+s+b+acl+xattrs+sha512" $FILE
			echo "\'$i p+i+n+u+g+s+b+acl+xattrs+sha512\'" >> /tmp/TWGCB-01-008-0145.txt
		fi
	done
fi
echo " - 在$FILE檔案中新增$(cat /tmp/TWGCB-01-008-0145.txt|xargs)內容。" >> $backup_dir/gcb.log
rm -f /tmp/TWGCB-01-008-0145.txt


echo '設定後檢查' &> /dev/null
num=0

for i in $COMMAND; do
	if grep -Eq "^\s*$i\s+p\+i\+n\+u\+g\+s\+b\+acl\+xattrs\+sha512" $FILE; then
	((num++))
	fi
done

if [ "$num" == "$CHECK" ]; then
	echo -e "TWGCB-01-008-0145 OK (設定成功)"
	echo -e " 結果：TWGCB-01-008-0145 OK (設定成功)\n" >> $backup_dir/gcb.log
	exit 0
else
	echo -e "\x1b[31;1mTWGCB-01-008-0145 FAIL (設定失敗)\x1b[0m"
	echo -e " \x1b[31;1m結果：TWGCB-01-008-0145 FAIL (設定失敗)\x1b[0m\n" >> $backup_dir/gcb.log
	exit 1
fi























sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################








            show_menu;
        ;;
        12) clear;
            option_picked "Option 12 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo






#TWGCB-01-008-0037

#
echo '定義全局變數或全局目標檔案路徑' &> /dev/null
backup_dir="/root/scripts/gcb/1_Basic_Disks-and-FileSystems_v1.2/backup/TWGCB-01-008-0027/$(date +"%Y%m%d")"
FILE=/etc/fstab


echo '創建備份目錄' &> /dev/null
if [ ! -d "$backup_dir" ]; then
	mkdir -p "$backup_dir"
fi


echo '檢查' &> /dev/null
# 遍历提取的行
nfs_lines=$(awk '$3=="nfs"' "$FILE")
missing_nosuid=0

while IFS= read -r line; do
	if [ -n "$line" ]; then
		if ! echo "$line" | grep -q '\bnosuid\b'; then
			((missing_nosuid++))
		fi
	fi
done <<< "$nfs_lines"

if [ "$missing_nosuid" -eq 0 ]; then
	echo "TWGCB-01-008-0027 OK (沒有設定改變)"
	echo -e "$(date +%Y-%m-%d\ %T)  TWGCB-01-008-0027：沒有設定改變。" >> "$backup_dir"/gcb.log
	echo -e " 結果：TWGCB-01-008-0027 OK\n" >> "$backup_dir"/gcb.log
	exit 0
fi





















sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################








            show_menu;
        ;;
        13) clear;
            option_picked "Option 13 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo




#TWGCB-01-008-0244~0248
dnf install firewalld
systemctl --now enable firewalld
systemctl --now mask iptables
systemctl --now mask nftables
firewall-cmd --set-default-zone=public

echo 'TWGCB-01-008-0244' >> 2-1.log
echo 'rpm -qa|grep firewalld' >> 2-1.log
rpm -qa|grep firewalld >> 2-1.log
echo "" >> 2-1.log
echo 'TWGCB-01-008-0245' >> 2-1.log
echo 'systemctl status firewalld' >> 2-1.log
systemctl status firewalld >> 2-1.log
echo "" >> 2-1.log
echo 'TWGCB-01-008-0246' >> 2-1.log
echo 'systemctl status iptables' >> 2-1.log
systemctl status iptables >> 2-1.log
echo "" >> 2-1.log
echo 'TWGCB-01-008-0247' >> 2-1.log
echo 'systemctl status nftables' >> 2-1.log
systemctl status nftables >> 2-1.log
echo "" >> 2-1.log
echo 'TWGCB-01-008-0248' >> 2-1.log
echo 'firewall-cmd --get-default-zone' >> 2-1.log
firewall-cmd --get-default-zone >> 2-1.log
echo "" >> 2-1.log























sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################








            show_menu;
        ;;
        14) clear;
            option_picked "Option 14 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo






#TWGCB-01-008-0244~0262
#244

#TWGCB-01-008-0132~0133
#dnf install audit audit-libs -y
systemctl --now enable auditd

dnf install firewalld



#245
systemctl --now enable firewalld
dnf install openssh-server.x86_64
systemctl --now enable sshd.service

#TWGCB-01-008-0263
grep -iw "Protocol\ 2" /etc/ssh/sshd_config ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e 'Protocol 2' >> /etc/ssh/sshd_config ; fi

#TWGCB-01-008-0264~0265
chown root:root /etc/ssh/sshd_config
chmod 600 /etc/ssh/sshd_config

#TWGCB-01-008-0266 需手動設定帳號
#echo "AllowUsers zz0001 zz0002 zz0003 zz0004 zz0005 zz0006 zz0007 zz0008 zz0009 zz0010 ap0001 ap0002 ap0003 ap0004 ap0005 ap0006 ap0007 ap0008 ap0009 ap0010" >> /etc/ssh/sshd_config
#echo "AllowUsers fiaitwroot" >> /etc/ssh/sshd_config

#TWGCB-01-008-0267~0270
#TWGCB-01-012-0260 (Alan修改為RED9)
#為Redhat8 find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec chown root:root {} \;
find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec chown root:ssh_keys {} \;
#TWGCB-01-012-0261 (Alan修改為RED9)
#為Redhat8 find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec chmod 600 {} \;
find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec chmod 640 {} \;
find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chown root:root {} \;
find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec chmod 644 {} \;

#TWGCB-01-008-0271 手動檢查是否已經加上
#grep -iw "Ciphers\ aes128-ctr" /etc/ssh/sshd_config ; tmp_fin=$? ; if [ $tmp_fin == 1 ] ;then echo -e 'Ciphers aes128-ctr,aes192-ctr,aes256-ctr' >> /etc/ssh/sshd_config ; fi

#TWGCB-01-008-0272~0292
sed -i '/LogLevel/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\LogLevel\ VERBOSE' /etc/ssh/sshd_config
sed -i '/X11Forwarding/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\X11Forwarding\ no' /etc/ssh/sshd_config
sed -i '/MaxAuthTries/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\MaxAuthTries\ 4' /etc/ssh/sshd_config
sed -i '/IgnoreRhosts/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\IgnoreRhosts\ yes' /etc/ssh/sshd_config
sed -i '/HostbasedAuthentication/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\HostbasedAuthentication\ no' /etc/ssh/sshd_config
sed -i '/PermitRootLogin/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\PermitRootLogin\ no' /etc/ssh/sshd_config
sed -i '/PermitEmptyPasswords/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\PermitEmptyPasswords\ no' /etc/ssh/sshd_config
sed -i '/ClientAliveInterval/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\ClientAliveInterval\ 600' /etc/ssh/sshd_config
sed -i '/ClientAliveCountMax/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\ClientAliveCountMax\ 0' /etc/ssh/sshd_config
sed -i '/LoginGraceTime/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\LoginGraceTime\ 60' /etc/ssh/sshd_config
sed -i '/UsePAM/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\UsePAM\ yes' /etc/ssh/sshd_config
sed -i '/AllowTcpForwarding/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\AllowTcpForwarding\ no' /etc/ssh/sshd_config
sed -i '/maxstartups/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\maxstartups\ 10:30:60' /etc/ssh/sshd_config
sed -i '/MaxSessions/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\MaxSessions\ 4' /etc/ssh/sshd_config
sed -i '/StrictModes/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\StrictModes\ yes' /etc/ssh/sshd_config
sed -i '/Compression/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\Compression\ no' /etc/ssh/sshd_config
sed -i '/IgnoreUserKnownHosts/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\IgnoreUserKnownHosts\ yes' /etc/ssh/sshd_config
sed -i '/PrintLastLog/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\PrintLastLog\ yes' /etc/ssh/sshd_config
sed -i '/CRYPTO_POLICY/s/^/#/' /etc/ssh/sshd_config
#0279
sed -i '/PermitUserEnvironment/s/^/#/' /etc/ssh/sshd_config && sed -i '$a\PermitUserEnvironment\ no' /etc/ssh/sshd_config
rm -rf /etc/ssh/shosts.equiv
systemctl restart sshd

#Config swappiness
sed -i '/vm\.swappiness/s/^vm\.swappiness/#vm\.swappiness/' /etc/sysctl.conf && sed -i '$a\vm\.swappiness=10' /etc/sysctl.conf
sysctl -p

#Remove weak SSH crypto-policies
sed -i "s/,aes256-cbc//g" /etc/crypto-policies/back-ends/openssh.config
sed -i "s/,aes128-cbc//g" /etc/crypto-policies/back-ends/openssh.config
echo "Ciphers aes128-ctr,aes192-ctr,aes256-ctr" >> /etc/ssh/sshd_config

echo 'TWGCB-01-008-0262' >> 2-4.log
echo 'systemctl status sshd' >> 2-4.log
systemctl status sshd >> 2-4.log
echo "" >> 2-4.log
echo 'TWGCB-01-008-0263、0266、0272~0289、0292' >> 2-4.log
echo 'cat /etc/ssh/sshd_config|grep 'Protocol\|AllowUsers\|Ciphers\|LogLevel\|X11Forwarding\|MaxAuthTries\|IgnoreRhosts\|HostbasedAuthentication\|PermitRootLogin\|PermitEmptyPasswords\|PermitUserEnvironment\|ClientAlive\|LoginGraceTime\|UsePAM\|AllowTcpForwarding\|maxstartups\|MaxSessions\|StrictModes\|Compression\|IgnoreUserKnownHosts\|PrintLastLog\|CRYPTO_POLICY'' >> 2-4.log
cat /etc/ssh/sshd_config|grep 'Protocol\|AllowUsers\|Ciphers\|LogLevel\|X11Forwarding\|MaxAuthTries\|IgnoreRhosts\|HostbasedAuthentication\|PermitRootLogin\|PermitEmptyPasswords\|PermitUserEnvironment\|ClientAlive\|LoginGraceTime\|UsePAM\|AllowTcpForwarding\|maxstartups\|MaxSessions\|StrictModes\|Compression\|IgnoreUserKnownHosts\|PrintLastLog\|CRYPTO_POLICY' >> 2-4.log
echo "" >> 2-4.log
echo 'TWGCB-01-008-0264~0265' >> 2-4.log
echo 'ls -l /etc/ssh/ssh_config' >> 2-4.log
ls -l /etc/ssh/ssh_config >> 2-4.log
echo "" >> 2-4.log
echo 'TWGCB-01-008-0267~0270' >> 2-4.log
echo 'ls -l /etc/ssh|grep key' >> 2-4.log
ls -l /etc/ssh|grep key >> 2-4.log
echo "" >> 2-4.log
echo 'TWGCB-01-008-0290' >> 2-4.log
echo 'find / -name shosts.equiv' >> 2-4.log
find / -name shosts.equiv >> 2-4.log
echo "" >> 2-4.log
echo 'TWGCB-01-008-0291' >> 2-4.log
echo 'find / -name '*.shosts'' >> 2-4.log
find / -name '*.shosts' >> 2-4.log
echo "" >> 2-4.log








sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################


### 可以再新增選項區域 2024/11/24
#            show_menu;
#        ;;
#        5) clear;
#            option_picked "Option 4 Picked";
######################################################################################################
#echo
#echo "#########################################################################"
#echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
#echo "#########################################################################"
#echo
#echo "Starting in 3 seconds"
#sleep 1
#echo "2"
#sleep 1
#echo "1"
#sleep 1
#START=$(date +%s)
#echo
#echo "#########################################################################"
#echo
#####輸入地方
#sleep 1
#echo "#########################################################################"
#echo
#END=$(date +%s)
#DIFF=$(( $END - $START ))
#echo "Script completed in" $DIFF "seconds"
#echo
#echo "Executed on :"
#echo
#echo "Check GCB hostname is" $HOSTNAME
#date
#echo
#echo "#########################################################################"
#echo
##############################END########################################################################









######################################################################################################
            show_menu;
		;;	
	    99) clear;
            option_picked "Option 99 Picked";
######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 1. Red Hat Enterprise Linux 9 Server GCB Check/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo
####################################### Red Hat 9 SYSTEM AND SECURITY CHECK #######################################

audit01=`awk '$1 == "install" && $2 == "cramfs" && $3 == "/bin/true"'  /etc/modprobe.d/cramfs.conf  | grep -q "install cramfs /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "cramfs"'  /etc/modprobe.d/cramfs.conf  | grep -q "blacklist cramfs" && echo 0 || echo 1`
audit03=`lsmod | grep cramfs &> /dev/null | grep -q "cramfs" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0001 rmmod cramfs is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0001 should be different to rmmod cramfs "
    fi

audit01=`awk '$1 == "install" && $2 == "squashfs" && $3 == "/bin/true"' /etc/modprobe.d/squashfs.conf | grep -q "install squashfs /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "squashfs"' /etc/modprobe.d/squashfs.conf  | grep -q "blacklist squashfs" && echo 0 || echo 1`
audit03=`lsmod | grep squashfs  | grep -q "squashfs" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0002 rmmod squashfs is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0002 should be different to rmmod squashfs "
    fi

audit01=`awk '$1 == "install" && $2 == "udf" && $3 == "/bin/true"' /etc/modprobe.d/udf.conf  | grep -q "install udf /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "udf"' /etc/modprobe.d/udf.conf  | grep -q "blacklist udf"  && echo 0 || echo 1`
audit03=`lsmod | grep udf | grep -q "udf"  && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0003 rmmod udf is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0003 should be different to rmmod udf "
    fi
	
audit01=`awk '$1 == "tmpfs" && $2 == "/tmp" && $3 == "tmpfs" && $4 == "defaults,rw,nosuid,nodev,noexec,relatime" && $5 == "0" && $6 == "0" ' /etc/fstab`
tmpfs01=`df "/tmp" | grep -q "tmpfs" && echo 0 || echo 1`
    if [ "$audit01" == "tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0" ] && [ "$tmpfs01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0004-0007 tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0004-0007 should be different to tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0"
    fi
	
tmpfs01=`lvs -o name | grep -q "var" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0008 /var is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0008 should be different to /var is not LVM "
    fi

tmpfs01=`lvs -o name | grep -q "var_tmp" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0009 /var/tmp is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0009 should be different to /var/tmp is not LVM "
    fi

audit01=`awk '$2 == "/var/tmp" && $4 ' /etc/fstab | grep -q "nodev" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0010 /var/tmp ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0010 should be different to /var/tmp ckeck add nodev"
    fi

audit01=`awk '$2 == "/var/tmp" && $4 ' /etc/fstab | grep -q "nosuid" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0011 /var/tmp ckeck add nosuid is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0011 should be different to /var/tmp ckeck add nosuid"
    fi

audit01=`awk '$2 == "/var/tmp" && $4 ' /etc/fstab | grep -q "noexec" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0012 /var/tmp ckeck add noexec is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0012 should be different to /var/tmp ckeck add noexec"
    fi

tmpfs01=`lvs -o name | grep -q "var_log" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0013 /var/log is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0013 should be different to /var/log is not LVM "
    fi

tmpfs01=`lvs -o name | grep -q "var_log_audit" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0014 /var/log/audit is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0014 should be different to /var/log/audit is not LVM "
    fi

tmpfs01=`lvs -o name | grep -q "home" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0015 /home is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0015 should be different to /home is not LVM "
    fi

audit01=`awk '$2 == "/home" && $4 ' /etc/fstab | grep -q "nodev" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0016 /home ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0016 should be different to /home ckeck add nodev"
    fi

audit01=`awk '$2 == "/dev/shm" && $4 ' /etc/fstab | grep -q "nodev" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0017 /dev/shm ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0017 should be different to /dev/shm ckeck add nodev"
    fi
	
audit01=`awk '$2 == "/dev/shm" && $4 ' /etc/fstab | grep -q "nosuid" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0018 /dev/shm ckeck add nosuid is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0018 should be different to /dev/shm ckeck add nosuid"
    fi
	
audit01=`awk '$2 == "/dev/shm" && $4 ' /etc/fstab | grep -q "noexec" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0019 /dev/shm ckeck add noexec is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0019 should be different to /dev/shm ckeck add noexec"
    fi
	
audit01=`mount | grep "/dev/sr" && echo 0 || echo 1`
audit02=`mount | grep /dev/sr | grep -q "nodev" && echo 0 || echo 1`
    if [ "$audit01" == "1" ] ; then
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0020 no /dev/sr* device "
    elif [ "$audit02" == "0" ] ; then
		echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0020 /dev/sr* ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0020 should be different to no /dev/sr* ckeck add nodev "
    fi
	
audit01=`mount | grep "/dev/sr" && echo 0 || echo 1`
audit02=`mount | grep /dev/sr | grep -q "nosuid" && echo 0 || echo 1`
    if [ "$audit01" == "1" ] ; then
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0021 no /dev/sr* device "
    elif [ "$audit02" == "0" ] ; then
		echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0021 /dev/sr* ckeck add nosuid is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0021 should be different to no /dev/sr* ckeck add nosuid "
    fi
	
audit01=`mount | grep "/dev/sr" && echo 0 || echo 1`
audit02=`mount | grep /dev/sr | grep -q "noexec" && echo 0 || echo 1`
    if [ "$audit01" == "1" ] ; then
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0022 no /dev/sr* device "
    elif [ "$audit02" == "0" ] ; then
		echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0022 /dev/sr* ckeck add noexec is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0022 should be different to no /dev/sr* ckeck add noexec "
    fi
	
audit02=`grep -q -P '^(?=.*/home/*)(?=.*nodev)(?=.*noexec)(?=.*nosuid)' /etc/fstab && echo 0 || echo 1`
    if [ "$audit02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0023-0025 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0023-0025 check is error"
    fi
	
 audit01=`awk '$3 == "nfs"' /etc/fstab | grep -q -P '^(?=.*nodev)(?=.*noexec)(?=.*nosuid)' && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0026-28 nfs ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0026-28 should be different to nfs ckeck add nodev (可排外，如無掛載NFS)"
    fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a -perm -1000 \)`
    if [ -z cramfs08 ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0029 check World-writable ok"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0029 具有全域寫入(World-writable)權限之目錄是需設定粘滯位 (可排外,確保只有擁有者才能刪除或更名自己建立之檔案，以防止使用者任意刪除或更名其他使用者所建立之檔案)" 
	fi
	
autofs01=`systemctl is-active autofs`
    if [ "$autofs01" == "inactive" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0030 "should be different to autofs Disable
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0030 should be different to autofs start for autofs.service"
    fi
	
audit01=`awk '$1 == "install" && $2 == "usb-storage" && $3 == "/bin/true"'  /etc/modprobe.d/usb-storage.conf  | grep -q "install usb-storage /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "usb-storage"'  /etc/modprobe.d/usb-storage.conf  | grep -q "blacklist usb-storage" && echo 0 || echo 1`
audit03=`lsmod | grep  usb-storage  | grep -q "usb-storage" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0031 rmmod usb-storage is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0031 should be different to rmmod usb-storage "
    fi
	
###	TWGCB-01-012-0032 ####
#1
FRUIT=`if [ -f "/etc/yum.conf" ] && [ -f "/etc/dnf/dnf.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    SSHTEST01=$(grep -i '^[[:space:]]*gpgcheck[[:space:]]*=' /etc/yum.conf | awk -F= '{gsub(/[    ]/, "", $2); print $2}')
    SSHTEST02=$(grep -i '^[[:space:]]*gpgcheck[[:space:]]*=' /etc/dnf/dnf.conf | awk -F= '{gsub(/[    ]/, "", $2); print $2}')
    if [ "$SSHTEST01" == "1" ] && [ "$SSHTEST02" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0032 gpgcheck = 1"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0032 no gpgcheck = 1"
    fi

    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0032 no gpgcheck = 1"
   
   ;;
esac

###	TWGCB-01-012-0032 ####

audit01=`rpm -q sudo | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0033 install sudo"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0033 should be different to dnf install sudo"
    fi

SSHTEST01=`grep -i "Defaults     use_pty" /etc/sudoers | grep -q -v "#" && echo 0 || echo 1`
    if [ "$SSHTEST01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0034 /etc/sudoers Defaults use_pty  ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0034 /etc/sudoers should be set to Defaults use_pty (手動設定)"
    fi
	
SSHTEST01=`awk ' /^[[:space:]]*Defaults     logfile[[:space:]]*=[[:space:]]*/{print}' /etc/sudoers |grep -i "/var/log/sudo.log" | grep -q -v ^# && echo 0 || echo 1`
    if [ "$SSHTEST01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0035 /etc/sudoers Defaults logfile  ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0035 /etc/sudoers should be set to Defaults logfile (手動設定)"
    fi

audit01=`rpm -q aide | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0036 install aide"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0036 should be different to dnf install aide"
    fi
	
cramfs01=$(crontab -l | awk '{print $1 $2 $3 $4 $5 $6 $7}' | grep -q '[0-9].*'***/usr/sbin/aide--check && echo 0 || echo 1)
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0037 Check 05***/usr/sbin/aide--check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0037 no 05***/usr/sbin/aide--check"
    fi
cramfs01=$(ls -l /boot/grub2/grub.cfg | awk '{print $3 ":" $4}')
cramfs02=$(ls -l /boot/grub2/grubenv | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] && [ "$cramfs02" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0038 Check /var/log/messages is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0038 no root:root"
    fi	
	
###	TWGCB-01-012-0039 ####
#1
FRUIT=`if [ -f "/boot/grub2/grub.cfg" ] && [ -f "/boot/grub2/grubenv" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /boot/grub2/grub.cfg)
	cramfs02=$(stat -c %a /boot/grub2/grubenv)
    if [ $cramfs01 -le "600" ] && [ $cramfs02 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0039 Check /boot/grub2/grubenv /boot/grub2/grub.cfg is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0039 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0039 no /boot/grub2/grubenv /boot/grub2/grub.cfg"
   
   ;;
esac

###	TWGCB-01-012-0039 ####

#https://bhanuwriter.com/how-to-set-grub2-password/
    if [ -f "/boot/grub2/user.cfg" ] ; then   echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0040 grub2-setpassword建立一組通行碼 OK" ; else   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0040 no grub2-setpassword建立一組通行碼 ok"; fi

SSHTEST01=$(grep -i '^[[:space:]]*ExecStart[[:space:]]*=' /usr/lib/systemd/system/rescue.service | awk -F= '{gsub(/[    ]/, "", $2); print $2}')
SSHTEST02=$(grep -i '^[[:space:]]*ExecStart[[:space:]]*=' /usr/lib/systemd/system/emergency.service | awk -F= '{gsub(/[    ]/, "", $2); print $2}')
    if [ "$SSHTEST01" == "-/usr/lib/systemd/systemd-sulogin-shellrescue" ] && [ "$SSHTEST02" == "-/usr/lib/systemd/systemd-sulogin-shellemergency" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0041 check ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0041 error"
    fi
	
SSHTEST01=$(grep -q -i '^[*]'"               hard    core            0" /etc/security/limits.conf && echo 0 || echo 1)
SSHTEST02=$(grep -q -i "fs.suid_dumpable=0" /etc/sysctl.conf && echo 0 || echo 1)
SSHTEST03=$(grep -q -i "Storage=none" /etc/systemd/coredump.conf && echo 0 || echo 1)
SSHTEST04=$(grep -q -i "ProcessSizeMax=0" /etc/systemd/coredump.conf && echo 0 || echo 1)
    if [ "$SSHTEST01" == "0" ] && [ "$SSHTEST02" == "0" ] && [ "$SSHTEST03" == "0" ] && [ "$SSHTEST04" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0042 check ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0042 error (可設定)"
    fi
	
SSHTEST01=$(grep -q -i "kernel.randomize_va_space=2" /etc/sysctl.conf && echo 0 || echo 1)
    if [ "$SSHTEST01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0043 check ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0043 error (可設定)"
    fi
	
SSHTEST=$(grep -q -E -i '^\s*(FUTURE|FIPS)\s*(\s+#.*)?$' /etc/crypto-policies/config && echo 0 || echo 1)
    if [ "$SSHTEST" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0044 Check ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0044 error (排外，會影響Client無法使用YUM)"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/passwd)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0045 /etc/passwd Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0045 /etc/passwd should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/passwd)
    if [ $SSHTEST -le "644" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0046 /etc/passwd Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0046 /etc/passwd should be set to 644 或 以下'"
    fi

SSHTEST=$(stat -c '%U':'%G' /etc/shadow)
SHADOW=$(stat -c '%U':'%G' /etc/shadow)
    if [ "$SSHTEST" == "root:root" -o "$SHADOW" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0047 /etc/shadow Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0047 /etc/shadow should be set to root:root or root:shadow'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/shadow)
    if [ $SSHTEST == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0048 /etc/shadow Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0048 /etc/shadow should be set to 000'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/group)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0049 /etc/group Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0049 /etc/group should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/group)
    if [ $SSHTEST -le "644" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0050 /etc/group Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0050 /etc/group should be set to 644 或 以下'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/gshadow)
SHADOW=$(stat -c '%U':'%G' /etc/gshadow)
    if [ "$SSHTEST" == "root:root" -o "$SHADOW" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0051 /etc/gshadow Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0051 /etc/gshadow should be set to root:root or root:shadow'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/gshadow)
    if [ $SSHTEST == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0052 /etc/gshadow Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0052 /etc/gshadow should be set to 000'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/passwd-)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0053 /etc/passwd- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0053 /etc/passwd- should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/passwd-)
    if [ $SSHTEST -le "644" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0054 /etc/passwd- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0054 /etc/passwd- should be set to 644 或 以下'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/shadow-)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0055 /etc/shadow- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0055 /etc/shadow- should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/shadow-)
    if [ $SSHTEST == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0056 /etc/shadow- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0056 /etc/shadow- should be set to 000'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/group-)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0057 /etc/group- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0057 /etc/group- should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/group-)
    if [ $SSHTEST -le "644" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0058 /etc/group- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0058 /etc/group- should be set to 644 或 以下'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/gshadow-)
SHADOW=$(stat -c '%U':'%G' /etc/gshadow-)
    if [ "$SSHTEST" == "root:root" -o "$SHADOW" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0059 /etc/gshadow- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0059 /etc/gshadow- should be set to root:root or root:shadow'"
    fi
	
cramfs01=$(stat -c %a /etc/gshadow-)
    if [ $cramfs01 -le "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0060 Check /etc/gshadow- is 0 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0060 no 0"
    fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type f \( -perm -0002 -print \)`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0061 無，具有全域寫入權限之(World-writable)之檔案"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0061 有，針對所找到之檔案，執行chmod o-w指令，以移除其他身分寫入權限" 
	fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -nouser`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0062 無，找出擁有者不是合法user之檔案或目錄"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0062 有，找出擁有者不是合法user之檔案或目錄" 
	fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -nogroup`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0063 無，找出擁有群組不是合法群組之檔案或目錄"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0063 有，找出擁有群組不是合法群組之檔案或目錄" 
	fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -uid +999 -print \)`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0064 無，具有全域寫入權限目錄之擁有者"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0064 有，具有全域寫入權限目錄之擁有者" 
	fi

cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -gid +999 -print \)`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0065 無，具有全域寫入權限之目錄擁有群組為root或其他系統群組"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0065 有，具有全域寫入權限之目錄擁有群組為root或其他系統群組" 
	fi
	
SSHTEST01=$(find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 755 ]; then echo $perm; exit 0; fi' \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0066 is 755 "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0066 should be set to chmod 755"
    fi

SSHTEST01=$(find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -user root -exec sh -c 'owner=$(ls -ld "$1" | awk "{print \$3}"); if [ "$owner" != "root" ]; then echo $owner; exit 0; else exit 1; fi' sh {} \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0067 is root "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0067 should be set to chown root"
    fi
	
SSHTEST01=$(find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -group root ! -group tty ! -group slocate ! -group lock -exec sh -c 'group=$(ls -ld "$1" | awk "{print \$4}"); if [ "$group" != "root" ]; then echo $group; exit 0; else exit 1; fi' sh {} \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0068 is root "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0068 should be set to chgrp root"
    fi
	
SSHTEST01=$(find /usr/lib /usr/lib64 -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 755 ]; then echo $perm; exit 0; fi' \; -quit)
SSHTEST02=$(find /usr/lib64 -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 755 ]; then echo $perm; exit 0; fi' \; -quit)    
    if [ "$SSHTEST01" == "777" ] && [ "$SSHTEST02" == "777" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0069 should be set to chmod 755"	
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0069 is 755 or 755 down"
    fi
	
SSHTEST01=$(find -L /lib /lib64 /usr/lib /usr/lib64 ! -user root -exec sh -c 'owner=$(ls -ld "$1" | awk "{print \$3}"); if [ "$owner" != "root" ]; then echo $owner; exit 0; else exit 1; fi' sh {} \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0070 is root "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0070 should be set to #chown root"
    fi
	
SSHTEST01=$(find -L /lib /lib64 /usr/lib /usr/lib64 ! -group root -exec sh -c 'group=$(ls -ld "$1" | awk "{print \$4}"); if [ "$group" != "root" ]; then echo $group; exit 0; else exit 1; fi' sh {} \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0071 is root "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0071 should be set to chgrp root"
    fi
	
SSHTEST01=$(awk -F: '($2 == "" ) { print $1 "_attension!"}' /etc/shadow | head -n 1)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0072 pass "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0072 should be set to passwd -l"
    fi
	
SSHTEST01=$(echo $PATH | tr ':' ' ' | awk '/^\.$|^\.\.$|^[^\/]/ && length($0) > 0 {print; exit}')
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0073 pass "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0073 should be set to /etc/profile"
    fi
	
SSHTEST01=$(echo $PATH | tr ':' ' ' | (while read -r dir; do if [ -d "$dir" ]; then perm=$(stat -c "%A" "$dir"); if [[ "$perm" == *'w'* ]]; then echo "$dir - $perm"; exit 0; fi; fi; done))
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0074 pass "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0074 should be set to /etc/profile"
    fi
	
SSHTEST=$(grep -m 1 '^\+:' /etc/passwd)
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0075 grep -m 1 '^\+:' /etc/passwd is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0075 grep -m 1 '^\+:' /etc/passwd del + "$SSHTEST
    fi
	
SSHTEST=$(grep -m 1 '^\+:' /etc/shadow)
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0076 grep -m 1 '^\+:' /etc/shadow is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0076 grep -m 1 '^\+:' /etc/shadow del + "$SSHTEST
    fi
	
SSHTEST=$(grep -m 1 '^\+:' /etc/group)
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0077 grep -m 1 '^\+:' /etc/group is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0077 grep -m 1 '^\+:' /etc/group del + "$SSHTEST
    fi
	
SSHTEST=$(awk -F: '($3 == 0) { print $1 }' /etc/passwd)
    if [ "$SSHTEST" == "root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0078 Check ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0078 error"
    fi
	
######TWGCB-01-012-0079######
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 !="/bin/false") { print $1 " " $6 }' | while read user dir; do
 if [ ! -d "$dir" ]; then
 echo "The home directory ($dir) of user $user does not exist." >> /root/TWGCB-01-012-0079.log
 else
 dirperm=$(ls -ld $dir | cut -f1 -d" ")
 if [ $(echo $dirperm | cut -c6) != "-" ]; then
 echo "Group Write permission set on the homedirectory ($dir) of user$user" >> /root/TWGCB-01-012-0079.log
 fi 
 if [ $(echo $dirperm | cut -c8) != "-" ]; then
 echo "Other Read permission set on the home directory ($dir) of user$user" >> /root/TWGCB-01-012-0079.log
 fi
 if [ $(echo $dirperm | cut -c9) != "-" ]; then
 echo "Other Write permission set on the home directory ($dir) of user$user" >> /root/TWGCB-01-012-0079.log
 fi
 if [ $(echo $dirperm | cut -c10) != "-" ]; then
echo "Other Execute permission set on the home directory ($dir) of user$user" >> /root/TWGCB-01-012-0079.log
 fi
 fi
done

cramfs01=`grep -q "/" /root/TWGCB-01-012-0079.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0079 Check ok "
		rm -rf /root/TWGCB-01-012-0079.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0079 error (如有腳本，可評估排外)"
		rm -rf /root/TWGCB-01-012-0079.log
    fi
######TWGCB-01-012-0079###############################################

#######################TWGCB-01-012-0080##############################

#
grep -q -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
do
 if [ ! -d "$dir" ]; then
 echo "The home directory ($dir) of user $user does not exist." >> /root/TWGCB-01-012-0080.log
 #else
 #owner=$(stat -L -c "%U" "$dir")
 #if [ "$owner" != "$user" ]; then
 #echo "The home directory ($dir) of user $user is owned by $owner."
 #fi
fi
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0082.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
cramfs01=`grep -q "does not exist" /root/TWGCB-01-012-0080.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0080 Check ok " 
		rm -rf  /root/TWGCB-01-012-0082.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0080 error (可排外，如有腳本使用)"
		rm -rf  /root/TWGCB-01-012-0082.log
    fi  

   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0080 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0080##############################	



	
#
#######################TWGCB-01-012-0081##############################

#
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $4 " " $6 }' | while read user gid dir; 
do
 if [ ! -d "$dir" ]; then
 echo "The home directory ($dir) of user $user does not exist." >> /root/TWGCB-01-012-0081.log
 #else
 #owner=$(stat -L -c "%g" "$dir")
 #if [ "$owner" != "$gid" ]; then
 #echo "The home directory ($dir) of group $gid is owned by group $owner."
 #fi
fi
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0081.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
cramfs01=`grep -q "does not exist" /root/TWGCB-01-012-0081.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0081 Check ok "
		rm -rf  /root/TWGCB-01-012-0081.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0081 error (可排外)"
		rm -rf  /root/TWGCB-01-012-0081.log
    fi   

   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0081 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0081##############################


#
#######################TWGCB-01-012-0082##############################

#
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 !="'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
do
 if [ ! -h "$file" -a -f "$file" ]; then
        fileperm=$(ls -ld $file | cut -f1 -d" ")
 if [ $(echo $fileperm | cut -c6) != "-" ]; then
     echo "Group Write permission set on file $file" >> /root/TWGCB-01-012-0082.log
fi
 if [ $(echo $fileperm | cut -c9) != "-" ]; then
     echo "Other Write permission set on file $file" >> /root/TWGCB-01-012-0082.log
 fi
fi
 done

FRUIT=`if [ -f "/root/TWGCB-01-012-0082.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q "Write permission set" /root/TWGCB-01-012-0082.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0082 Check ok "
		rm -rf  /root/TWGCB-01-012-0082.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0082 error"
		rm -rf  /root/TWGCB-01-012-0082.log
    fi
  
   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0082 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0082##############################

	
#
#######################TWGCB-01-012-0083##############################

#
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
 do
 if [ ! -h "$dir/.forward" -a -f "$dir/.forward" ]; then
     echo ".forward file $dir/.forward exists" >> /root/TWGCB-01-012-0083.log
 fi
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0083.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q "forward exists" /root/TWGCB-01-012-0083.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0083 Check ok "
		rm -rf  /root/TWGCB-01-012-0083.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0083 error"
		rm -rf  /root/TWGCB-01-012-0083.log
    fi
  
   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0083 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0083##############################


	
#
#######################TWGCB-01-012-0084##############################

#
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
do
 if [ ! -h "$dir/.netrc" -a -f "$dir/.netrc" ]; then
    echo ".netrc file $dir/.netrc exists" >> /root/TWGCB-01-012-0084.log
 fi
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0084.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q "netrc exists" /root/TWGCB-01-012-0084.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0084 Check ok "
		rm -rf  /root/TWGCB-01-012-0084.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0084 error"
		rm -rf  /root/TWGCB-01-012-0084.log
    fi   
  
   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0084 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0084##############################


	
#
#######################TWGCB-01-012-0085##############################

#
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
do
 for file in $dir/.rhosts;
 do
    if [ ! -h "$file" -a -f "$file" ]; then
       echo ".rhosts file in $dir" >> /root/TWGCB-01-012-0085.log
    fi
 done
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0085.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q "rhosts file" /root/TWGCB-01-012-0085.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0085 Check ok " 
		rm -rf  /root/TWGCB-01-012-0085.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0085 error"
		rm -rf  /root/TWGCB-01-012-0085.log
    fi  

   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0085 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0085##############################
	
#######################TWGCB-01-012-0086##############################

#
for i in $(cut -s -d: -f4 /etc/passwd | sort -u );
do
 grep -q -P "^.*?:[^:]*:$i:" /etc/group
    if [ $? -ne 0 ]; then
      echo "Group $i is referenced by /etc/passwd but does not exist in /etc/group" >> /root/TWGCB-01-012-0086.log
    fi
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0086.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "/etc/passwd" /root/TWGCB-01-012-0086.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0086 Check ok "
		rm -rf  /root/TWGCB-01-012-0086.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0086 Check error"
		rm -rf  /root/TWGCB-01-012-0086.log
    fi

   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0086 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0086##############################


######################TWGCB-01-012-0087##############################

#
cut -f3 -d":" /etc/passwd | sort -n | uniq -c | while read x ;
do
 [ -z "$x" ] && break
 set - $x
    if [ $1 -gt 1 ]; then
       users=$(awk -F: '($3 == n) { print $1 }' n=$2 /etc/passwd | xargs)
       echo "Duplicate UID ($2): $users" >> /root/TWGCB-01-012-0087.log
    fi
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0087.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "Duplicate UID" /root/TWGCB-01-012-0087.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0087 Check ok "
		rm -rf  /root/TWGCB-01-012-0087.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0087 The Duplicate UID"
		rm -rf  /root/TWGCB-01-012-0087.log
    fi
   ;;
   "FAIL") 
   
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0087 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0087##############################

	
#
######################TWGCB-01-012-0088##############################

#
cut -d: -f3 /etc/group | sort | uniq -d | while read x ;
do
 echo "Duplicate GID ($x) in /etc/group" >> /root/TWGCB-01-012-0088.log
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0088.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "Duplicate GID" /root/TWGCB-01-012-0088.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0088 Check ok "
		rm -rf  /root/TWGCB-01-012-0088.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0088 Duplicate GID ($x) in /etc/group"
		rm -rf  /root/TWGCB-01-012-0088.log
    fi

   ;;
   "FAIL") 

    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0088 Check ok "

   ;; 
  
esac

######################TWGCB-01-012-0088##############################



######################TWGCB-01-012-0089##############################

#
cut -d: -f1 /etc/passwd | sort | uniq -d | while read x ;
do 
  echo "Duplicate login name ${x} in /etc/passwd" >> /root/TWGCB-01-012-0089.log
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0089.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "Duplicate UID" /root/TWGCB-01-012-0089.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0089 Check ok "
		rm -rf  /root/TWGCB-01-012-0089.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0089 Duplicate login name ${x} in /etc/passwd"
		rm -rf  /root/TWGCB-01-012-0089.log
    fi

   ;;
   "FAIL") 

    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0089 Check ok "  
	
   ;; 
  
esac

######################TWGCB-01-012-0089##############################




######################TWGCB-01-012-0090##############################

cut -d: -f1 /etc/group | sort | uniq -d | while read x ;
do 
  echo "Duplicate group name ${x} in /etc/group" >> /root/TWGCB-01-012-0090.log
done

FRUIT=`if [ -f "/root/TWGCB-01-012-0090.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=`grep -q "Duplicate group name" /root/TWGCB-01-012-0090.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0090 Check ok "
		rm -rf  /root/TWGCB-01-012-0090.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0090 Duplicate group name ${x} in /etc/group"
		rm -rf  /root/TWGCB-01-012-0090.log
    fi

   ;;
   "FAIL") 

   echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0090 Check ok "   
   ;; 
  
esac

######################TWGCB-01-012-0090##############################

	
cramfs01=`awk -F: '($1=="shadow") {print $NF}' /etc/group && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0091 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0091 /etc/group is users"
    fi
	
audit01=`rpm -q xinetd | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0092 remove xinetd"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0092 should be different to dnf remove xinetd"
    fi
	
cramfs01=`grep -i "server" /etc/chrony.conf | grep -v "#" | wc -l`
    if [ "$cramfs01" -ge "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0093 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0093 error (手動設定NTP Server)"
    fi
	
autofs01=`systemctl is-active rsyncd`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0094 active rsyncd "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0094 disable rsyncd "$autofs01
    fi
	
autofs01=`systemctl is-active avahi-daemon`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0095 active avahi-daemon "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0095 disable avahi-daemon "$autofs01
    fi
	
autofs01=`systemctl is-active snmpd`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0096 enable snmpd "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0096 disable snmpd "$autofs01
    fi
	
autofs01=`systemctl is-active squid`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0097 enable squid "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0097 disable squid "$autofs01
    fi
	
autofs01=`systemctl is-active smb`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0098 enable smb "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0098 disable smb "$autofs01
    fi
	
autofs01=`systemctl is-active vsftpd`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0099 enable vsftpd "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0099 disable vsftpd "$autofs01
    fi
	
autofs01=`systemctl is-active ypserv`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0100 enable ypserv "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0100 disable ypserv "$autofs01
    fi
	
autofs01=`systemctl is-active kdump.service`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0101 enable kdump.service "$autofs01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0101 disable kdump.service "$autofs01
    fi
	
audit01=`rpm -q ypbind | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0102 remove ypbind"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0102 should be different to dnf remove ypbind"
    fi
	
audit01=`rpm -q telnet | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0103 remove telnet"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0103 should be different to dnf remove telnet"
    fi
	
audit01=`rpm -q telnet-server | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0104 remove telnet-server"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0104 should be different to dnf remove telnet-server"
    fi
	
audit01=`rpm -q rsh-server | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0105 remove rsh-server"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0105 should be different to dnf remove rsh-server"
    fi
	
audit01=`rpm -q tftp-server | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0106 remove tftp-server"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0106 should be different to dnf remove tftp-server"
    fi
	
SSHTEST=$(cat /etc/dnf/dnf.conf | grep clean_requirements_on_remove | cut -c30-)
    if [ $SSHTEST == "True" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0107 clean_requirements_on_remove Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0107 clean_requirements_on_remove should be set to True'"
    fi
	
#https://www.cnblogs.com/eleclsc/p/11685092.html
SSHTEST01=$(cat /etc/sysctl.conf | grep -q net.ipv4.ip_forward=0 && echo 0 || echo 1)
SSHTEST02=$(cat /etc/sysctl.conf | grep -q net.ipv6.conf.all.forwarding && echo 0 || echo 1)
    if [ "$SSHTEST01" == "0" ] && [ "$SSHTEST02" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0108 net.ipv4.ip_forward net.ipv6.conf.all.forwarding Check is 0"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0108 net.ipv4.ip_forward net.ipv6.conf.all.forwarding should be set to 0'"
    fi
	
SSHTEST02=$(cat /etc/sysctl.conf | grep -q net.ipv4.conf.all.send_redirects=0 && echo 0 || echo 1)
    if [ $SSHTEST02 == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0109 net.ipv4.conf.all.send_redirects Check is "$SSHTEST02
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0109 net.ipv4.conf.all.send_redirects should be set to 0'"
    fi
	
SSHTEST02=$(cat /etc/sysctl.conf | grep -q net.ipv4.conf.default.send_redirects=0 && echo 0 || echo 1)
    if [ $SSHTEST02 == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0110 net.ipv4.conf.default.send_redirects Check is "$SSHTEST02
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0110 net.ipv4.conf.all.send_redirects should be set to 0'"
    fi
	
SSHTEST01=$(cat /etc/sysctl.conf | grep -q net.ipv4.conf.all.accept_source_route=0 && echo 0 || echo 1)
SSHTEST02=$(cat /etc/sysctl.conf | grep -q net.ipv6.conf.all.accept_source_route=0 && echo 0 || echo 1)
    if [ "$SSHTEST01" == "0" ] && [ "$SSHTEST02" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0111 net.ipv4-6.conf.all.accept_source_route Check is 0"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0111 net.ipv4-6.conf.all.accept_source_route should be set to 0'"
    fi
	
if grep -qE "^net.ipv4.conf.default.accept_source_route\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0112 net.ipv4.conf.default.accept_source_route = 0"
else
    if grep -qE "^net.ipv4.conf.default.accept_source_route" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.accept_source_route" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0112 net.ipv4.conf.default.accept_source_route = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0112 net.ipv4.conf.default.accept_source_route = 0"
    fi
fi
if grep -qE "^net.ipv6.conf.default.accept_source_route\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0112 net.ipv6.conf.default.accept_source_route = 0"
else
    if grep -qE "^net.ipv6.conf.default.accept_source_route" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.default.accept_source_route" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0112 net.ipv6.conf.default.accept_source_route = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0112 net.ipv6.conf.default.accept_source_route = 0"
    fi
fi
expected_value="0"

#TWGCB-01-012-0113
if grep -qE "^net.ipv4.conf.all.accept_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0113 net.ipv4.conf.all.accept_redirects = 0"
else
    if grep -qE "^net.ipv4.conf.all.accept_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.all.accept_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0113 net.ipv4.conf.all.accept_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0113 net.ipv4.conf.all.accept_redirects = 0"
    fi
fi

if grep -qE "^net.ipv6.conf.all.accept_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0113 net.ipv6.conf.all.accept_redirects = 0"
else
    if grep -qE "^net.ipv6.conf.all.accept_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.all.accept_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0113 net.ipv6.conf.all.accept_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0113 net.ipv6.conf.all.accept_redirects = 0"
    fi
fi
#
#TWGCB-01-012-0114
if grep -qE "^net.ipv4.conf.default.accept_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0114 net.ipv4.conf.default.accept_redirects = 0"
else
    if grep -qE "^net.ipv4.conf.default.accept_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.accept_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0114 net.ipv4.conf.default.accept_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0114 net.ipv4.conf.default.accept_redirects = 0"
    fi
fi
if grep -qE "^net.ipv6.conf.default.accept_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0114 net.ipv6.conf.default.accept_redirects = 0"
else
    if grep -qE "^net.ipv6.conf.default.accept_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.default.accept_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0114 net.ipv6.conf.default.accept_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0114 net.ipv6.conf.default.accept_redirects = 0"
    fi
fi
#

#TWGCB-01-012-0115
if grep -qE "^net.ipv4.conf.all.secure_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0115 net.ipv4.conf.all.secure_redirects = 0"
else
    if grep -qE "^net.ipv4.conf.all.secure_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.all.secure_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0115 net.ipv4.conf.all.secure_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0115 net.ipv4.conf.all.secure_redirects = 0"
    fi
fi

#TWGCB-01-012-0116
if grep -qE "^net.ipv4.conf.default.secure_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0116 net.ipv4.conf.default.secure_redirects = 0"
else
    if grep -qE "^net.ipv4.conf.default.secure_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.secure_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0116 net.ipv4.conf.default.secure_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0116 net.ipv4.conf.default.secure_redirects = 0"
    fi
fi

#TWGCB-01-012-0117
expected_value="1"
if grep -qE "^net.ipv4.conf.all.log_martians\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0117 net.ipv4.conf.all.log_martians = 1"
else
    if grep -qE "^net.ipv4.conf.all.log_martians" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.all.log_martians" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0117 net.ipv4.conf.all.log_martians = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0117 net.ipv4.conf.all.log_martians = 1"
    fi
fi
#TWGCB-01-012-0118
if grep -qE "^net.ipv4.conf.default.log_martians\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0118 net.ipv4.conf.default.log_martians = 1"
else
    if grep -qE "^net.ipv4.conf.default.log_martians" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.log_martians" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0118 net.ipv4.conf.default.log_martians = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0118 net.ipv4.conf.default.log_martians = 1"
    fi
fi

#TWGCB-01-012-0119
expected_value="1"
if grep -qE "^net.ipv4.icmp_echo_ignore_broadcasts\s*=\s*$expected_value" /etc/sysctl.conf ; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0119 net.ipv4.icmp_echo_ignore_broadcasts = 1"
else
    if grep -qE "^net.ipv4.icmp_echo_ignore_broadcasts" /etc/sysctl.conf ; then
        current_value=$(grep -E "^net.ipv4.icmp_echo_ignore_broadcasts" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0119 net.ipv4.icmp_echo_ignore_broadcasts = "$current_value " Expected value : "$expected_value
    else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0119 net.ipv4.icmp_echo_ignore_broadcasts = 1"
    fi
fi
sleep 1
#TWGCB-01-012-0120
expected_value="1"
if grep -qE "^net.ipv4.icmp_ignore_bogus_error_responses\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0120 net.ipv4.icmp_ignore_bogus_error_responses = 1"
else
    if grep -qE "^net.ipv4.icmp_ignore_bogus_error_responses" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.icmp_ignore_bogus_error_responses" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0120 net.ipv4.icmp_ignore_bogus_error_responses = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0120 net.ipv4.icmp_ignore_bogus_error_responses = 1"
    fi
fi
#TWGCB-01-012-0121
expected_value="1"
if grep -qE "^net.ipv4.conf.all.rp_filter\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0121 net.ipv4.conf.all.rp_filter = 1"
else
    if grep -qE "^net.ipv4.conf.all.rp_filter" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.all.rp_filter" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0121 net.ipv4.conf.all.rp_filter = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0121 net.ipv4.conf.all.rp_filter = 1"
    fi
fi
#TWGCB-01-012-0122
expected_value="1"
if grep -qE "^net.ipv4.conf.default.rp_filter\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0122 net.ipv4.conf.default.rp_filter = 1"
else
    if grep -qE "^net.ipv4.conf.default.rp_filter" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.rp_filter" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0122 net.ipv4.conf.default.rp_filter = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0122 net.ipv4.conf.default.rp_filter = 1"
    fi
fi
sleep 1
#TWGCB-01-012-0123
expected_value="1"
if grep -qE "^net.ipv4.tcp_syncookies\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0123 net.ipv4.tcp_syncookies = 1"
else
    if grep -qE "^net.ipv4.tcp_syncookies" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.tcp_syncookies" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0123 net.ipv4.tcp_syncookies = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0123 net.ipv4.tcp_syncookies = 1"
    fi
fi
#TWGCB-01-012-0124
expected_value="0"
if grep -qE "^net.ipv6.conf.all.accept_ra\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0124 net.ipv6.conf.all.accept_ra = 0"
else
    if grep -qE "^net.ipv6.conf.all.accept_ra" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.all.accept_ra" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0124 net.ipv6.conf.all.accept_ra = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0124 net.ipv6.conf.all.accept_ra = 0"
    fi
fi
#TWGCB-01-012-0125
expected_value="0"
if grep -qE "^net.ipv6.conf.default.accept_ra\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-012-0125 net.ipv6.conf.default.accept_ra = 0"
else
    if grep -qE "^net.ipv6.conf.default.accept_ra" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.default.accept_ra" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-012-0125 net.ipv6.conf.default.accept_ra = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-012-0125 net.ipv6.conf.default.accept_ra = 0"
    fi
fi

###	TWGCB-01-012-0126 ####
#1
FRUIT=`if [ -f "/etc/modprobe.d/dccp.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

audit01=`awk '$1 == "install" && $2 == "dccp" && $3 == "/bin/true"'  /etc/modprobe.d/dccp.conf  | grep -q "install dccp /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "dccp"'  /etc/modprobe.d/dccp.conf  | grep -q "blacklist dccp" && echo 0 || echo 1`
audit03=`lsmod | grep dccp  | grep -q "dccp" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0126 rmmod dccp is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0126 should be different to rmmod dccp "
    fi


   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0126 no /etc/modprobe.d/dccp.conf"
   
   ;;
esac

###	TWGCB-01-012-0126 ####

###	TWGCB-01-012-0127 ####
#1
FRUIT=`if [ -f "/etc/modprobe.d/sctp.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

audit01=`awk '$1 == "install" && $2 == "sctp" && $3 == "/bin/true"'  /etc/modprobe.d/sctp.conf  | grep -q "install sctp /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "sctp"'  /etc/modprobe.d/sctp.conf  | grep -q "blacklist sctp" && echo 0 || echo 1`
audit03=`lsmod | grep sctp  | grep -q "sctp" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0127 rmmod sctp is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0127 should be different to rmmod sctp "
    fi


   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0127 no /etc/modprobe.d/sctp.conf"
   
   ;;
esac

###	TWGCB-01-012-0127 ####

###	TWGCB-01-012-0128 ####
#1
FRUIT=`if [ -f "/etc/modprobe.d/rds.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

audit01=`awk '$1 == "install" && $2 == "rds" && $3 == "/bin/true"'  /etc/modprobe.d/rds.conf  | grep -q "install rds /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "rds"'  /etc/modprobe.d/rds.conf  | grep -q "blacklist rds" && echo 0 || echo 1`
audit03=`lsmod | grep rds  | grep -q "rds" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0128 rmmod rds is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0128 should be different to rmmod rds "
    fi


   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0128 no /etc/modprobe.d/rds.conf"
   
   ;;
esac
###

###	TWGCB-01-012-0129 ####
#1
FRUIT=`if [ -f "/etc/modprobe.d/tipc.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

audit01=`awk '$1 == "install" && $2 == "tipc" && $3 == "/bin/true"'  /etc/modprobe.d/tipc.conf  | grep -q "install tipc /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "tipc"'  /etc/modprobe.d/tipc.conf | grep -q "blacklist tipc" && echo 0 || echo 1`
audit03=`lsmod | grep tipc  | grep -q "tipc" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0129 rmmod tipc is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0129 should be different to rmmod tipc "
    fi


   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0129 no /etc/modprobe.d/tipc.conf"
   
   ;;
esac
###

cramfs01=`nmcli radio wifi | grep -q -i "disabled" && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0130 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0130 error"
    fi
	
cramfs08=`ip link | grep -i promisc`
    if [ -z $cramfs08 ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0131 無，檢查網路介面處於混雜模式"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0131 有，檢查網路介面處於混雜模式" 
	fi
	
audit01=`rpm -q audit | grep -q '尚未安裝' && echo 0 || echo 1`
audit02=`rpm -q audit-libs | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ] && [ "$audit02" -eq "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0132 no install"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0132 should be different to dnf install audit audit-libs"
    fi
	
autofs01=`systemctl is-active auditd`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0133 enable auditd "$autofs01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0133 disable auditd "$autofs01
    fi
	
cramfs01=$(grep -q -P '^(?=.*GRUB_CMDLINE_LINUX)(?=.*audit=1)' /etc/default/grub && echo 0 || echo 1)
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0134 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0134 Check no GRUB_CMDLINE_LINUX_DEFAULT="audit=1" "
    fi
	
cramfs01=$(grep -q -P '^(?=.*GRUB_CMDLINE_LINUX)(?=.*audit_backlog_limit=8192)' /etc/default/grub && echo 0 || echo 1)
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0135 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0135 Check no GRUB_CMDLINE_LINUX_DEFAULT="audit_backlog_limit=8192" "
    fi
	
 audit01=`awk '$1 == "postmaster:"' /etc/aliases | grep -q -P '^(?=.*postmaster)(?=.*root)' && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0136 nfs ckeck add postmaster: root is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0136 /etc/aliases should be different to add postmaster: rootv"
    fi
	
cramfs01=$(ls -l /var/log/audit/audit.log | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0137 Check /var/log/audit/audit.log is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0137 no root:root"
    fi
	
###	TWGCB-01-012-0138 ####
FRUIT=`if [ -f "/var/log/audit/audit.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /var/log/audit/audit.log)
    if [ $cramfs01 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0138 Check /var/log/audit/audit.log is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0138 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0138 no /var/log/audit/audit.log"
   
   ;;
esac
###	TWGCB-01-012-0138 ####

cramfs01=$(ls -l /etc/audit/auditd.conf | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0139 Check /etc/audit/auditd.conf is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0139 no root:root"
    fi
	
###	TWGCB-01-012-0140 ####
FRUIT=`if [ -f "/etc/audit/auditd.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /var/log/audit)
    if [ $cramfs01 -le "700" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0140 Check /var/log/audit is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0140 no 700"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0140 no /var/log/audit"
   
   ;;
esac
###	TWGCB-01-012-0140 ####

###	TWGCB-01-012-0141 ####
FRUIT=`if [ -f "/etc/audit/rules.d/audit.rules" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /etc/audit/rules.d/audit.rules)
    if [ $cramfs01 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0141 Check /etc/audit/rules.d/audit.rules is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0141 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0141 no /etc/audit/rules.d/audit.rules"
   
   ;;
esac
###	TWGCB-01-012-0141 ####

###	TWGCB-01-012-0142 ####
FRUIT=`if [ -f "/etc/audit/auditd.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /etc/audit/auditd.conf)
    if [ $cramfs01 -le "640" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0142 Check /etc/audit/auditd.conf is 640 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0142 no 640"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0142 no /etc/audit/auditd.conf"
   
   ;;
esac
###	TWGCB-01-012-0142 ####

###	TWGCB-01-012-0143 ####
#1
FRUIT=`if [ -f "/sbin/auditctl" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /sbin/auditctl)
    if [ $cramfs01 -le "750" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0143 Check /sbin/auditctl is 750 ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0143 no 750 (手動設定)"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0143 no /sbin/auditctl"
   
   ;;
esac

###	TWGCB-01-012-0144 ####
#1
FRUIT=`if [ -f "/sbin/auditctl" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(ls -l /sbin/auditctl | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0144 Check /sbin/auditctl is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no /sbin/auditctl"
   
   ;;
esac

#2
FRUIT=`if [ -f "/sbin/aureport" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(ls -l /sbin/aureport | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0144 Check /sbin/aureport is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no /sbin/aureport"
   
   ;;
esac

#3
FRUIT=`if [ -f "/sbin/ausearch" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(ls -l /sbin/ausearch | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0144 Check /sbin/ausearch is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no /sbin/ausearch"
   
   ;;
esac

#4
FRUIT=`if [ -f "/sbin/autrace" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(ls -l /sbin/autrace | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0144 Check /sbin/autrace is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no /sbin/autrace"
   
   ;;
esac


#5
FRUIT=`if [ -f "/sbin/auditd" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=$(ls -l /sbin/auditd | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0144 Check /sbin/auditd is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no root:root"
    fi
    
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no /sbin/auditd"
   
   ;;
esac

#6
FRUIT=`if [ -f "/sbin/audisp-remote" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=$(ls -l /sbin/audisp-remote | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0144 Check /sbin/audisp-remote is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no /sbin/audisp-remote (可排外，無此目錄)"
   
   ;;
esac

#7
FRUIT=`if [ -f "/sbin/audisp-syslog" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
       
cramfs01=$(ls -l /sbin/audisp-syslog | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0144 Check /sbin/audisp-syslog is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no root:root"
    fi
	
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no /sbin/audisp-syslog (可排外，無此目錄)"
   
   ;;
esac

#8
FRUIT=`if [ -f "/sbin/augenrules" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   	
cramfs01=$(ls -l /sbin/augenrules | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0144 Check /sbin/augenrules is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0144 no /sbin/augenrules"
   
   ;;
esac

###	TWGCB-01-012-0144 ####

###	TWGCB-01-012-0145 ####
#1
FRUIT=`if [ -f "/etc/aide.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q -i "/usr/sbin/auditctl p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs02=`grep -q -i "/usr/sbin/auditd p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs03=`grep -q -i "/usr/sbin/ausearch p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs04=`grep -q -i "/usr/sbin/aureport p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs05=`grep -q -i "/usr/sbin/autrace p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs06=`grep -q -i "/usr/sbin/audisp-remote p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs07=`grep -q -i "/usr/sbin/audisp-syslog p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs08=`grep -q -i "/usr/sbin/augenrules p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] && [ "$cramfs04" == "0" ] && [ "$cramfs05" == "0" ] && [ "$cramfs06" == "0" ] && [ "$cramfs07" == "0" ] && [ "$cramfs08" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0145 add aide rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0145 should be different to add aide rules"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0145 no /etc/aide.conf"
   
   ;;
esac

###	TWGCB-01-012-0145 ####

audit01=`grep -i '^[[:space:]]*max_log_file[[:space:]]*=' /etc/audit/auditd.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" -ge "32" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0146 max_log_file = 32"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0146 should be different to max_log_file = 32"
    fi

audit01=`grep -i '^[[:space:]]*max_log_file_action[[:space:]]*=' /etc/audit/auditd.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "keep_logs" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0147 max_log_file_action = keep_logs"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0147 should be different to max_log_file_action = keep_logs"
    fi
	
cramfs01=`grep -q '^[-]'"w /etc/sudoers -p wa -k scope" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /etc/sudoers.d/ -p wa -k scope" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0148 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0148 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /var/run/faillock/ -p wa -k logins" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /var/log/lastlog -p wa -k logins" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0149 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0149 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /var/run/utmp -p wa -k session" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /var/log/wtmp -p wa -k logins" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs03=`grep -q '^[-]'"w /var/log/btmp -p wa -k logins" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0150 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0150 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs03=`grep -q '^[-]'"a always,exit -F arch=b64 -S clock_settime -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs04=`grep -q '^[-]'"a always,exit -F arch=b32 -S clock_settime -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs05=`grep -q '^[-]'"w /etc/localtime -p wa -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] && [ "$cramfs04" == "0" ] && [ "$cramfs05" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0151 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0151 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /etc/selinux/ -p wa -k MAC-policy" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /usr/share/selinux/ -p wa -k MAC-policy" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0152 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0152 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"w /etc/issue -p wa -k system-locale" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"w /etc/issue.net -p wa -k system-locale" /etc/audit/rules.d/audit.rules`
cramfs05=`grep '^[-]'"w /etc/sysconfig/network-scripts/ -p wa -k system-locale" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale" ] && [ "$cramfs02" == "-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale" ] && [ "$cramfs03" == "-w /etc/issue -p wa -k system-locale" ] && [ "$cramfs04" == "-w /etc/issue.net -p wa -k system-locale" ] && [ "$cramfs05" == "-w /etc/sysconfig/network-scripts/ -p wa -k system-locale" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0153 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0153 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs05=`grep '^[-]'"a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs06=`grep '^[-]'"a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs02" == "-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs03" == "-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs04" == "-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs05" == "-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs06" == "-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0154 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0154 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access" ] && [ "$cramfs02" == "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access" ] && [ "$cramfs03" == "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access" ] && [ "$cramfs04" == "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0155 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0155 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /etc/group -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /etc/passwd -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs03=`grep -q '^[-]'"w /etc/gshadow -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs04=`grep -q '^[-]'"w /etc/shadow -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs05=`grep -q '^[-]'"w /etc/security/opasswd -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] && [ "$cramfs04" == "0" ] && [ "$cramfs05" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0156 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0156 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts" ] && [ "$cramfs02" == "-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0157 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0157 should be different to add audit rules"
    fi
	
########TWGCB-01-012-0158################
FRUIT=`if [ -f "/etc/audit/rules.d/privileged.rules" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
# 此是query -->> df --local -P 2> /dev/null | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type f \( -perm -4000 -o -perm -2000 \) | awk '{print "-a always,exit -F path="$1" -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged" }' >> /etc/audit/rules.d/privileged.rules
cramfs08=`grep -q "/" /etc/audit/rules.d/privileged.rules && echo 0 || echo 1`
    if [ -z $cramfs08 ] ; then  
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0158 無，找出特權程式稽核規則加入到該/etc/audit/rules.d/privileged.rules檔案"
    else   
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0158 Enable，找出特權程式稽核規則加入到該/etc/audit/rules.d/privileged.rules檔案" 
	fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0158 no /etc/audit/rules.d/privileged.rules"
   
   ;;
esac
########TWGCB-01-012-0158################

cramfs01=`grep -q '^[-]'"a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0159 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0159 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /sbin/insmod -p x -k modules" /etc/audit/rules.d/audit.rules > /dev/null 2>&1 && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /sbin/rmmod -p x -k modules" /etc/audit/rules.d/audit.rules > /dev/null 2>&1 && echo 0 || echo 1`
cramfs03=`grep -q '^[-]'"w /sbin/modprobe -p x -k modules" /etc/audit/rules.d/audit.rules > /dev/null 2>&1 && echo 0 || echo 1`
cramfs04=`grep -q '^[-]'"a always,exit -F arch=b64 -S init_module -S delete_module -k modules" /etc/audit/rules.d/audit.rules > /dev/null 2>&1 && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] && [ "$cramfs04" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0160 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0160 should be different to add audit rules"
    fi

###	TWGCB-01-012-0161 ####
#1
FRUIT=`if [ -f "/var/log/sudo.log" ] && [ -f "/etc/audit/rules.d/actions.rules" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "/var/log/sudo.log" /etc/audit/rules.d/actions.rules | tail -1 && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0161 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0161 should be different to add audit rules (可手動設定)"
    fi

   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0161 no /etc/audit/rules.d/actions.rules (可手動設定)"
   
   ;;
esac
###
	
cramfs01=`grep '^[-]'"a always,exit -F path=/usr/bin/chcon -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/usr/bin/chcon -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0162 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0162 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"a always,exit -F path=/usr/bin/ssh-agent -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-ssh" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0163 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0163 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F path=/sbin/unix_update -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix-update" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/sbin/unix_update -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix-update" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0164 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0164 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0165 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0165 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b32 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b64 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b32 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng" ] && [ "$cramfs02" == "-a always,exit -F arch=b64 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0166 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0166 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" ] && [ "$cramfs02" == "-a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" ] && [ "$cramfs03" == "-a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" ] && [ "$cramfs04" == "-a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0167 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0167 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-usermod" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-usermod" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0168 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0168 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F path=/usr/bin/chacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/usr/bin/chacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0169 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0169 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"w /bin/kmod -p x -k modules" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-w /bin/kmod -p x -k modules" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0170 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0170 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"w /var/log/faillock -p wa -k logins" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-w /var/log/faillock -p wa -k logins" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0171 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0171 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b32 -S execve -C uid!=euid -F key=execpriv" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b64 -S execve -C uid!=euid -F key=execpriv" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"a always,exit -F arch=b32 -S execve -C gid!=egid -F key=execpriv" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"a always,exit -F arch=b64 -S execve -C gid!=egid -F key=execpriv" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b32 -S execve -C uid!=euid -F key=execpriv" ] && [ "$cramfs02" == "-a always,exit -F arch=b64 -S execve -C uid!=euid -F key=execpriv" ] && [ "$cramfs03" == "-a always,exit -F arch=b32 -S execve -C gid!=egid -F key=execpriv" ] && [ "$cramfs04" == "-a always,exit -F arch=b64 -S execve -C gid!=egid -F key=execpriv" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0172 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0172 should be different to add audit rules"
    fi
	
cramfs01=`grep "-e 2" /etc/audit/rules.d/audit.rules`
cramfs02=`grep "^\s*[^#]" /etc/audit/rules.d/*.rules | tail -1`

    if [ "$cramfs01" == "-e 2" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0173 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0173 should be different to add audit rules"
    fi
	
    if [ $(rpm -qa|grep -c rsyslog) -gt 0 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0174 install rsyslog "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0174 rsyslog should be different to dnf install rsyslog"
    fi
	
autofs01=`systemctl is-active crond`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0175 enable rsyslog "$autofs01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0175 disable rsyslog "$autofs01
    fi
	
SSHTEST01=`grep -i "auth.*,authpriv.* /var/log/secure" /etc/rsyslog.conf | grep -q -v "#" && echo 0 || echo 1`
SSHTEST02=`grep -i "daemon.* /var/log/messages" /etc/rsyslog.conf | grep -q -v "#" && echo 0 || echo 1`
    if [ "$SSHTEST01" == "0" ] && [ "$SSHTEST02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0176 /etc/rsyslog.conf  ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0176 /etc/rsyslog.conf should be set to auth.*,authpriv.* /var/log/secure daemon.* /var/log/messages"
    fi
	
audit01=`grep -q -i "daemon.*" /etc/rsyslog.conf && echo 0 || echo 1` 
audit02=`grep -q -P '^(?=.*auth.*)(?=.*,authpriv)' /etc/rsyslog.conf && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0177 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0177 check is error"
    fi
	
 cramfs01=$(ls -l /var/log/messages | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0178 Check /var/log/messages is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0178 no root:root"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.d)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0179 Check /etc/cron.d is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0179 no root:root"
    fi
	
audit01=`grep -i '^[[:space:]]*ForwardToSyslog[[:space:]]*=' /etc/systemd/journald.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "yes" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0180 ForwardToSyslog=yes"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0180 should be different to ForwardToSyslog=yes"
    fi
	
audit01=`grep -i '^[[:space:]]*Compress[[:space:]]*=' /etc/systemd/journald.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "yes" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0181 Compress=yes"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0181 should be different to Compress=yes"
    fi
	
audit01=`grep -i '^[[:space:]]*Storage[[:space:]]*=' /etc/systemd/journald.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "persistent" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0182 Storage = persistent"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0182 should be different to Storage = persistent"
    fi
	
SSHTEST01=$(find /var/log -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 640 ]; then echo $perm; exit 0; fi' \; | paste -s)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0183 /var/log  -type f 大於 640 沒有"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0183 /var/log  -type f should be set to chmod g-wx,o-rwx "{}" + (可設定)"
    fi
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0184 於 v1.1 已移除的政策"
###########################################################################################


audit01=`rpm -q libselinux | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0184 install libselinux "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0184 should be different to dnf install libselinux"
    fi
	
cramfs01=$(grep -E "^GRUB_CMDLINE_LINUX=" /etc/default/grub | awk -F= '{print $2}')
cramfs02=$(grep -E "^GRUB_CMDLINE_LINUX_DEFAULT=" /etc/default/grub | awk -F= '{print $2}' | grep -q -E \"quiet\" && echo 0 || echo 1)
    if [ "$cramfs01" == '""' ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0185 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0185 Check no GRUB_CMDLINE_LINUX_DEFAULT="quiet" & GRUB_CMDLINE_LINUX="" ((可設定))"
    fi
	
audit01=`grep -i '^[[:space:]]*SELINUXTYPE[[:space:]]*=' /etc/selinux/config | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "targeted" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0186 SELINUXTYPE=targeted "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0186 should be different to SELINUXTYPE=targeted "
    fi
	
audit01=`grep -i '^[[:space:]]*SELINUX[[:space:]]*=' /etc/selinux/config | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "enforcing" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0187 SELINUX=enforcing (排外，會影響Auitd.Service無法啟動)"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0187 should be different to SELINUX=enforcing (排外，會影響Auitd.Service無法啟動)"
    fi
	
#https://medium.com/@DavidAwCloudSOC/the-truth-about-unconfined-domain-and-selinux-policy-dea9ec7cab1c
#1.inti_t. Systemd.
#2.httpd_t. HTTP daemon threads.
#3.kernel_t. Kernel threads.
#4.syslogd_t. The logging daemons for journald and rsyslogd.
#5.unconfined_t. Processes executed by users in the unconfined domain.
#chcon -t inti_t /usr/libexec/power-profiles-daemon
#chcon -t kernel_t /usr/libexec/switcheroo-control
cramfs01=$(ps -eZf | grep -c unconfined_service_t)
    if [ $cramfs01 -gt "1" ] ; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0188 Check yes unconfined_service_t (可排外，如有安裝防毒或監控可考慮，無入SELINUX)"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0188 Check no unconfined_service_t ok "
    fi
	
audit01=`rpm -q setroubleshoot | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ] ; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0189 install setroubleshoot"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0189 no install setroubleshoot"
    fi
	
audit01=`rpm -q mcstrans | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ] ; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0190 install mcstrans"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0190 no install mcstrans"
    fi
	
autofs01=`systemctl is-active crond`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0191 enable crond "$autofs01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0191 disable crond "$autofs01
    fi
	
cramfs01=$(ls -l /etc/crontab | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0192 Check /etc/crontab is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0192 /etc/crontab no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/crontab)
    if [ $cramfs01 -le "644" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0193 Check /etc/crontab is 644 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0193 no 644"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.hourly)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0194 Check /etc/cron.hourly is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0194 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.hourly)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0195 Check /etc/cron.hourly is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0195 no 700"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.daily)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0196 Check /etc/cron.daily is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0196 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.daily)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0197 Check /etc/cron.daily is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0197 no 700"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.weekly)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0198 Check /etc/cron.weekly is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0198 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.weekly)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0199 Check /etc/cron.weekly is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0199 no 700"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.monthly)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0200 Check /etc/cron.monthly is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0200 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.monthly)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0201 Check /etc/cron.monthly is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0201 no 700"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.d)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0202 Check /etc/cron.d is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0202 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.d)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0203 Check /etc/cron.d is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0203 no 700"
    fi
	
###	TWGCB-01-012-0204 ####
#1
FRUIT=`if [ -f "/etc/cron.deny" ] && [ -f "/etc/at.deny" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "FAIL") 
   

###	TWGCB-01-012-0204 ####################################################################################
#1
FRUIT01=`if [ -f "/etc/cron.allow" ] && [ -f "/etc/at.allow" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
   case "$FRUIT01" in

       "SUCC") 
   

    audit01=`if [ -f "/etc/cron.allow" ] && [ -f "/etc/at.allow" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
    audit02=`stat -c '%U':'%G' /etc/cron.allow`
    audit03=`stat -c '%U':'%G' /etc/at.allow`
    if [ "$audit01" == "SUCC" ] && [ "$audit02" == "root:root" ] && [ "$audit03" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0204 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0204 check is error"
    fi


       ;;
       "FAIL") 
   
       echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0204 no /etc/at.allow /etc/cron.allow"
   
       ;;
       esac
##############################################################################


   ;;
   "SUCC") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0204 no del /etc/cron.deny /etc/cron.deny"
   
   ;;
esac
###TWGCB-01-012-0204########################################################

###	TWGCB-01-012-0205 ####
FRUIT=`if [ -f "/etc/cron.allow" ] && [ -f "/etc/at.allow" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /etc/cron.allow)
    cramfs02=$(stat -c %a /etc/at.allow)
    if [ $cramfs01 -le "600" ] && [ $cramfs02 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0205 Check /etc/cron.allow & /etc/at.allow is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0205 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0205 no /etc/cron.allow /etc/at.allow"
   
   ;;
esac
###	TWGCB-01-012-0205 ####

cramfs08=`grep -q -i "/var/log/cron.log" /etc/rsyslog.conf && echo 0 || echo 1`
    if [ "$cramfs08" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0206 /etc/rsyslog.conf ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0206 should be different to add /var/log/cron.log"
    fi
	
  audit03=`grep -q -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*\s+retry=\S+\s*.*$' /etc/pam.d/system-auth && echo 0 || echo 1`
  audit04=`grep -q -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*\s+retry=\S+\s*.*$' /etc/pam.d/password-auth && echo 0 || echo 1`
    if [ "$audit03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0207 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0207 check is error"
    fi
	
 audit03=`grep -q -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*enforce_for_root\s*.*$' /etc/pam.d/password-auth && echo 0 || echo 1`
 audit04=`grep -q -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*\s+retry=\S+\s*.*$' /etc/pam.d/password-auth && echo 0 || echo 1`
    if [ "$audit03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0208 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0208 check is error"
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*minlen[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "12" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0209 minlen = 12"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0209 minlen = 12"
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*minclass[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "4" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0210 minclass = 4 "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0210 minclass = 4 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*dcredit[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "-1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0211 dcredit = -1 "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0211 dcredit = -1 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*ucredit[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "-1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0212 ucredit = -1  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0212 ucredit = -1  "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*lcredit[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "-1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0213 lcredit = -1  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0213 lcredit = -1"
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*ocredit[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "-1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0214 ocredit = -1  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0214 ocredit = -1"
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*difok[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "3" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0215 difok = 3  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0215 difok = 3 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*maxclassrepeat[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "4" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0216 maxclassrepeat = 4 "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0216 maxclassrepeat = 4 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*maxrepeat[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "3" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0217 maxrepeat = 3  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0217 maxrepeat = 3 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*dictcheck[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0218 dictcheck = 1  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0218 dictcheck = 1 "
    fi
	
###TWGCB-01-012-0219########
SSHTEST=$(awk ' /^[[:space:]]*deny[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
FRUIT=`if [ -z $SSHTEST ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0219 no deny = 5 "
    
    
   ;;
   "FAIL") 
   
   SSHTEST=$(awk ' /^[[:space:]]*deny[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
    if [ "$SSHTEST" -le 5 -a "$SSHTEST" -gt 0 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0219 deny = 5"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0219 no deny = 5"
    fi
   
   ;;
esac
###TWGCB-01-012-0219########

###TWGCB-01-012-0220########
SSHTEST1=$(awk ' /^[[:space:]]*unlock_time[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
SSHTEST2=$(awk ' /^[[:space:]]*deny[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
FRUIT=`if [ $SSHTEST1 == "900" ] &&[ $SSHTEST2 == "5" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
   SSHTEST=$(awk ' /^[[:space:]]*unlock_time[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
    if [ "$SSHTEST" -ge 900 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0220 unlock_time = 900 & deny = 5"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0220 no unlock_time = 900 & deny = 5"
    fi
    
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0220 error "
    
   
   ;;
esac
###TWGCB-01-012-0220########

  audit03=`grep -q -E '^\s*password\s+(sufficient\s+pam_unix|requi(red|site)\s+pam_pwhistory).so\s+([^#]+\s+)*remember=\S+\s*.*$' /etc/pam.d/system-auth && echo 0 || echo 1`
  audit04=`grep -q -E '^\s*password\s+(sufficient\s+pam_unix|requi(red|site)\s+pam_pwhistory).so\s+([^#]+\s+)*remember=\S+\s*.*$' /etc/pam.d/password-auth && echo 0 || echo 1`
    if [ "$audit03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0221 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0221 check is error"
    fi
	
  audit03=`grep -q -E '^\s*session\s+required\s+pam_lastlog.so\s+showfailed' /etc/pam.d/postlogin && echo 0 || echo 1`
    if [ "$audit03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0222 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0222 check is error"
    fi
	
audit01=`awk '$1 == "session" && $2 == "required" && $3 == "pam_lastlog.so"' /etc/pam.d/postlogin | grep -q  "showfailed" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0223 /etc/pam.d/postlogin showfailed is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0223 should be different to /etc/pam.d/postlogin showfailed "
    fi
	
SSHTEST=$(cat /etc/login.defs | grep PASS_MIN_DAYS | grep -v ^# | awk '{print $2}')
    if [ "$SSHTEST" -ge "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0224 /etc/login.defs PASS_MIN_DAYS Check is (,chage --mindays 1 ) "$SSHTEST 
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0224 /etc/login.defs PASS_MIN_DAYS should be set to 1'"
    fi
	
passage=$(cat /etc/login.defs | grep PASS_WARN_AGE | grep -v ^# | awk '{print $2}')
    if [ "$passage" -ge "14" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0225 /etc/login.defs PASS_WARN_AGE Check is (,chage --warndays 14 ) "$SSHTEST 
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0225 /etc/login.defs PASS_WARN_AGE should be set to 14'"
    fi
	
passmax=$(cat /etc/login.defs | grep PASS_MAX_DAYS | grep -v ^# | awk '{print $2}')
    if [ "$passmax" -le 90 -a "$passmax" -gt 0 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0226 /etc/login.defs passmax Check is (,chage --maxdays 90 )"$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0226 /etc/login.defs passmax should be set to 90'"
    fi
	
SSHTEST=$(egrep ^[^:]+:[^\!*] /etc/shadow| egrep -v "^\s*#|root" | awk -F: '{print $1":"$7}' | egrep -v ".*:(30|[1-2][0-9]|[1-9])$")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0227 PASSWD is set 30 Day (,chage --inactive 30)"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0227 PASSWD should be set 30 Day account: "$SSHTEST
    fi
	
SSHTEST=$(awk 'toupper($1) == "FAIL_DELAY"  { print $2 }' /etc/login.defs)
    if [ "$SSHTEST" -eq "4" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0228 /etc/login.defs Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0228 /etc/login.defs should be set to 4'"
    fi
	
SSHTEST=$(awk 'toupper($1) == "CREATE_HOME"  { print $2 }' /etc/login.defs)
    if [ "$SSHTEST" == "yes" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0229 /etc/login.defs Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0229 /etc/login.defs should be set to yes'"
    fi
	#/etc/sudoers.d/*
	#find /etc/sudoers.d -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 640 ]; then echo $perm; exit 0; fi' \; | paste -s
SSHTEST=$(egrep -i '^[^#]*(nopasswd|!authenticate)' /etc/sudoers )
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0230 NOPASSWD & !authenticate is #"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0230 NOPASSWD & !authenticate should be set #"$SSHTEST
    fi
	
SSHTEST=$(awk '$1 == "*" && $2 == "hard" && $3 == "maxlogins" { print $4 }' /etc/security/limits.conf)
    if [ $SSHTEST == "10" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0231 * hard maxlogins 10  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0231 /etc/security/limits.conf should be different to * hard maxlogins 10 "
    fi
	
audit01=`rpm -q kbd.x86_64 | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0232 install kbd.x86_64"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0232 should be different to dnf install kbd.x86_64"
    fi
	
SSHTEST=$(awk '/^[[:space:]]*lock-enabled[[:space:]]*=[[:space:]]*/{print}' /etc/dconf/db/local.d/00-screensaver | cut -d= -f2)
    if [ $SSHTEST == "true" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0233 /etc/dconf/db/local.d/00-screensaver Check is "$SSHTEST
    else
	echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0233 /etc/dconf/db/local.d/00-screensaver should be set to true (PS.It’s a graphic, no settings required !!)'"
    fi
	
SSHTEST=$(awk '/^[[:space:]]*idle-delay[[:space:]]*=[[:space:]]*/{print}' /etc/dconf/db/local.d/00-screensaver | cut -d= -f2)
    if [ "$SSHTEST" == "uint32 900" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0234 /etc/dconf/db/local.d/00-screensaver Check is "$SSHTEST
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0234 /etc/dconf/db/local.d/00-screensaver should be set to uint32 900 (PS.It’s a graphic, no settings required !!)'"
    fi
	
SSHTEST=$(awk '/^\[daemon\]$/{flag=1; next} /^\[/{flag=0} flag && tolower($0) ~ /^[[:space:]]*automaticloginenable[[:space:]]*=[[:space:]]*/{print}' /etc/gdm/custom.conf | cut -d= -f2)
    if [ $SSHTEST == "false" > /dev/null 2>&1 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0235 /etc/gdm/custom.conf Check is "$SSHTEST
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0235 /etc/gdm/custom.conf should be set to false (PS.It’s a graphic, no settings required !!)'"
    fi
	
SSHTEST=$(awk -F: '($1!="root" && $1!~/^\+/ && $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"') {print $1}' /etc/passwd | xargs -I '{}' passwd -S '{}' | awk '($2!="L" && $2!="LK") {print $1}' | while read user; do usermod -L $user; done)
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0236 nologin"$SSHTEST
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0236 should be set"
    fi
	
cramfs06=`grep -q -E "TMOUT=900" /etc/bashrc && echo 0 || echo 1`
cramfs07=`grep -q -E "TMOUT=900" /etc/profile && echo 0 || echo 1`  
cramfs08=`grep -q -E "TMOUT=900" /etc/profile.d/*.sh && echo 0 || echo 1`
    if [ "$cramfs08" == "0" ] && [ "$cramfs07" == "0" ] && [ "$cramfs06" == "0" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0237 ok，readonly TMOUT=900 ; export TMOUT"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0237 on，readonly TMOUT=900 ; export TMOUT ((可手動設定)"
	
    fi
	
audit01=`awk '$1=="/org/gnome/desktop/session/idle-delay"' /etc/dconf/db/local.d/locks/session | grep -q -E "/org/gnome/desktop/session/idle-delay" && echo 0 || echo 1`
audit02=`awk '$1=="/org/gnome/desktop/screensaver/lock-enabled"' /etc/dconf/db/local.d/locks/session | grep -q -E "/org/gnome/desktop/screensaver/lock-enabled" && echo 0 || echo 1`
audit03=`awk '$1=="/org/gnome/desktop/screensaver/lock-delay"' /etc/dconf/db/local.d/locks/session | grep -q -E "/org/gnome/desktop/screensaver/lock-delay" && echo 0 || echo 1`
audit04=`awk '$1=="/org/gnome/desktop/lockdown/disable-lock-screen"' /etc/dconf/db/local.d/locks/session | grep -q -E "/org/gnome/desktop/lockdown/disable-lock-screen" && echo 0 || echo 1`
    if [ $audit01 == "0" ] && [ $audit02 == "0" ] && [ $audit03 == "0" ] && [ $audit04 == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0238 enable /etc/dconf/db/local.d/locks/session ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0238 should be different to vim /etc/dconf/db/local.d/locks/session (PS.It’s a graphic, no settings required !!)"
    fi
	
SSHTEST=$(grep '^root:' /etc/passwd | cut -d: -f4)
    if [ $SSHTEST == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0239 /etc/passwd Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0239 /etc/passwd should be set to GID 0'"
    fi
	
cramfs06=`grep -q -E "umask 027" /etc/bashrc && echo 0 || echo 1`
cramfs07=`grep -q -E "umask 027" /etc/profile && echo 0 || echo 1`  
cramfs08=`grep -q -E "umask 027" /etc/profile.d/*.sh && echo 0 || echo 1`
    if [ "$cramfs08" == "0" ] && [ "$cramfs07" == "0" ] && [ "$cramfs06" == "0" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0240 ok，umask 027"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0240 on，umask 027 (PS.TWGCB-01-012-0240 排除 (專案內系統有下載不同帳號創建檔的需求)"
	fi
	
SSHTEST=$(awk 'tolower($1) == "umask"  { print $2 }' /etc/login.defs | paste -sd ";")
    if [ $SSHTEST -le "027" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0241 027 或 以下 "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0241 should be different to 027 或 以下 (PS.TWGCB-01-012-0240 排除 (專案內系統有下載不同帳號創建檔的需求)"
    fi
	
audit01=`awk '$1 == "auth" && $2 == "required" && $3 == "pam_wheel.so" { print $4 }' /etc/pam.d/su`
audit02=`cat /etc/group | grep "wheel:x:10:" | cut -c12-`
    if [ "$audit01" == "use_uid" ] && [ "$audit02" == "alan" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0242 install use_uid & root,chtadmin"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0242 should be different to vim /etc/pam.d/su use_uid & root,XXXXX (可手動設定)"
    fi
	
audit01=`rpm -q firewalld | grep -q '尚未安裝' && echo 0 || echo 1`
audit02=`systemctl is-active firewalld`
    if [ "$audit01" -eq "1" ] && [ "$audit02" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0243 install firewalld & enable firewalld"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0243 should be different to dnf install firewalld"
    fi
	
firewalld01=`systemctl is-active firewalld`
    if [ $firewalld01 == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0244 "$firewalld01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0244 firewalld should be different to firewalld inactive"
    fi
	
iptables01=`systemctl is-enabled iptables`
    if [ "$iptables01" == "masked" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0245 "$iptables01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0245 should be different to iptables Failed to get unit file state for iptables.service: No such file or directory"
    fi
	
firewalld01=`systemctl is-enabled nftables`
    if [ $firewalld01 == "masked" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0246 "$firewalld01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0246 nftables should be different is inactive"
    fi
	
defaultzone01=`systemctl is-enabled nftables`
    if [ $defaultzone01 == "masked" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0247 "$defaultzone01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0247 should be different is-enabled nftables"
    fi
	
firewalld01=`systemctl is-active nftables`
    if [ $firewalld01 == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0248 "$firewalld01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0248 nftables should be different is inactive (排外，使用Firewalld)"
    fi
	
firewalld01=`systemctl is-enabled firewalld`
    if [ $firewalld01 == "enabled" ]; then
	echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0249 firewalld is enable"
	
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0249 firewalld is stop"
    fi
	
SSHTEST=$(nft list tables | grep -c "table")
    if [ $SSHTEST -ge "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0250 nft list tables Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0250 nft list tables to 0 以下'"
    fi
	
SSHTEST01=$(nft list table inet filter 2>/dev/null | grep -c "chain")
SSHTEST02=$(nft list table inet filter 2>/dev/null | grep -c "chain input")
SSHTEST03=$(nft list table inet filter 2>/dev/null | grep -c "chain output")
SSHTEST04=$(nft list table inet filter 2>/dev/null | grep -c "chain forward")
    if [ $SSHTEST01 == "1" ] && [ $SSHTEST02 == "1" ] && [ $SSHTEST03 == "1" ] && [ $SSHTEST04 == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0251 Check is ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0251 Check is error (排外，使用Firewalld)"
    fi
	
SSHTEST01=$(nft list table inet filter 2>/dev/null | awk '/chain input \{/,/\}/ { if (/iif "lo" /) { print } }' | awk '{ print $NF }')
SSHTEST02=$(nft list table inet filter 2>/dev/null | awk '/chain input \{/,/\}/ { if (/ip saddr 127\.0\.0\.0\/8 counter/) { print } }' | awk '{ print $NF }')
SSHTEST03=$(nft list table inet filter 2>/dev/null | awk '/chain input \{/,/\}/ { if (/ip6 saddr ::1 counter/) { print } }' | awk '{ print $NF }')
    if [ "$SSHTEST01" == "accept" ] && [ "$SSHTEST02" == "drop" ] && [ "$SSHTEST03" == "drop" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0252 Check is ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0252 Check is error (排外，使用Firewalld)"
    fi
	
SSHTEST01=$(nft list table inet filter 2>/dev/null | awk '/chain input \{/,/\}/ { if (/type filter hook input priority filter/) { print } }' | awk '{ print $(NF)}')
SSHTEST02=$(nft list table inet filter 2>/dev/null | awk '/chain forward \{/,/\}/ { if (/type filter hook forward priority filter/) { print } }' | awk '{ print $(NF)}')
SSHTEST03=$(nft list table inet filter 2>/dev/null | awk '/chain output \{/,/\}/ { if (/type filter hook output priority filter/) { print } }' | awk '{ print $(NF)}')
    if [ "$SSHTEST01" == "drop;" ] && [ "$SSHTEST02" == "drop;" ] && [ "$SSHTEST03" == "drop;" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0253 Check is ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0253 Check is error (排外，使用Firewalld)"
    fi
	
SSHTEST=$(grep -i "include" /etc/sysconfig/nftables.conf | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0254 include /etc/sysconfig/nftables.conf should be set to rm '#' (排外，使用Firewalld)"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0254 rm '#' is ok"
    fi
	
audit01=`rpm -q openssh-server | grep -q '尚未安裝' && echo 0 || echo 1`
audit02=`systemctl is-active sshd.service`
    if [ "$audit01" -eq "1" ] && [ "$audit02" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0255 install openssh-server & enable sshd.service"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0255 should be different to dnf install openssh-server & enable sshd.service"
    fi
	
ssh01=`awk '$1=="Protocol" {print $2}' /etc/ssh/sshd_config`
    if [ "$ssh01" == "2" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0256 Protocol 2"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0256  should be different to Protocol 2"
    fi

cramfs01=$(ls -l /etc/ssh/sshd_config | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0257 Check /etc/ssh/sshd_config is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0257 no root:root"
    fi
	
###	TWGCB-01-012-0258 ####
FRUIT=`if [ -f "/etc/ssh/sshd_config" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /etc/ssh/sshd_config)
    if [ $cramfs01 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0258 Check /etc/ssh/sshd_config is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0258 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0258 no /etc/cron.allow /etc/at.allow"
   
   ;;
esac
###	TWGCB-01-012-0258 ####

SSHTEST01=$(grep -i "AllowUsers" /etc/ssh/sshd_config | grep -v "#")
SSHTEST02=$(awk '$1 ~ /^(AllowUsers|AllowGroups|DenyUsers|DenyGroups)$/ {print $1,$2,$3,$4,$5}' /etc/ssh/sshd_config | paste -sd ";")
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0259 PasswordAuthentication should be set to 'AllowUsers ...(可設定)'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0259 "$SSHTEST02 
    fi
	
SSHTEST=$(ls -l /etc/ssh/ssh_host_*_key | awk '{print $3 ":" $4}' | paste -sd ";")
    if [ $SSHTEST == "root:ssh_keys;root:ssh_keys;root:ssh_keys" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0260 /etc/ssh/ssh_host_*_key Check is Linux 8: root:root Linux 9: root:ssh_keys "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0260 /etc/ssh/ssh_host_*_key should be set to Linux 8: root:root Linux 9: root:ssh_keys"
    fi
	
SSHTEST01=$(ls -l /etc/ssh/ssh_host_*_key | cut -c 1-10 | paste -sd ";")
    if [ "$SSHTEST01" == "-rw-r-----;-rw-r-----;-rw-r-----" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0261 PASS"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0261 ERROR"
    fi
	
SSHTEST01=`ls -l /etc/ssh/ssh_host_*_key.pub | awk '{print $3 ":" $4}' | paste -sd ";" | grep -q "root:root;root:root;root:root" && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0262 PASS "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0262 ERROR"
    fi
	
SSHTEST01=`ls -l /etc/ssh/ssh_host_*_key.pub | cut -c 1-10 | paste -sd ";" | grep -q '^[-]'"rw-r--r--;-rw-r--r--;-rw-r--r--" && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0263 PASS "	
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0263 ERROR"
    fi
	
SSHTEST01=`awk '$1=="Ciphers" {print $2}' /etc/ssh/sshd_config | head -n 1 | grep -q "aes128-ctr,aes192-ctr,aes256-ctr" && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0264 PASS "	
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0264 ERROR"
    fi
	
SSHTEST=$(grep -i "LogLevel VERBOSE" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0265 LogLevel should be set to 'VERBOSE'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0265 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "X11Forwarding no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0266 X11Forwarding should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0266 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "MaxAuthTries 4" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0267 MaxAuthTries should be set to '4'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0267 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "IgnoreRhosts yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0268 IgnoreRhosts should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0268 "$SSHTEST
    fi	
	
SSHTEST=$(grep -i "HostbasedAuthentication no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0269 HostbasedAuthentication should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0269 $SSHTEST (可手動設定)"
    fi
	
SSHTEST=$(grep -i "PermitRootLogin no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0270 PermitRootLogin should be set to no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0270 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "PermitEmptyPasswords no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0271 PermitEmptyPasswords should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0271 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "PermitUserEnvironment no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0272 PermitUserEnvironment should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0272 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "ClientAliveInterval 600" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0273 ClientAliveInterval should be set to '600'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0273 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "LoginGraceTime 60" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0274 ClientAliveCountMax should be set to '60'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0274 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "UsePAM yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0275 ClientAliveCountMax should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0275 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "AllowTcpForwarding no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0276 AllowTcpForwarding should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0276 "$SSHTEST
    fi

SSHTEST=$(grep -i "maxstartups 10:30:60" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0277 maxstartups should be set to '10:30:60'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0277 "$SSHTEST
    fi

SSHTEST=$(grep -i "MaxSessions 4" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0278 MaxSessions should be set to '4'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0278 "$SSHTEST
    fi

SSHTEST=$(grep -i "StrictModes yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0279 StrictModes should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0279 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "Compression no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0280 Compression should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0280 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "IgnoreUserKnownHosts yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0281 TCPKeepAlive should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0281 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "PrintLastLog yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0282 PrintLastLog should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0282 "$SSHTEST
    fi
	
SSHTEST01=`find / -name shosts.equiv 2>/dev/null && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0283 PASS "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0283 ERROR"
    fi
	
SSHTEST01=`find / -name *.shosts 2>/dev/null && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0284 PASS "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0284 ERROR"
    fi
	
SSHTEST01=`awk '$1 ~ /^CRYPTO_POLICY/ {print $0}' /etc/sysconfig/sshd | paste -sd ";" | grep -q ""  && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-012-0285 PASS "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-012-0285 ERROR"
    fi

sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
######################################################################################################
 
           show_menu;
        ;;
        77) clear;
            option_picked "Option 77 Picked";

######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 77. GCB Check for Red Hat 8.10 (2024/12/08)/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo


####################################### Red Hat 9 SYSTEM AND SECURITY CHECK #######################################

audit01=`awk '$1 == "install" && $2 == "cramfs" && $3 == "/bin/true"'  /etc/modprobe.d/cramfs.conf  | grep -q "install cramfs /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "cramfs"'  /etc/modprobe.d/cramfs.conf  | grep -q "blacklist cramfs" && echo 0 || echo 1`
audit03=`lsmod | grep cramfs &> /dev/null | grep -q "cramfs" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0001 rmmod cramfs is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0001 should be different to rmmod cramfs "
    fi

audit01=`awk '$1 == "install" && $2 == "squashfs" && $3 == "/bin/true"' /etc/modprobe.d/squashfs.conf | grep -q "install squashfs /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "squashfs"' /etc/modprobe.d/squashfs.conf  | grep -q "blacklist squashfs" && echo 0 || echo 1`
audit03=`lsmod | grep squashfs  | grep -q "squashfs" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0002 rmmod squashfs is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0002 should be different to rmmod squashfs "
    fi

audit01=`awk '$1 == "install" && $2 == "udf" && $3 == "/bin/true"' /etc/modprobe.d/udf.conf  | grep -q "install udf /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "udf"' /etc/modprobe.d/udf.conf  | grep -q "blacklist udf"  && echo 0 || echo 1`
audit03=`lsmod | grep udf | grep -q "udf"  && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0003 rmmod udf is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0003 should be different to rmmod udf "
    fi
	
audit01=`awk '$1 == "tmpfs" && $2 == "/tmp" && $3 == "tmpfs" && $4 == "defaults,rw,nosuid,nodev,noexec,relatime" && $5 == "0" && $6 == "0" ' /etc/fstab`
tmpfs01=`df "/tmp" | grep -q "tmpfs" && echo 0 || echo 1`
    if [ "$audit01" == "tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0" ] && [ "$tmpfs01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0004-0007 tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0004-0007 should be different to tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0"
    fi
	
tmpfs01=`lvs -o name | grep -q "var" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0008 /var is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0008 should be different to /var is not LVM "
    fi

tmpfs01=`lvs -o name | grep -q "var_tmp" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0009 /var/tmp is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0009 should be different to /var/tmp is not LVM "
    fi

audit01=`awk '$2 == "/var/tmp" && $4 ' /etc/fstab | grep -q "nodev" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0010 /var/tmp ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0010 should be different to /var/tmp ckeck add nodev"
    fi

audit01=`awk '$2 == "/var/tmp" && $4 ' /etc/fstab | grep -q "nosuid" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0011 /var/tmp ckeck add nosuid is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0011 should be different to /var/tmp ckeck add nosuid"
    fi

audit01=`awk '$2 == "/var/tmp" && $4 ' /etc/fstab | grep -q "noexec" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0012 /var/tmp ckeck add noexec is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0012 should be different to /var/tmp ckeck add noexec"
    fi

tmpfs01=`lvs -o name | grep -q "var_log" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0013 /var/log is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0013 should be different to /var/log is not LVM "
    fi

tmpfs01=`lvs -o name | grep -q "var_log_audit" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0014 /var/log/audit is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0014 should be different to /var/log/audit is not LVM "
    fi

tmpfs01=`lvs -o name | grep -q "home" && echo 0 || echo 1`
    if [ "$tmpfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0015 /home is LVM"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0015 should be different to /home is not LVM "
    fi

audit01=`awk '$2 == "/home" && $4 ' /etc/fstab | grep -q "nodev" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0016 /home ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0016 should be different to /home ckeck add nodev"
    fi

audit01=`awk '$2 == "/dev/shm" && $4 ' /etc/fstab | grep -q "nodev" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0017 /dev/shm ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0017 should be different to /dev/shm ckeck add nodev"
    fi
	
audit01=`awk '$2 == "/dev/shm" && $4 ' /etc/fstab | grep -q "nosuid" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0018 /dev/shm ckeck add nosuid is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0018 should be different to /dev/shm ckeck add nosuid"
    fi
	
audit01=`awk '$2 == "/dev/shm" && $4 ' /etc/fstab | grep -q "noexec" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0019 /dev/shm ckeck add noexec is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0019 should be different to /dev/shm ckeck add noexec"
    fi
	
audit01=`mount | grep "/dev/sr" && echo 0 || echo 1`
audit02=`mount | grep /dev/sr | grep -q "nodev" && echo 0 || echo 1`
    if [ "$audit01" == "1" ] ; then
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0020 no /dev/sr* device "
    elif [ "$audit02" == "0" ] ; then
		echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0020 /dev/sr* ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0020 should be different to no /dev/sr* ckeck add nodev "
    fi
	
audit01=`mount | grep "/dev/sr" && echo 0 || echo 1`
audit02=`mount | grep /dev/sr | grep -q "nosuid" && echo 0 || echo 1`
    if [ "$audit01" == "1" ] ; then
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0021 no /dev/sr* device "
    elif [ "$audit02" == "0" ] ; then
		echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0021 /dev/sr* ckeck add nosuid is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0021 should be different to no /dev/sr* ckeck add nosuid "
    fi
	
audit01=`mount | grep "/dev/sr" && echo 0 || echo 1`
audit02=`mount | grep /dev/sr | grep -q "noexec" && echo 0 || echo 1`
    if [ "$audit01" == "1" ] ; then
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0022 no /dev/sr* device "
    elif [ "$audit02" == "0" ] ; then
		echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0022 /dev/sr* ckeck add noexec is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0022 should be different to no /dev/sr* ckeck add noexec "
    fi
	
audit02=`grep -q -P '^(?=.*/home/*)(?=.*nodev)(?=.*noexec)(?=.*nosuid)' /etc/fstab && echo 0 || echo 1`
    if [ "$audit02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0023-0025 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0023-0025 check is error"
    fi
	
 audit01=`awk '$3 == "nfs"' /etc/fstab | grep -q -P '^(?=.*nodev)(?=.*noexec)(?=.*nosuid)' && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0026-28 nfs ckeck add nodev is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0026-28 should be different to nfs ckeck add nodev (可排外，如無掛載NFS)"
    fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a -perm -1000 \)`
    if [ -z cramfs08 ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0029 check World-writable ok"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0029 具有全域寫入(World-writable)權限之目錄是需設定粘滯位 (可排外,確保只有擁有者才能刪除或更名自己建立之檔案，以防止使用者任意刪除或更名其他使用者所建立之檔案)" 
	fi
	
autofs01=`systemctl is-active autofs`
    if [ "$autofs01" == "inactive" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0030 "should be different to autofs Disable
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0030 should be different to autofs start for autofs.service"
    fi
	
audit01=`awk '$1 == "install" && $2 == "usb-storage" && $3 == "/bin/true"'  /etc/modprobe.d/usb-storage.conf  | grep -q "install usb-storage /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "usb-storage"'  /etc/modprobe.d/usb-storage.conf  | grep -q "blacklist usb-storage" && echo 0 || echo 1`
audit03=`lsmod | grep  usb-storage  | grep -q "usb-storage" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0031 rmmod usb-storage is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0031 should be different to rmmod usb-storage "
    fi
	
###	TWGCB-01-008-0032 ####
#1
FRUIT=`if [ -f "/etc/yum.conf" ] && [ -f "/etc/dnf/dnf.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    SSHTEST01=$(grep -i '^[[:space:]]*gpgcheck[[:space:]]*=' /etc/yum.conf | awk -F= '{gsub(/[    ]/, "", $2); print $2}')
    SSHTEST02=$(grep -i '^[[:space:]]*gpgcheck[[:space:]]*=' /etc/dnf/dnf.conf | awk -F= '{gsub(/[    ]/, "", $2); print $2}')
    if [ "$SSHTEST01" == "1" ] && [ "$SSHTEST02" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0032 gpgcheck = 1"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0032 no gpgcheck = 1"
    fi

    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0032 no gpgcheck = 1"
   
   ;;
esac

###	TWGCB-01-008-0032 ####

audit01=`rpm -q sudo | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0033 install sudo"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0033 should be different to dnf install sudo"
    fi

SSHTEST01=`grep -i "Defaults     use_pty" /etc/sudoers | grep -q -v "#" && echo 0 || echo 1`
    if [ "$SSHTEST01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0034 /etc/sudoers Defaults use_pty  ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0034 /etc/sudoers should be set to Defaults use_pty (手動設定)"
    fi
	
SSHTEST01=`awk ' /^[[:space:]]*Defaults     logfile[[:space:]]*=[[:space:]]*/{print}' /etc/sudoers |grep -i "/var/log/sudo.log" | grep -q -v ^# && echo 0 || echo 1`
    if [ "$SSHTEST01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0035 /etc/sudoers Defaults logfile  ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0035 /etc/sudoers should be set to Defaults logfile (手動設定)"
    fi

audit01=`rpm -q aide | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0036 install aide"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0036 should be different to dnf install aide"
    fi
	
cramfs01=$(crontab -l | awk '{print $1 $2 $3 $4 $5 $6 $7}' | grep -q '[0-9].*'***/usr/sbin/aide--check && echo 0 || echo 1)
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0037 Check 05***/usr/sbin/aide--check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0037 no 05***/usr/sbin/aide--check"
    fi
cramfs01=$(ls -l /boot/grub2/grub.cfg | awk '{print $3 ":" $4}')
cramfs02=$(ls -l /boot/grub2/grubenv | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] && [ "$cramfs02" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0038 Check /var/log/messages is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0038 no root:root"
    fi	
	
###	TWGCB-01-008-0039 ####
#1
FRUIT=`if [ -f "/boot/grub2/grub.cfg" ] && [ -f "/boot/grub2/grubenv" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /boot/grub2/grub.cfg)
	cramfs02=$(stat -c %a /boot/grub2/grubenv)
    if [ $cramfs01 -le "600" ] && [ $cramfs02 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0039 Check /boot/grub2/grubenv /boot/grub2/grub.cfg is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0039 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0039 no /boot/grub2/grubenv /boot/grub2/grub.cfg"
   
   ;;
esac

###	TWGCB-01-008-0039 ####

#https://bhanuwriter.com/how-to-set-grub2-password/
    if [ -f "/boot/grub2/user.cfg" ] ; then   echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0040 grub2-setpassword建立一組通行碼 OK" ; else   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0040 no grub2-setpassword建立一組通行碼 ok"; fi

SSHTEST01=$(grep -i '^[[:space:]]*ExecStart[[:space:]]*=' /usr/lib/systemd/system/rescue.service | awk -F= '{gsub(/[    ]/, "", $2); print $2}')
SSHTEST02=$(grep -i '^[[:space:]]*ExecStart[[:space:]]*=' /usr/lib/systemd/system/emergency.service | awk -F= '{gsub(/[    ]/, "", $2); print $2}')
    if [ "$SSHTEST01" == "-/usr/lib/systemd/systemd-sulogin-shellrescue" ] && [ "$SSHTEST02" == "-/usr/lib/systemd/systemd-sulogin-shellemergency" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0041 check ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0041 error"
    fi
	
SSHTEST01=$(grep -q -i '^[*]'"               hard    core            0" /etc/security/limits.conf && echo 0 || echo 1)
SSHTEST02=$(grep -q -i "fs.suid_dumpable=0" /etc/sysctl.conf && echo 0 || echo 1)
SSHTEST03=$(grep -q -i "Storage=none" /etc/systemd/coredump.conf && echo 0 || echo 1)
SSHTEST04=$(grep -q -i "ProcessSizeMax=0" /etc/systemd/coredump.conf && echo 0 || echo 1)
    if [ "$SSHTEST01" == "0" ] && [ "$SSHTEST02" == "0" ] && [ "$SSHTEST03" == "0" ] && [ "$SSHTEST04" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0042 check ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0042 error (可設定)"
    fi
	
SSHTEST01=$(grep -q -i "kernel.randomize_va_space=2" /etc/sysctl.conf && echo 0 || echo 1)
    if [ "$SSHTEST01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0043 check ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0043 error (可設定)"
    fi
	
SSHTEST=$(grep -q -E -i '^\s*(FUTURE|FIPS)\s*(\s+#.*)?$' /etc/crypto-policies/config && echo 0 || echo 1)
    if [ "$SSHTEST" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0044 Check ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0044 error (排外，會影響Client無法使用YUM)"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/passwd)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0045 /etc/passwd Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0045 /etc/passwd should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/passwd)
    if [ $SSHTEST -le "644" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0046 /etc/passwd Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0046 /etc/passwd should be set to 644 或 以下'"
    fi

SSHTEST=$(stat -c '%U':'%G' /etc/shadow)
SHADOW=$(stat -c '%U':'%G' /etc/shadow)
    if [ "$SSHTEST" == "root:root" -o "$SHADOW" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0047 /etc/shadow Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0047 /etc/shadow should be set to root:root or root:shadow'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/shadow)
    if [ $SSHTEST == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0048 /etc/shadow Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0048 /etc/shadow should be set to 000'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/group)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0049 /etc/group Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0049 /etc/group should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/group)
    if [ $SSHTEST -le "644" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0050 /etc/group Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0050 /etc/group should be set to 644 或 以下'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/gshadow)
SHADOW=$(stat -c '%U':'%G' /etc/gshadow)
    if [ "$SSHTEST" == "root:root" -o "$SHADOW" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0051 /etc/gshadow Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0051 /etc/gshadow should be set to root:root or root:shadow'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/gshadow)
    if [ $SSHTEST == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0052 /etc/gshadow Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0052 /etc/gshadow should be set to 000'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/passwd-)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0053 /etc/passwd- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0053 /etc/passwd- should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/passwd-)
    if [ $SSHTEST -le "644" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0054 /etc/passwd- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0054 /etc/passwd- should be set to 644 或 以下'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/shadow-)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0055 /etc/shadow- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0055 /etc/shadow- should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/shadow-)
    if [ $SSHTEST == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0056 /etc/shadow- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0056 /etc/shadow- should be set to 000'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/group-)
    if [ "$SSHTEST" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0057 /etc/group- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0057 /etc/group- should be set to root:root'"
    fi
	
SSHTEST=$(stat -c '%a' /etc/group-)
    if [ $SSHTEST -le "644" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0058 /etc/group- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0058 /etc/group- should be set to 644 或 以下'"
    fi
	
SSHTEST=$(stat -c '%U':'%G' /etc/gshadow-)
SHADOW=$(stat -c '%U':'%G' /etc/gshadow-)
    if [ "$SSHTEST" == "root:root" -o "$SHADOW" == "root:root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0059 /etc/gshadow- Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0059 /etc/gshadow- should be set to root:root or root:shadow'"
    fi
	
cramfs01=$(stat -c %a /etc/gshadow-)
    if [ $cramfs01 -le "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0060 Check /etc/gshadow- is 0 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0060 no 0"
    fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type f \( -perm -0002 -print \)`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0061 無，具有全域寫入權限之(World-writable)之檔案"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0061 有，針對所找到之檔案，執行chmod o-w指令，以移除其他身分寫入權限" 
	fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -nouser`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0062 無，找出擁有者不是合法user之檔案或目錄"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0062 有，找出擁有者不是合法user之檔案或目錄" 
	fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -nogroup`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0063 無，找出擁有群組不是合法群組之檔案或目錄"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0063 有，找出擁有群組不是合法群組之檔案或目錄" 
	fi
	
cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -uid +999 -print \)`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0064 無，具有全域寫入權限目錄之擁有者"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0064 有，具有全域寫入權限目錄之擁有者" 
	fi

cramfs08=`df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -gid +999 -print \)`
    if [ -z "$cramfs08" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0065 無，具有全域寫入權限之目錄擁有群組為root或其他系統群組"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0065 有，具有全域寫入權限之目錄擁有群組為root或其他系統群組" 
	fi
	
SSHTEST01=$(find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 755 ]; then echo $perm; exit 0; fi' \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0066 is 755 "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0066 should be set to chmod 755"
    fi

SSHTEST01=$(find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -user root -exec sh -c 'owner=$(ls -ld "$1" | awk "{print \$3}"); if [ "$owner" != "root" ]; then echo $owner; exit 0; else exit 1; fi' sh {} \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0067 is root "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0067 should be set to chown root"
    fi
	
SSHTEST01=$(find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -group root ! -group tty ! -group slocate ! -group lock -exec sh -c 'group=$(ls -ld "$1" | awk "{print \$4}"); if [ "$group" != "root" ]; then echo $group; exit 0; else exit 1; fi' sh {} \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0068 is root "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0068 should be set to chgrp root"
    fi
	
SSHTEST01=$(find /usr/lib /usr/lib64 -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 755 ]; then echo $perm; exit 0; fi' \; -quit)
SSHTEST02=$(find /usr/lib64 -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 755 ]; then echo $perm; exit 0; fi' \; -quit)    
    if [ "$SSHTEST01" == "777" ] && [ "$SSHTEST02" == "777" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0069 should be set to chmod 755"	
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0069 is 755 or 755 down"
    fi
	
SSHTEST01=$(find -L /lib /lib64 /usr/lib /usr/lib64 ! -user root -exec sh -c 'owner=$(ls -ld "$1" | awk "{print \$3}"); if [ "$owner" != "root" ]; then echo $owner; exit 0; else exit 1; fi' sh {} \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0070 is root "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0070 should be set to #chown root"
    fi
	
SSHTEST01=$(find -L /lib /lib64 /usr/lib /usr/lib64 ! -group root -exec sh -c 'group=$(ls -ld "$1" | awk "{print \$4}"); if [ "$group" != "root" ]; then echo $group; exit 0; else exit 1; fi' sh {} \; -quit)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0071 is root "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0071 should be set to chgrp root"
    fi
	
SSHTEST01=$(awk -F: '($2 == "" ) { print $1 "_attension!"}' /etc/shadow | head -n 1)
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0072 pass "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0072 should be set to passwd -l"
    fi
	
SSHTEST01=$(echo $PATH | tr ':' ' ' | awk '/^\.$|^\.\.$|^[^\/]/ && length($0) > 0 {print; exit}')
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0073 pass "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0073 should be set to /etc/profile"
    fi
	
SSHTEST01=$(echo $PATH | tr ':' ' ' | (while read -r dir; do if [ -d "$dir" ]; then perm=$(stat -c "%A" "$dir"); if [[ "$perm" == *'w'* ]]; then echo "$dir - $perm"; exit 0; fi; fi; done))
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0074 pass "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0074 should be set to /etc/profile"
    fi
	
SSHTEST=$(grep -m 1 '^\+:' /etc/passwd)
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0075 grep -m 1 '^\+:' /etc/passwd is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0075 grep -m 1 '^\+:' /etc/passwd del + "$SSHTEST
    fi
	
SSHTEST=$(grep -m 1 '^\+:' /etc/shadow)
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0076 grep -m 1 '^\+:' /etc/shadow is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0076 grep -m 1 '^\+:' /etc/shadow del + "$SSHTEST
    fi
	
SSHTEST=$(grep -m 1 '^\+:' /etc/group)
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0077 grep -m 1 '^\+:' /etc/group is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0077 grep -m 1 '^\+:' /etc/group del + "$SSHTEST
    fi
	
SSHTEST=$(awk -F: '($3 == 0) { print $1 }' /etc/passwd)
    if [ "$SSHTEST" == "root" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0078 Check ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0078 error"
    fi
	
######TWGCB-01-008-0079######
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 !="/bin/false") { print $1 " " $6 }' | while read user dir; do
 if [ ! -d "$dir" ]; then
 echo "The home directory ($dir) of user $user does not exist." >> /root/TWGCB-01-008-0079.log
 else
 dirperm=$(ls -ld $dir | cut -f1 -d" ")
 if [ $(echo $dirperm | cut -c6) != "-" ]; then
 echo "Group Write permission set on the homedirectory ($dir) of user$user" >> /root/TWGCB-01-008-0079.log
 fi 
 if [ $(echo $dirperm | cut -c8) != "-" ]; then
 echo "Other Read permission set on the home directory ($dir) of user$user" >> /root/TWGCB-01-008-0079.log
 fi
 if [ $(echo $dirperm | cut -c9) != "-" ]; then
 echo "Other Write permission set on the home directory ($dir) of user$user" >> /root/TWGCB-01-008-0079.log
 fi
 if [ $(echo $dirperm | cut -c10) != "-" ]; then
echo "Other Execute permission set on the home directory ($dir) of user$user" >> /root/TWGCB-01-008-0079.log
 fi
 fi
done

cramfs01=`grep -q "/" /root/TWGCB-01-008-0079.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0079 Check ok "
		rm -rf /root/TWGCB-01-008-0079.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0079 error (如有腳本，可評估排外)"
		rm -rf /root/TWGCB-01-008-0079.log
    fi
######TWGCB-01-008-0079###############################################

#######################TWGCB-01-008-0080##############################

#
grep -q -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
do
 if [ ! -d "$dir" ]; then
 echo "The home directory ($dir) of user $user does not exist." >> /root/TWGCB-01-008-0080.log
 #else
 #owner=$(stat -L -c "%U" "$dir")
 #if [ "$owner" != "$user" ]; then
 #echo "The home directory ($dir) of user $user is owned by $owner."
 #fi
fi
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0082.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
cramfs01=`grep -q "does not exist" /root/TWGCB-01-008-0080.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0080 Check ok " 
		rm -rf  /root/TWGCB-01-008-0082.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0080 error (可排外，如有腳本使用)"
		rm -rf  /root/TWGCB-01-008-0082.log
    fi  

   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0080 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0080##############################	



	
#
#######################TWGCB-01-008-0081##############################

#
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $4 " " $6 }' | while read user gid dir; 
do
 if [ ! -d "$dir" ]; then
 echo "The home directory ($dir) of user $user does not exist." >> /root/TWGCB-01-008-0081.log
 #else
 #owner=$(stat -L -c "%g" "$dir")
 #if [ "$owner" != "$gid" ]; then
 #echo "The home directory ($dir) of group $gid is owned by group $owner."
 #fi
fi
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0081.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
cramfs01=`grep -q "does not exist" /root/TWGCB-01-008-0081.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0081 Check ok "
		rm -rf  /root/TWGCB-01-008-0081.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0081 error (可排外)"
		rm -rf  /root/TWGCB-01-008-0081.log
    fi   

   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0081 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0081##############################


#
#######################TWGCB-01-008-0082##############################

#
grep -E -v '^(halt|sync|shutdown)' /etc/passwd | awk -F: '($7 !="'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
do
 if [ ! -h "$file" -a -f "$file" ]; then
        fileperm=$(ls -ld $file | cut -f1 -d" ")
 if [ $(echo $fileperm | cut -c6) != "-" ]; then
     echo "Group Write permission set on file $file" >> /root/TWGCB-01-008-0082.log
fi
 if [ $(echo $fileperm | cut -c9) != "-" ]; then
     echo "Other Write permission set on file $file" >> /root/TWGCB-01-008-0082.log
 fi
fi
 done

FRUIT=`if [ -f "/root/TWGCB-01-008-0082.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q "Write permission set" /root/TWGCB-01-008-0082.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0082 Check ok "
		rm -rf  /root/TWGCB-01-008-0082.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0082 error"
		rm -rf  /root/TWGCB-01-008-0082.log
    fi
  
   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0082 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0082##############################

	
#
#######################TWGCB-01-008-0083##############################

#
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
 do
 if [ ! -h "$dir/.forward" -a -f "$dir/.forward" ]; then
     echo ".forward file $dir/.forward exists" >> /root/TWGCB-01-008-0083.log
 fi
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0083.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q "forward exists" /root/TWGCB-01-008-0083.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0083 Check ok "
		rm -rf  /root/TWGCB-01-008-0083.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0083 error"
		rm -rf  /root/TWGCB-01-008-0083.log
    fi
  
   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0083 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0083##############################


	
#
#######################TWGCB-01-008-0084##############################

#
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
do
 if [ ! -h "$dir/.netrc" -a -f "$dir/.netrc" ]; then
    echo ".netrc file $dir/.netrc exists" >> /root/TWGCB-01-008-0084.log
 fi
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0084.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q "netrc exists" /root/TWGCB-01-008-0084.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0084 Check ok "
		rm -rf  /root/TWGCB-01-008-0084.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0084 error"
		rm -rf  /root/TWGCB-01-008-0084.log
    fi   
  
   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0084 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0084##############################


	
#
#######################TWGCB-01-008-0085##############################

#
grep -E -v '^(root|halt|sync|shutdown)' /etc/passwd | awk -F: '($7 != "'"$(which nologin)"'" && $7 != "/bin/false") { print $1 " " $6 }' | while read user dir;
do
 for file in $dir/.rhosts;
 do
    if [ ! -h "$file" -a -f "$file" ]; then
       echo ".rhosts file in $dir" >> /root/TWGCB-01-008-0085.log
    fi
 done
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0085.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q "rhosts file" /root/TWGCB-01-008-0085.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0085 Check ok " 
		rm -rf  /root/TWGCB-01-008-0085.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0085 error"
		rm -rf  /root/TWGCB-01-008-0085.log
    fi  

   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0085 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0085##############################
	
#######################TWGCB-01-008-0086##############################

#
for i in $(cut -s -d: -f4 /etc/passwd | sort -u );
do
 grep -q -P "^.*?:[^:]*:$i:" /etc/group
    if [ $? -ne 0 ]; then
      echo "Group $i is referenced by /etc/passwd but does not exist in /etc/group" >> /root/TWGCB-01-008-0086.log
    fi
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0086.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "/etc/passwd" /root/TWGCB-01-008-0086.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0086 Check ok "
		rm -rf  /root/TWGCB-01-008-0086.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0086 Check error"
		rm -rf  /root/TWGCB-01-008-0086.log
    fi

   ;;
   "FAIL") 

        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0086 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0086##############################


######################TWGCB-01-008-0087##############################

#
cut -f3 -d":" /etc/passwd | sort -n | uniq -c | while read x ;
do
 [ -z "$x" ] && break
 set - $x
    if [ $1 -gt 1 ]; then
       users=$(awk -F: '($3 == n) { print $1 }' n=$2 /etc/passwd | xargs)
       echo "Duplicate UID ($2): $users" >> /root/TWGCB-01-008-0087.log
    fi
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0087.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "Duplicate UID" /root/TWGCB-01-008-0087.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0087 Check ok "
		rm -rf  /root/TWGCB-01-008-0087.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0087 The Duplicate UID"
		rm -rf  /root/TWGCB-01-008-0087.log
    fi
   ;;
   "FAIL") 
   
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0087 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0087##############################

	
#
######################TWGCB-01-008-0088##############################

#
cut -d: -f3 /etc/group | sort | uniq -d | while read x ;
do
 echo "Duplicate GID ($x) in /etc/group" >> /root/TWGCB-01-008-0088.log
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0088.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "Duplicate GID" /root/TWGCB-01-008-0088.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0088 Check ok "
		rm -rf  /root/TWGCB-01-008-0088.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0088 Duplicate GID ($x) in /etc/group"
		rm -rf  /root/TWGCB-01-008-0088.log
    fi

   ;;
   "FAIL") 

    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0088 Check ok "

   ;; 
  
esac

######################TWGCB-01-008-0088##############################



######################TWGCB-01-008-0089##############################

#
cut -d: -f1 /etc/passwd | sort | uniq -d | while read x ;
do 
  echo "Duplicate login name ${x} in /etc/passwd" >> /root/TWGCB-01-008-0089.log
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0089.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "Duplicate UID" /root/TWGCB-01-008-0089.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0089 Check ok "
		rm -rf  /root/TWGCB-01-008-0089.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0089 Duplicate login name ${x} in /etc/passwd"
		rm -rf  /root/TWGCB-01-008-0089.log
    fi

   ;;
   "FAIL") 

    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0089 Check ok "  
	
   ;; 
  
esac

######################TWGCB-01-008-0089##############################




######################TWGCB-01-008-0090##############################

cut -d: -f1 /etc/group | sort | uniq -d | while read x ;
do 
  echo "Duplicate group name ${x} in /etc/group" >> /root/TWGCB-01-008-0090.log
done

FRUIT=`if [ -f "/root/TWGCB-01-008-0090.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=`grep -q "Duplicate group name" /root/TWGCB-01-008-0090.log && echo 0 || echo 1`
    if [ "$cramfs01" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0090 Check ok "
		rm -rf  /root/TWGCB-01-008-0090.log
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0090 Duplicate group name ${x} in /etc/group"
		rm -rf  /root/TWGCB-01-008-0090.log
    fi

   ;;
   "FAIL") 

   echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0090 Check ok "   
   ;; 
  
esac

######################TWGCB-01-008-0090##############################

	
cramfs01=`awk -F: '($1=="shadow") {print $NF}' /etc/group && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0091 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0091 /etc/group is users"
    fi
	
audit01=`rpm -q xinetd | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0092 remove xinetd"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0092 should be different to dnf remove xinetd"
    fi
	
cramfs01=`grep -i "server" /etc/chrony.conf | grep -v "#" | wc -l`
    if [ "$cramfs01" -ge "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0093 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0093 error (手動設定NTP Server)"
    fi
	
autofs01=`systemctl is-active rsyncd`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0094 active rsyncd "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0094 disable rsyncd "$autofs01
    fi
	
autofs01=`systemctl is-active avahi-daemon`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0095 active avahi-daemon "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0095 disable avahi-daemon "$autofs01
    fi
	
autofs01=`systemctl is-active snmpd`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0096 enable snmpd "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0096 disable snmpd "$autofs01
    fi
	
autofs01=`systemctl is-active squid`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0097 enable squid "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0097 disable squid "$autofs01
    fi
	
autofs01=`systemctl is-active smb`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0098 enable smb "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0098 disable smb "$autofs01
    fi
	
autofs01=`systemctl is-active vsftpd`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0099 enable vsftpd "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0099 disable vsftpd "$autofs01
    fi
	
autofs01=`systemctl is-active ypserv`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0100 enable ypserv "$autofs01
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0100 disable ypserv "$autofs01
    fi
	
autofs01=`systemctl is-active kdump.service`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0101 enable kdump.service "$autofs01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0101 disable kdump.service "$autofs01
    fi
	
audit01=`rpm -q ypbind | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0102 remove ypbind"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0102 should be different to dnf remove ypbind"
    fi
	
audit01=`rpm -q telnet | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0103 remove telnet"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0103 should be different to dnf remove telnet"
    fi
	
audit01=`rpm -q telnet-server | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0104 remove telnet-server"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0104 should be different to dnf remove telnet-server"
    fi
	
audit01=`rpm -q rsh-server | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0105 remove rsh-server"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0105 should be different to dnf remove rsh-server"
    fi
	
audit01=`rpm -q tftp-server | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0106 remove tftp-server"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0106 should be different to dnf remove tftp-server"
    fi
	
SSHTEST=$(cat /etc/dnf/dnf.conf | grep clean_requirements_on_remove | cut -c30-)
    if [ $SSHTEST == "True" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0107 clean_requirements_on_remove Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0107 clean_requirements_on_remove should be set to True'"
    fi
	
#https://www.cnblogs.com/eleclsc/p/11685092.html
SSHTEST01=$(cat /etc/sysctl.conf | grep -q net.ipv4.ip_forward=0 && echo 0 || echo 1)
SSHTEST02=$(cat /etc/sysctl.conf | grep -q net.ipv6.conf.all.forwarding && echo 0 || echo 1)
    if [ "$SSHTEST01" == "0" ] && [ "$SSHTEST02" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0108 net.ipv4.ip_forward net.ipv6.conf.all.forwarding Check is 0"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0108 net.ipv4.ip_forward net.ipv6.conf.all.forwarding should be set to 0'"
    fi
	
SSHTEST02=$(cat /etc/sysctl.conf | grep -q net.ipv4.conf.all.send_redirects=0 && echo 0 || echo 1)
    if [ $SSHTEST02 == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0109 net.ipv4.conf.all.send_redirects Check is "$SSHTEST02
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0109 net.ipv4.conf.all.send_redirects should be set to 0'"
    fi
	
SSHTEST02=$(cat /etc/sysctl.conf | grep -q net.ipv4.conf.default.send_redirects=0 && echo 0 || echo 1)
    if [ $SSHTEST02 == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0110 net.ipv4.conf.default.send_redirects Check is "$SSHTEST02
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0110 net.ipv4.conf.all.send_redirects should be set to 0'"
    fi
	
SSHTEST01=$(cat /etc/sysctl.conf | grep -q net.ipv4.conf.all.accept_source_route=0 && echo 0 || echo 1)
SSHTEST02=$(cat /etc/sysctl.conf | grep -q net.ipv6.conf.all.accept_source_route=0 && echo 0 || echo 1)
    if [ "$SSHTEST01" == "0" ] && [ "$SSHTEST02" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0111 net.ipv4-6.conf.all.accept_source_route Check is 0"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0111 net.ipv4-6.conf.all.accept_source_route should be set to 0'"
    fi
	
if grep -qE "^net.ipv4.conf.default.accept_source_route\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0112 net.ipv4.conf.default.accept_source_route = 0"
else
    if grep -qE "^net.ipv4.conf.default.accept_source_route" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.accept_source_route" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0112 net.ipv4.conf.default.accept_source_route = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0112 net.ipv4.conf.default.accept_source_route = 0"
    fi
fi
if grep -qE "^net.ipv6.conf.default.accept_source_route\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0112 net.ipv6.conf.default.accept_source_route = 0"
else
    if grep -qE "^net.ipv6.conf.default.accept_source_route" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.default.accept_source_route" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0112 net.ipv6.conf.default.accept_source_route = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0112 net.ipv6.conf.default.accept_source_route = 0"
    fi
fi
expected_value="0"

#TWGCB-01-008-0113
if grep -qE "^net.ipv4.conf.all.accept_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0113 net.ipv4.conf.all.accept_redirects = 0"
else
    if grep -qE "^net.ipv4.conf.all.accept_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.all.accept_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0113 net.ipv4.conf.all.accept_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0113 net.ipv4.conf.all.accept_redirects = 0"
    fi
fi

if grep -qE "^net.ipv6.conf.all.accept_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0113 net.ipv6.conf.all.accept_redirects = 0"
else
    if grep -qE "^net.ipv6.conf.all.accept_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.all.accept_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0113 net.ipv6.conf.all.accept_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0113 net.ipv6.conf.all.accept_redirects = 0"
    fi
fi
#
#TWGCB-01-008-0114
if grep -qE "^net.ipv4.conf.default.accept_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0114 net.ipv4.conf.default.accept_redirects = 0"
else
    if grep -qE "^net.ipv4.conf.default.accept_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.accept_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0114 net.ipv4.conf.default.accept_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0114 net.ipv4.conf.default.accept_redirects = 0"
    fi
fi
if grep -qE "^net.ipv6.conf.default.accept_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0114 net.ipv6.conf.default.accept_redirects = 0"
else
    if grep -qE "^net.ipv6.conf.default.accept_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.default.accept_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0114 net.ipv6.conf.default.accept_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0114 net.ipv6.conf.default.accept_redirects = 0"
    fi
fi
#

#TWGCB-01-008-0115
if grep -qE "^net.ipv4.conf.all.secure_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0115 net.ipv4.conf.all.secure_redirects = 0"
else
    if grep -qE "^net.ipv4.conf.all.secure_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.all.secure_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0115 net.ipv4.conf.all.secure_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0115 net.ipv4.conf.all.secure_redirects = 0"
    fi
fi

#TWGCB-01-008-0116
if grep -qE "^net.ipv4.conf.default.secure_redirects\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0116 net.ipv4.conf.default.secure_redirects = 0"
else
    if grep -qE "^net.ipv4.conf.default.secure_redirects" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.secure_redirects" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0116 net.ipv4.conf.default.secure_redirects = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0116 net.ipv4.conf.default.secure_redirects = 0"
    fi
fi

#TWGCB-01-008-0117
expected_value="1"
if grep -qE "^net.ipv4.conf.all.log_martians\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0117 net.ipv4.conf.all.log_martians = 1"
else
    if grep -qE "^net.ipv4.conf.all.log_martians" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.all.log_martians" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0117 net.ipv4.conf.all.log_martians = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0117 net.ipv4.conf.all.log_martians = 1"
    fi
fi
#TWGCB-01-008-0118
if grep -qE "^net.ipv4.conf.default.log_martians\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0118 net.ipv4.conf.default.log_martians = 1"
else
    if grep -qE "^net.ipv4.conf.default.log_martians" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.log_martians" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0118 net.ipv4.conf.default.log_martians = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0118 net.ipv4.conf.default.log_martians = 1"
    fi
fi

#TWGCB-01-008-0119
expected_value="1"
if grep -qE "^net.ipv4.icmp_echo_ignore_broadcasts\s*=\s*$expected_value" /etc/sysctl.conf ; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0119 net.ipv4.icmp_echo_ignore_broadcasts = 1"
else
    if grep -qE "^net.ipv4.icmp_echo_ignore_broadcasts" /etc/sysctl.conf ; then
        current_value=$(grep -E "^net.ipv4.icmp_echo_ignore_broadcasts" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0119 net.ipv4.icmp_echo_ignore_broadcasts = "$current_value " Expected value : "$expected_value
    else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0119 net.ipv4.icmp_echo_ignore_broadcasts = 1"
    fi
fi
sleep 1
#TWGCB-01-008-0120
expected_value="1"
if grep -qE "^net.ipv4.icmp_ignore_bogus_error_responses\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0120 net.ipv4.icmp_ignore_bogus_error_responses = 1"
else
    if grep -qE "^net.ipv4.icmp_ignore_bogus_error_responses" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.icmp_ignore_bogus_error_responses" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0120 net.ipv4.icmp_ignore_bogus_error_responses = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0120 net.ipv4.icmp_ignore_bogus_error_responses = 1"
    fi
fi
#TWGCB-01-008-0121
expected_value="1"
if grep -qE "^net.ipv4.conf.all.rp_filter\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0121 net.ipv4.conf.all.rp_filter = 1"
else
    if grep -qE "^net.ipv4.conf.all.rp_filter" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.all.rp_filter" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0121 net.ipv4.conf.all.rp_filter = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0121 net.ipv4.conf.all.rp_filter = 1"
    fi
fi
#TWGCB-01-008-0122
expected_value="1"
if grep -qE "^net.ipv4.conf.default.rp_filter\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0122 net.ipv4.conf.default.rp_filter = 1"
else
    if grep -qE "^net.ipv4.conf.default.rp_filter" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.conf.default.rp_filter" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0122 net.ipv4.conf.default.rp_filter = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0122 net.ipv4.conf.default.rp_filter = 1"
    fi
fi
sleep 1
#TWGCB-01-008-0123
expected_value="1"
if grep -qE "^net.ipv4.tcp_syncookies\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0123 net.ipv4.tcp_syncookies = 1"
else
    if grep -qE "^net.ipv4.tcp_syncookies" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv4.tcp_syncookies" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0123 net.ipv4.tcp_syncookies = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0123 net.ipv4.tcp_syncookies = 1"
    fi
fi
#TWGCB-01-008-0124
expected_value="0"
if grep -qE "^net.ipv6.conf.all.accept_ra\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0124 net.ipv6.conf.all.accept_ra = 0"
else
    if grep -qE "^net.ipv6.conf.all.accept_ra" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.all.accept_ra" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0124 net.ipv6.conf.all.accept_ra = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0124 net.ipv6.conf.all.accept_ra = 0"
    fi
fi
#TWGCB-01-008-0125
expected_value="0"
if grep -qE "^net.ipv6.conf.default.accept_ra\s*=\s*$expected_value" /etc/sysctl.conf; then
    echo -e " [\033[1;32mOK\033[0m] TWGCB-01-008-0125 net.ipv6.conf.default.accept_ra = 0"
else
    if grep -qE "^net.ipv6.conf.default.accept_ra" /etc/sysctl.conf; then
        current_value=$(grep -E "^net.ipv6.conf.default.accept_ra" /etc/sysctl.conf | awk -F= '{print $2}' | tr -d '[:space:]')
        echo -e " [\033[1;33mWARNING\033[0m] TWGCB-01-008-0125 net.ipv6.conf.default.accept_ra = "$current_value " Expected value : "$expected_value
else
        echo -e " [\033[0;31mKO\033[0m] Not found. You should add : TWGCB-01-008-0125 net.ipv6.conf.default.accept_ra = 0"
    fi
fi

###	TWGCB-01-008-0126 ####
#1
FRUIT=`if [ -f "/etc/modprobe.d/dccp.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

audit01=`awk '$1 == "install" && $2 == "dccp" && $3 == "/bin/true"'  /etc/modprobe.d/dccp.conf  | grep -q "install dccp /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "dccp"'  /etc/modprobe.d/dccp.conf  | grep -q "blacklist dccp" && echo 0 || echo 1`
audit03=`lsmod | grep dccp  | grep -q "dccp" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0126 rmmod dccp is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0126 should be different to rmmod dccp "
    fi


   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0126 no /etc/modprobe.d/dccp.conf"
   
   ;;
esac

###	TWGCB-01-008-0126 ####

###	TWGCB-01-008-0127 ####
#1
FRUIT=`if [ -f "/etc/modprobe.d/sctp.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

audit01=`awk '$1 == "install" && $2 == "sctp" && $3 == "/bin/true"'  /etc/modprobe.d/sctp.conf  | grep -q "install sctp /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "sctp"'  /etc/modprobe.d/sctp.conf  | grep -q "blacklist sctp" && echo 0 || echo 1`
audit03=`lsmod | grep sctp  | grep -q "sctp" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0127 rmmod sctp is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0127 should be different to rmmod sctp "
    fi


   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0127 no /etc/modprobe.d/sctp.conf"
   
   ;;
esac

###	TWGCB-01-008-0127 ####

###	TWGCB-01-008-0128 ####
#1
FRUIT=`if [ -f "/etc/modprobe.d/rds.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

audit01=`awk '$1 == "install" && $2 == "rds" && $3 == "/bin/true"'  /etc/modprobe.d/rds.conf  | grep -q "install rds /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "rds"'  /etc/modprobe.d/rds.conf  | grep -q "blacklist rds" && echo 0 || echo 1`
audit03=`lsmod | grep rds  | grep -q "rds" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0128 rmmod rds is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0128 should be different to rmmod rds "
    fi


   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0128 no /etc/modprobe.d/rds.conf"
   
   ;;
esac
###

###	TWGCB-01-008-0129 ####
#1
FRUIT=`if [ -f "/etc/modprobe.d/tipc.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

audit01=`awk '$1 == "install" && $2 == "tipc" && $3 == "/bin/true"'  /etc/modprobe.d/tipc.conf  | grep -q "install tipc /bin/true" && echo 0 || echo 1`
audit02=`awk '$1 == "blacklist" && $2 == "tipc"'  /etc/modprobe.d/tipc.conf | grep -q "blacklist tipc" && echo 0 || echo 1`
audit03=`lsmod | grep tipc  | grep -q "tipc" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ] && [ "$audit03" == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0129 rmmod tipc is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0129 should be different to rmmod tipc "
    fi


   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0129 no /etc/modprobe.d/tipc.conf"
   
   ;;
esac
###

cramfs01=`nmcli radio wifi | grep -q -i "disabled" && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0130 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0130 error"
    fi
	
cramfs08=`ip link | grep -i promisc`
    if [ -z $cramfs08 ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0131 無，檢查網路介面處於混雜模式"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0131 有，檢查網路介面處於混雜模式" 
	fi
	
audit01=`rpm -q audit | grep -q '尚未安裝' && echo 0 || echo 1`
audit02=`rpm -q audit-libs | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ] && [ "$audit02" -eq "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0132 no install"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0132 should be different to dnf install audit audit-libs"
    fi
	
autofs01=`systemctl is-active auditd`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0133 enable auditd "$autofs01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0133 disable auditd "$autofs01
    fi
	
cramfs01=$(grep -q -P '^(?=.*GRUB_CMDLINE_LINUX)(?=.*audit=1)' /etc/default/grub && echo 0 || echo 1)
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0134 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0134 Check no GRUB_CMDLINE_LINUX_DEFAULT="audit=1" "
    fi
	
cramfs01=$(grep -q -P '^(?=.*GRUB_CMDLINE_LINUX)(?=.*audit_backlog_limit=8192)' /etc/default/grub && echo 0 || echo 1)
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0135 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0135 Check no GRUB_CMDLINE_LINUX_DEFAULT="audit_backlog_limit=8192" "
    fi
	
 audit01=`awk '$1 == "postmaster:"' /etc/aliases | grep -q -P '^(?=.*postmaster)(?=.*root)' && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0136 nfs ckeck add postmaster: root is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0136 /etc/aliases should be different to add postmaster: rootv"
    fi
	
cramfs01=$(ls -l /var/log/audit/audit.log | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0137 Check /var/log/audit/audit.log is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0137 no root:root"
    fi
	
###	TWGCB-01-008-0138 ####
FRUIT=`if [ -f "/var/log/audit/audit.log" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /var/log/audit/audit.log)
    if [ $cramfs01 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0138 Check /var/log/audit/audit.log is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0138 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0138 no /var/log/audit/audit.log"
   
   ;;
esac
###	TWGCB-01-008-0138 ####

cramfs01=$(ls -l /etc/audit/auditd.conf | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0139 Check /etc/audit/auditd.conf is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0139 no root:root"
    fi
	
###	TWGCB-01-008-0140 ####
FRUIT=`if [ -f "/etc/audit/auditd.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /var/log/audit)
    if [ $cramfs01 -le "700" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0140 Check /var/log/audit is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0140 no 700"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0140 no /var/log/audit"
   
   ;;
esac
###	TWGCB-01-008-0140 ####

###	TWGCB-01-008-0141 ####
FRUIT=`if [ -f "/etc/audit/rules.d/audit.rules" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /etc/audit/rules.d/audit.rules)
    if [ $cramfs01 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0141 Check /etc/audit/rules.d/audit.rules is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0141 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0141 no /etc/audit/rules.d/audit.rules"
   
   ;;
esac
###	TWGCB-01-008-0141 ####

###	TWGCB-01-008-0142 ####
FRUIT=`if [ -f "/etc/audit/auditd.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /etc/audit/auditd.conf)
    if [ $cramfs01 -le "640" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0142 Check /etc/audit/auditd.conf is 640 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0142 no 640"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0142 no /etc/audit/auditd.conf"
   
   ;;
esac
###	TWGCB-01-008-0142 ####

###	TWGCB-01-008-0143 ####
#1
FRUIT=`if [ -f "/sbin/auditctl" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /sbin/auditctl)
    if [ $cramfs01 -le "750" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0143 Check /sbin/auditctl is 750 ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0143 no 750 (手動設定)"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0143 no /sbin/auditctl"
   
   ;;
esac

###	TWGCB-01-008-0144 ####
#1
FRUIT=`if [ -f "/sbin/auditctl" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(ls -l /sbin/auditctl | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0144 Check /sbin/auditctl is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no /sbin/auditctl"
   
   ;;
esac

#2
FRUIT=`if [ -f "/sbin/aureport" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(ls -l /sbin/aureport | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0144 Check /sbin/aureport is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no /sbin/aureport"
   
   ;;
esac

#3
FRUIT=`if [ -f "/sbin/ausearch" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(ls -l /sbin/ausearch | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0144 Check /sbin/ausearch is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no /sbin/ausearch"
   
   ;;
esac

#4
FRUIT=`if [ -f "/sbin/autrace" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(ls -l /sbin/autrace | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0144 Check /sbin/autrace is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no /sbin/autrace"
   
   ;;
esac


#5
FRUIT=`if [ -f "/sbin/auditd" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=$(ls -l /sbin/auditd | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0144 Check /sbin/auditd is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no root:root"
    fi
    
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no /sbin/auditd"
   
   ;;
esac

#6
FRUIT=`if [ -f "/sbin/audisp-remote" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=$(ls -l /sbin/audisp-remote | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0144 Check /sbin/audisp-remote is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no /sbin/audisp-remote (可排外，無此目錄)"
   
   ;;
esac

#7
FRUIT=`if [ -f "/sbin/audisp-syslog" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
       
cramfs01=$(ls -l /sbin/audisp-syslog | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0144 Check /sbin/audisp-syslog is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no root:root"
    fi
	
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no /sbin/audisp-syslog (可排外，無此目錄)"
   
   ;;
esac

#8
FRUIT=`if [ -f "/sbin/augenrules" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   	
cramfs01=$(ls -l /sbin/augenrules | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0144 Check /sbin/augenrules is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no root:root"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0144 no /sbin/augenrules"
   
   ;;
esac

###	TWGCB-01-008-0144 ####

###	TWGCB-01-008-0145 ####
#1
FRUIT=`if [ -f "/etc/aide.conf" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
cramfs01=`grep -q -i "/usr/sbin/auditctl p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs02=`grep -q -i "/usr/sbin/auditd p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs03=`grep -q -i "/usr/sbin/ausearch p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs04=`grep -q -i "/usr/sbin/aureport p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs05=`grep -q -i "/usr/sbin/autrace p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs06=`grep -q -i "/usr/sbin/audisp-remote p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs07=`grep -q -i "/usr/sbin/audisp-syslog p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
cramfs08=`grep -q -i "/usr/sbin/augenrules p+i+n+u+g+s+b+acl+xattrs+sha512" /etc/aide.conf && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] && [ "$cramfs04" == "0" ] && [ "$cramfs05" == "0" ] && [ "$cramfs06" == "0" ] && [ "$cramfs07" == "0" ] && [ "$cramfs08" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0145 add aide rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0145 should be different to add aide rules"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0145 no /etc/aide.conf"
   
   ;;
esac

###	TWGCB-01-008-0145 ####

audit01=`grep -i '^[[:space:]]*max_log_file[[:space:]]*=' /etc/audit/auditd.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" -ge "32" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0146 max_log_file = 32"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0146 should be different to max_log_file = 32"
    fi

audit01=`grep -i '^[[:space:]]*max_log_file_action[[:space:]]*=' /etc/audit/auditd.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "keep_logs" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0147 max_log_file_action = keep_logs"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0147 should be different to max_log_file_action = keep_logs"
    fi
	
cramfs01=`grep -q '^[-]'"w /etc/sudoers -p wa -k scope" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /etc/sudoers.d/ -p wa -k scope" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0148 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0148 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /var/run/faillock/ -p wa -k logins" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /var/log/lastlog -p wa -k logins" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0149 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0149 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /var/run/utmp -p wa -k session" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /var/log/wtmp -p wa -k logins" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs03=`grep -q '^[-]'"w /var/log/btmp -p wa -k logins" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0150 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0150 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs03=`grep -q '^[-]'"a always,exit -F arch=b64 -S clock_settime -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs04=`grep -q '^[-]'"a always,exit -F arch=b32 -S clock_settime -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs05=`grep -q '^[-]'"w /etc/localtime -p wa -k time-change" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] && [ "$cramfs04" == "0" ] && [ "$cramfs05" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0151 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0151 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /etc/selinux/ -p wa -k MAC-policy" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /usr/share/selinux/ -p wa -k MAC-policy" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0152 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0152 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"w /etc/issue -p wa -k system-locale" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"w /etc/issue.net -p wa -k system-locale" /etc/audit/rules.d/audit.rules`
cramfs05=`grep '^[-]'"w /etc/sysconfig/network-scripts/ -p wa -k system-locale" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale" ] && [ "$cramfs02" == "-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale" ] && [ "$cramfs03" == "-w /etc/issue -p wa -k system-locale" ] && [ "$cramfs04" == "-w /etc/issue.net -p wa -k system-locale" ] && [ "$cramfs05" == "-w /etc/sysconfig/network-scripts/ -p wa -k system-locale" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0153 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0153 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs05=`grep '^[-]'"a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
cramfs06=`grep '^[-]'"a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs02" == "-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs03" == "-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs04" == "-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs05" == "-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] && [ "$cramfs06" == "-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0154 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0154 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access" ] && [ "$cramfs02" == "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access" ] && [ "$cramfs03" == "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access" ] && [ "$cramfs04" == "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0155 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0155 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /etc/group -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /etc/passwd -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs03=`grep -q '^[-]'"w /etc/gshadow -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs04=`grep -q '^[-]'"w /etc/shadow -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs05=`grep -q '^[-]'"w /etc/security/opasswd -p wa -k identity" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] && [ "$cramfs04" == "0" ] && [ "$cramfs05" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0156 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0156 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts" ] && [ "$cramfs02" == "-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0157 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0157 should be different to add audit rules"
    fi
	
########TWGCB-01-008-0158################
FRUIT=`if [ -f "/etc/audit/rules.d/privileged.rules" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
# 此是query -->> df --local -P 2> /dev/null | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type f \( -perm -4000 -o -perm -2000 \) | awk '{print "-a always,exit -F path="$1" -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged" }' >> /etc/audit/rules.d/privileged.rules
cramfs08=`grep -q "/" /etc/audit/rules.d/privileged.rules && echo 0 || echo 1`
    if [ -z $cramfs08 ] ; then  
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0158 無，找出特權程式稽核規則加入到該/etc/audit/rules.d/privileged.rules檔案"
    else   
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0158 Enable，找出特權程式稽核規則加入到該/etc/audit/rules.d/privileged.rules檔案" 
	fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0158 no /etc/audit/rules.d/privileged.rules"
   
   ;;
esac
########TWGCB-01-008-0158################

cramfs01=`grep -q '^[-]'"a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0159 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0159 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"w /sbin/insmod -p x -k modules" /etc/audit/rules.d/audit.rules > /dev/null 2>&1 && echo 0 || echo 1`
cramfs02=`grep -q '^[-]'"w /sbin/rmmod -p x -k modules" /etc/audit/rules.d/audit.rules > /dev/null 2>&1 && echo 0 || echo 1`
cramfs03=`grep -q '^[-]'"w /sbin/modprobe -p x -k modules" /etc/audit/rules.d/audit.rules > /dev/null 2>&1 && echo 0 || echo 1`
cramfs04=`grep -q '^[-]'"a always,exit -F arch=b64 -S init_module -S delete_module -k modules" /etc/audit/rules.d/audit.rules > /dev/null 2>&1 && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] && [ "$cramfs02" == "0" ] && [ "$cramfs03" == "0" ] && [ "$cramfs04" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0160 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0160 should be different to add audit rules"
    fi

###	TWGCB-01-008-0161 ####
#1
FRUIT=`if [ -f "/var/log/sudo.log" ] && [ -f "/etc/audit/rules.d/actions.rules" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   

cramfs01=`grep -q "/var/log/sudo.log" /etc/audit/rules.d/actions.rules | tail -1 && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0161 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0161 should be different to add audit rules (可手動設定)"
    fi

   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0161 no /etc/audit/rules.d/actions.rules (可手動設定)"
   
   ;;
esac
###
	
cramfs01=`grep '^[-]'"a always,exit -F path=/usr/bin/chcon -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/usr/bin/chcon -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0162 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0162 should be different to add audit rules"
    fi
	
cramfs01=`grep -q '^[-]'"a always,exit -F path=/usr/bin/ssh-agent -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-ssh" /etc/audit/rules.d/audit.rules && echo 0 || echo 1`
    if [ "$cramfs01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0163 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0163 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F path=/sbin/unix_update -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix-update" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/sbin/unix_update -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix-update" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0164 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0164 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0165 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0165 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b32 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b64 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b32 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng" ] && [ "$cramfs02" == "-a always,exit -F arch=b64 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module_chng" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0166 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0166 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" ] && [ "$cramfs02" == "-a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" ] && [ "$cramfs03" == "-a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" ] && [ "$cramfs04" == "-a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0167 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0167 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-usermod" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-usermod" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0168 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0168 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F path=/usr/bin/chacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F path=/usr/bin/chacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0169 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0169 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"w /bin/kmod -p x -k modules" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-w /bin/kmod -p x -k modules" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0170 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0170 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"w /var/log/faillock -p wa -k logins" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-w /var/log/faillock -p wa -k logins" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0171 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0171 should be different to add audit rules"
    fi
	
cramfs01=`grep '^[-]'"a always,exit -F arch=b32 -S execve -C uid!=euid -F key=execpriv" /etc/audit/rules.d/audit.rules`
cramfs02=`grep '^[-]'"a always,exit -F arch=b64 -S execve -C uid!=euid -F key=execpriv" /etc/audit/rules.d/audit.rules`
cramfs03=`grep '^[-]'"a always,exit -F arch=b32 -S execve -C gid!=egid -F key=execpriv" /etc/audit/rules.d/audit.rules`
cramfs04=`grep '^[-]'"a always,exit -F arch=b64 -S execve -C gid!=egid -F key=execpriv" /etc/audit/rules.d/audit.rules`
    if [ "$cramfs01" == "-a always,exit -F arch=b32 -S execve -C uid!=euid -F key=execpriv" ] && [ "$cramfs02" == "-a always,exit -F arch=b64 -S execve -C uid!=euid -F key=execpriv" ] && [ "$cramfs03" == "-a always,exit -F arch=b32 -S execve -C gid!=egid -F key=execpriv" ] && [ "$cramfs04" == "-a always,exit -F arch=b64 -S execve -C gid!=egid -F key=execpriv" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0172 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0172 should be different to add audit rules"
    fi
	
cramfs01=`grep "-e 2" /etc/audit/rules.d/audit.rules`
cramfs02=`grep "^\s*[^#]" /etc/audit/rules.d/*.rules | tail -1`

    if [ "$cramfs01" == "-e 2" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0173 add audit rules ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0173 should be different to add audit rules"
    fi
	
    if [ $(rpm -qa|grep -c rsyslog) -gt 0 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0174 install rsyslog "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0174 rsyslog should be different to dnf install rsyslog"
    fi
	
autofs01=`systemctl is-active crond`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0175 enable rsyslog "$autofs01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0175 disable rsyslog "$autofs01
    fi
	
SSHTEST01=`grep -i "auth.*,authpriv.* /var/log/secure" /etc/rsyslog.conf | grep -q -v "#" && echo 0 || echo 1`
SSHTEST02=`grep -i "daemon.* /var/log/messages" /etc/rsyslog.conf | grep -q -v "#" && echo 0 || echo 1`
    if [ "$SSHTEST01" == "0" ] && [ "$SSHTEST02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0176 /etc/rsyslog.conf  ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0176 /etc/rsyslog.conf should be set to auth.*,authpriv.* /var/log/secure daemon.* /var/log/messages"
    fi
	
audit01=`grep -q -i "daemon.*" /etc/rsyslog.conf && echo 0 || echo 1` 
audit02=`grep -q -P '^(?=.*auth.*)(?=.*,authpriv)' /etc/rsyslog.conf && echo 0 || echo 1`
    if [ "$audit01" == "0" ] && [ "$audit02" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0177 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0177 check is error"
    fi
	
 cramfs01=$(ls -l /var/log/messages | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0178 Check /var/log/messages is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0178 no root:root"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.d)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0179 Check /etc/cron.d is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0179 no root:root"
    fi
	
audit01=`grep -i '^[[:space:]]*ForwardToSyslog[[:space:]]*=' /etc/systemd/journald.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "yes" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0180 ForwardToSyslog=yes"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0180 should be different to ForwardToSyslog=yes"
    fi
	
audit01=`grep -i '^[[:space:]]*Compress[[:space:]]*=' /etc/systemd/journald.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "yes" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0181 Compress=yes"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0181 should be different to Compress=yes"
    fi
	
audit01=`grep -i '^[[:space:]]*Storage[[:space:]]*=' /etc/systemd/journald.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "persistent" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0182 Storage = persistent"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0182 should be different to Storage = persistent"
    fi
	
cramfs01=$(grep -E "^GRUB_CMDLINE_LINUX=" /etc/default/grub | awk -F= '{print $2}')
cramfs02=$(grep -E "^GRUB_CMDLINE_LINUX_DEFAULT=" /etc/default/grub | awk -F= '{print $2}' | grep -q -E \"quiet\" && echo 0 || echo 1)
    if [ "$cramfs01" == '""' ] && [ "$cramfs02" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0186 Check ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0186 Check no GRUB_CMDLINE_LINUX_DEFAULT="quiet" & GRUB_CMDLINE_LINUX="" ((可設定))"
    fi
	
audit01=`grep -i '^[[:space:]]*SELINUXTYPE[[:space:]]*=' /etc/selinux/config | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "targeted" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0187 SELINUXTYPE=targeted "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0187 should be different to SELINUXTYPE=targeted "
    fi
	
audit01=`grep -i '^[[:space:]]*SELINUX[[:space:]]*=' /etc/selinux/config | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";"`
    if [ "$audit01" == "enforcing" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0188 SELINUX=enforcing (排外，會影響Auitd.Service無法啟動)"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0188 should be different to SELINUX=enforcing (排外，會影響Auitd.Service無法啟動)"
    fi
	
#https://medium.com/@DavidAwCloudSOC/the-truth-about-unconfined-domain-and-selinux-policy-dea9ec7cab1c
#1.inti_t. Systemd.
#2.httpd_t. HTTP daemon threads.
#3.kernel_t. Kernel threads.
#4.syslogd_t. The logging daemons for journald and rsyslogd.
#5.unconfined_t. Processes executed by users in the unconfined domain.
#chcon -t inti_t /usr/libexec/power-profiles-daemon
#chcon -t kernel_t /usr/libexec/switcheroo-control
cramfs01=$(ps -eZf | grep -c unconfined_service_t)
    if [ $cramfs01 -gt "1" ] ; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0189 Check yes unconfined_service_t (可排外，如有安裝防毒或監控可考慮，無入SELINUX)"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0189 Check no unconfined_service_t ok "
    fi
	
audit01=`rpm -q setroubleshoot | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ] ; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0190 install setroubleshoot"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0190 no install setroubleshoot"
    fi
	
audit01=`rpm -q mcstrans | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ] ; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0191 install mcstrans"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0191 no install mcstrans"
    fi
	
autofs01=`systemctl is-active crond`
    if [ "$autofs01" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0192 enable crond "$autofs01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0192 disable crond "$autofs01
    fi
	
cramfs01=$(ls -l /etc/crontab | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0193 Check /etc/crontab is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0193 /etc/crontab no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/crontab)
    if [ $cramfs01 -le "644" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0194 Check /etc/crontab is 644 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0194 no 644"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.hourly)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0195 Check /etc/cron.hourly is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0195 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.hourly)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0196 Check /etc/cron.hourly is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0196 no 700"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.daily)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0197 Check /etc/cron.daily is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0197 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.daily)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0198 Check /etc/cron.daily is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0198 no 700"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.weekly)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0199 Check /etc/cron.weekly is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0199 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.weekly)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0200 Check /etc/cron.weekly is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0200 no 700"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.monthly)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0201 Check /etc/cron.monthly is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0201 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.monthly)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0202 Check /etc/cron.monthly is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0202 no 700"
    fi
	
cramfs01=$(stat -c %U:%G /etc/cron.d)
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0203 Check /etc/cron.d is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0203 no root:root"
    fi
	
cramfs01=$(stat -c %a /etc/cron.d)
    if [ $cramfs01 -le "700" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0204 Check /etc/cron.d is 700 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0204 no 700"
    fi
	
###	TWGCB-01-008-0205 ####
#1
FRUIT=`if [ -f "/etc/cron.deny" ] && [ -f "/etc/at.deny" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "FAIL") 
   

###	TWGCB-01-008-0205 ####################################################################################
#1
FRUIT01=`if [ -f "/etc/cron.allow" ] && [ -f "/etc/at.allow" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
   case "$FRUIT01" in

       "SUCC") 
   

    audit01=`if [ -f "/etc/cron.allow" ] && [ -f "/etc/at.allow" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
    audit02=`stat -c '%U':'%G' /etc/cron.allow`
    audit03=`stat -c '%U':'%G' /etc/at.allow`
    if [ "$audit01" == "SUCC" ] && [ "$audit02" == "root:root" ] && [ "$audit03" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0205 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0205 check is error"
    fi


       ;;
       "FAIL") 
   
       echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0205 no /etc/at.allow /etc/cron.allow"
   
       ;;
       esac
##############################################################################


   ;;
   "SUCC") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0205 no del /etc/cron.deny /etc/cron.deny"
   
   ;;
esac
###TWGCB-01-008-0205########################################################

###	TWGCB-01-008-0206 ####
FRUIT=`if [ -f "/etc/cron.allow" ] && [ -f "/etc/at.allow" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /etc/cron.allow)
    cramfs02=$(stat -c %a /etc/at.allow)
    if [ $cramfs01 -le "600" ] && [ $cramfs02 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0206 Check /etc/cron.allow & /etc/at.allow is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0206 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0206 no /etc/cron.allow /etc/at.allow"
   
   ;;
esac
###	TWGCB-01-008-0206 ####

cramfs08=`grep -q -i "/var/log/cron.log" /etc/rsyslog.conf && echo 0 || echo 1`
    if [ "$cramfs08" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0207 /etc/rsyslog.conf ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0207 should be different to add /var/log/cron.log"
    fi
	
  audit03=`grep -q -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*\s+retry=\S+\s*.*$' /etc/pam.d/system-auth && echo 0 || echo 1`
  audit04=`grep -q -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*\s+retry=\S+\s*.*$' /etc/pam.d/password-auth && echo 0 || echo 1`
    if [ "$audit03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0208 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0208 check is error"
    fi
	
 audit03=`grep -q -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*enforce_for_root\s*.*$' /etc/pam.d/password-auth && echo 0 || echo 1`
 audit04=`grep -q -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*\s+retry=\S+\s*.*$' /etc/pam.d/password-auth && echo 0 || echo 1`
    if [ "$audit03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0209 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0209 check is error"
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*minlen[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "12" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0210 minlen = 12"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0210 minlen = 12"
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*minclass[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "4" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0211 minclass = 4 "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0211 minclass = 4 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*dcredit[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "-1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0212 dcredit = -1 "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0212 dcredit = -1 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*ucredit[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "-1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0213 ucredit = -1  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0213 ucredit = -1  "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*lcredit[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "-1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0214 lcredit = -1  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0214 lcredit = -1"
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*ocredit[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "-1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0215 ocredit = -1  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0215 ocredit = -1"
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*difok[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "3" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0216 difok = 3  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0216 difok = 3 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*maxclassrepeat[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "4" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0217 maxclassrepeat = 4 "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0217 maxclassrepeat = 4 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*maxrepeat[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "3" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0218 maxrepeat = 3  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0218 maxrepeat = 3 "
    fi
	
SSHTEST=$(grep -i '^[[:space:]]*dictcheck[[:space:]]*=' /etc/security/pwquality.conf | awk -F= '{gsub(/[ 	]/, "", $2); print $2}' | paste -sd ";")
    if [ "$SSHTEST" == "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0219 dictcheck = 1  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0219 dictcheck = 1 "
    fi
	
###TWGCB-01-008-0220########
SSHTEST=$(awk ' /^[[:space:]]*deny[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
FRUIT=`if [ -z $SSHTEST ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0220 no deny = 5 "
    
    
   ;;
   "FAIL") 
   
   SSHTEST=$(awk ' /^[[:space:]]*deny[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
    if [ "$SSHTEST" -le 5 -a "$SSHTEST" -gt 0 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0220 deny = 5"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0220 no deny = 5"
    fi
   
   ;;
esac
###TWGCB-01-008-0220########

###TWGCB-01-008-0221########
SSHTEST1=$(awk ' /^[[:space:]]*unlock_time[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
SSHTEST2=$(awk ' /^[[:space:]]*deny[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
FRUIT=`if [ $SSHTEST1 == "900" ] &&[ $SSHTEST2 == "5" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
   SSHTEST=$(awk ' /^[[:space:]]*unlock_time[[:space:]]*=[[:space:]]*/{print}' /etc/security/faillock.conf | grep -v ^# | cut -d= -f2)
    if [ "$SSHTEST" -ge 900 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0221 unlock_time = 900 & deny = 5"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0221 no unlock_time = 900 & deny = 5"
    fi
    
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0221 error "
    
   
   ;;
esac
###TWGCB-01-008-0221########

  audit03=`grep -q -E '^\s*password\s+(sufficient\s+pam_unix|requi(red|site)\s+pam_pwhistory).so\s+([^#]+\s+)*remember=\S+\s*.*$' /etc/pam.d/system-auth && echo 0 || echo 1`
  audit04=`grep -q -E '^\s*password\s+(sufficient\s+pam_unix|requi(red|site)\s+pam_pwhistory).so\s+([^#]+\s+)*remember=\S+\s*.*$' /etc/pam.d/password-auth && echo 0 || echo 1`
    if [ "$audit03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0222 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0222 check is error"
    fi
	
  audit03=`grep -q -E '^\s*session\s+required\s+pam_lastlog.so\s+showfailed' /etc/pam.d/postlogin && echo 0 || echo 1`
    if [ "$audit03" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0223 check is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0223 check is error"
    fi
	
audit01=`awk '$1 == "session" && $2 == "required" && $3 == "pam_lastlog.so"' /etc/pam.d/postlogin | grep -q  "showfailed" && echo 0 || echo 1`
    if [ "$audit01" == "0" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0224 /etc/pam.d/postlogin showfailed is ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0224 should be different to /etc/pam.d/postlogin showfailed "
    fi
	
SSHTEST=$(cat /etc/login.defs | grep PASS_MIN_DAYS | grep -v ^# | awk '{print $2}')
    if [ "$SSHTEST" -ge "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0225 /etc/login.defs PASS_MIN_DAYS Check is (,chage --mindays 1 ) "$SSHTEST 
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0225 /etc/login.defs PASS_MIN_DAYS should be set to 1'"
    fi
	
passage=$(cat /etc/login.defs | grep PASS_WARN_AGE | grep -v ^# | awk '{print $2}')
    if [ "$passage" -ge "14" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0226 /etc/login.defs PASS_WARN_AGE Check is (,chage --warndays 14 ) "$SSHTEST 
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0226 /etc/login.defs PASS_WARN_AGE should be set to 14'"
    fi
	
passmax=$(cat /etc/login.defs | grep PASS_MAX_DAYS | grep -v ^# | awk '{print $2}')
    if [ "$passmax" -le 90 -a "$passmax" -gt 0 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0227 /etc/login.defs passmax Check is (,chage --maxdays 90 )"$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0227 /etc/login.defs passmax should be set to 90'"
    fi
	
SSHTEST=$(egrep ^[^:]+:[^\!*] /etc/shadow| egrep -v "^\s*#|root" | awk -F: '{print $1":"$7}' | egrep -v ".*:(30|[1-2][0-9]|[1-9])$")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0228 PASSWD is set 30 Day (,chage --inactive 30)"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0228 PASSWD should be set 30 Day account: "$SSHTEST
    fi
	
SSHTEST=$(awk 'toupper($1) == "FAIL_DELAY"  { print $2 }' /etc/login.defs)
    if [ "$SSHTEST" -eq "4" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0229 /etc/login.defs Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0229 /etc/login.defs should be set to 4'"
    fi
	
SSHTEST=$(awk 'toupper($1) == "CREATE_HOME"  { print $2 }' /etc/login.defs)
    if [ "$SSHTEST" == "yes" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0230 /etc/login.defs Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0230 /etc/login.defs should be set to yes'"
    fi
	#/etc/sudoers.d/*
	#find /etc/sudoers.d -type f -exec sh -c 'perm=$(stat -c "%a" "{}"); if [ $perm -gt 640 ]; then echo $perm; exit 0; fi' \; | paste -s
SSHTEST=$(egrep -i '^[^#]*(nopasswd|!authenticate)' /etc/sudoers )
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0231 NOPASSWD & !authenticate is #"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0231 NOPASSWD & !authenticate should be set #"$SSHTEST
    fi
	
SSHTEST=$(awk '$1 == "*" && $2 == "hard" && $3 == "maxlogins" { print $4 }' /etc/security/limits.conf)
    if [ $SSHTEST == "10" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0232 * hard maxlogins 10  "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0232 /etc/security/limits.conf should be different to * hard maxlogins 10 "
    fi
	
audit01=`rpm -q kbd.x86_64 | grep -q '尚未安裝' && echo 0 || echo 1`
    if [ "$audit01" -eq "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0233 install kbd.x86_64"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0233 should be different to dnf install kbd.x86_64"
    fi
	
SSHTEST=$(awk '/^[[:space:]]*lock-enabled[[:space:]]*=[[:space:]]*/{print}' /etc/dconf/db/local.d/00-screensaver | cut -d= -f2)
    if [ $SSHTEST == "true" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0234 /etc/dconf/db/local.d/00-screensaver Check is "$SSHTEST
    else
	echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0234 /etc/dconf/db/local.d/00-screensaver should be set to true (PS.It’s a graphic, no settings required !!)'"
    fi
	
SSHTEST=$(awk '/^[[:space:]]*idle-delay[[:space:]]*=[[:space:]]*/{print}' /etc/dconf/db/local.d/00-screensaver | cut -d= -f2)
    if [ "$SSHTEST" == "uint32 900" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0235 /etc/dconf/db/local.d/00-screensaver Check is "$SSHTEST
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0235 /etc/dconf/db/local.d/00-screensaver should be set to uint32 900 (PS.It’s a graphic, no settings required !!)'"
    fi
	
SSHTEST=$(awk '/^\[daemon\]$/{flag=1; next} /^\[/{flag=0} flag && tolower($0) ~ /^[[:space:]]*automaticloginenable[[:space:]]*=[[:space:]]*/{print}' /etc/gdm/custom.conf | cut -d= -f2)
    if [ $SSHTEST == "false" > /dev/null 2>&1 ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0236 /etc/gdm/custom.conf Check is "$SSHTEST
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0236 /etc/gdm/custom.conf should be set to false (PS.It’s a graphic, no settings required !!)'"
    fi
	
SSHTEST=$(awk -F: '($1!="root" && $1!~/^\+/ && $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"') {print $1}' /etc/passwd | xargs -I '{}' passwd -S '{}' | awk '($2!="L" && $2!="LK") {print $1}' | while read user; do usermod -L $user; done)
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0237 nologin"$SSHTEST
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0237 should be set"
    fi
	
cramfs06=`grep -q -E "TMOUT=900" /etc/bashrc && echo 0 || echo 1`
cramfs07=`grep -q -E "TMOUT=900" /etc/profile && echo 0 || echo 1`  
cramfs08=`grep -q -E "TMOUT=900" /etc/profile.d/*.sh && echo 0 || echo 1`
    if [ "$cramfs08" == "0" ] && [ "$cramfs07" == "0" ] && [ "$cramfs06" == "0" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0238 ok，readonly TMOUT=900 ; export TMOUT"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0238 on，readonly TMOUT=900 ; export TMOUT ((可手動設定)"
	
    fi
	
audit01=`awk '$1=="/org/gnome/desktop/session/idle-delay"' /etc/dconf/db/local.d/locks/session | grep -q -E "/org/gnome/desktop/session/idle-delay" && echo 0 || echo 1`
audit02=`awk '$1=="/org/gnome/desktop/screensaver/lock-enabled"' /etc/dconf/db/local.d/locks/session | grep -q -E "/org/gnome/desktop/screensaver/lock-enabled" && echo 0 || echo 1`
audit03=`awk '$1=="/org/gnome/desktop/screensaver/lock-delay"' /etc/dconf/db/local.d/locks/session | grep -q -E "/org/gnome/desktop/screensaver/lock-delay" && echo 0 || echo 1`
audit04=`awk '$1=="/org/gnome/desktop/lockdown/disable-lock-screen"' /etc/dconf/db/local.d/locks/session | grep -q -E "/org/gnome/desktop/lockdown/disable-lock-screen" && echo 0 || echo 1`
    if [ $audit01 == "0" ] && [ $audit02 == "0" ] && [ $audit03 == "0" ] && [ $audit04 == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0239 enable /etc/dconf/db/local.d/locks/session ok"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0239 should be different to vim /etc/dconf/db/local.d/locks/session (PS.It’s a graphic, no settings required !!)"
    fi
	
SSHTEST=$(grep '^root:' /etc/passwd | cut -d: -f4)
    if [ $SSHTEST == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0240 /etc/passwd Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0240 /etc/passwd should be set to GID 0'"
    fi
	
cramfs06=`grep -q -E "umask 027" /etc/bashrc && echo 0 || echo 1`
cramfs07=`grep -q -E "umask 027" /etc/profile && echo 0 || echo 1`  
cramfs08=`grep -q -E "umask 027" /etc/profile.d/*.sh && echo 0 || echo 1`
    if [ "$cramfs08" == "0" ] && [ "$cramfs07" == "0" ] && [ "$cramfs06" == "0" ] ; then  
	    echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0241 ok，umask 027"
    else   
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0241 on，umask 027 (PS.TWGCB-01-008-0240 排除 (專案內系統有下載不同帳號創建檔的需求)"
	fi
	
SSHTEST=$(awk 'tolower($1) == "umask"  { print $2 }' /etc/login.defs | paste -sd ";")
    if [ $SSHTEST -le "027" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0242 027 或 以下 "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0242 should be different to 027 或 以下 (PS.TWGCB-01-008-0240 排除 (專案內系統有下載不同帳號創建檔的需求)"
    fi
	
audit01=`awk '$1 == "auth" && $2 == "required" && $3 == "pam_wheel.so" { print $4 }' /etc/pam.d/su`
audit02=`cat /etc/group | grep "wheel:x:10:" | cut -c12-`
    if [ "$audit01" == "use_uid" ] && [ "$audit02" == "alan" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0243 install use_uid & root,chtadmin"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0243 should be different to vim /etc/pam.d/su use_uid & root,XXXXX (可手動設定)"
    fi
	
audit01=`rpm -q firewalld | grep -q '尚未安裝' && echo 0 || echo 1`
audit02=`systemctl is-active firewalld`
    if [ "$audit01" -eq "1" ] && [ "$audit02" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0244 install firewalld & enable firewalld"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0244 should be different to dnf install firewalld"
    fi
	
firewalld01=`systemctl is-active firewalld`
    if [ $firewalld01 == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0245 "$firewalld01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0245 firewalld should be different to firewalld inactive"
    fi
	
iptables01=`systemctl is-enabled iptables`
    if [ "$iptables01" == "masked" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0246 "$iptables01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0246 should be different to iptables Failed to get unit file state for iptables.service: No such file or directory"
    fi
	
firewalld01=`systemctl is-enabled nftables`
    if [ $firewalld01 == "masked" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0247 "$firewalld01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0247 nftables should be different is inactive"
    fi
	
defaultzone01=`systemctl is-enabled nftables`
    if [ $defaultzone01 == "masked" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0248 "$defaultzone01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0248 should be different is-enabled nftables"
    fi
	
firewalld01=`systemctl is-active nftables`
    if [ $firewalld01 == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0249 "$firewalld01
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0249 nftables should be different is inactive (排外，使用Firewalld)"
    fi
	
firewalld01=`systemctl is-enabled firewalld`
    if [ $firewalld01 == "enabled" ]; then
	echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0250 firewalld is enable"
	
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0250 firewalld is stop"
    fi
	
SSHTEST=$(nft list tables | grep -c "table")
    if [ $SSHTEST -ge "1" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0251 nft list tables Check is "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0251 nft list tables to 0 以下'"
    fi
	
SSHTEST01=$(nft list table inet filter 2>/dev/null | grep -c "chain")
SSHTEST02=$(nft list table inet filter 2>/dev/null | grep -c "chain input")
SSHTEST03=$(nft list table inet filter 2>/dev/null | grep -c "chain output")
SSHTEST04=$(nft list table inet filter 2>/dev/null | grep -c "chain forward")
    if [ $SSHTEST01 == "1" ] && [ $SSHTEST02 == "1" ] && [ $SSHTEST03 == "1" ] && [ $SSHTEST04 == "1" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0252 Check is ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0252 Check is error (排外，使用Firewalld)"
    fi
	
SSHTEST01=$(nft list table inet filter 2>/dev/null | awk '/chain input \{/,/\}/ { if (/iif "lo" /) { print } }' | awk '{ print $NF }')
SSHTEST02=$(nft list table inet filter 2>/dev/null | awk '/chain input \{/,/\}/ { if (/ip saddr 127\.0\.0\.0\/8 counter/) { print } }' | awk '{ print $NF }')
SSHTEST03=$(nft list table inet filter 2>/dev/null | awk '/chain input \{/,/\}/ { if (/ip6 saddr ::1 counter/) { print } }' | awk '{ print $NF }')
    if [ "$SSHTEST01" == "accept" ] && [ "$SSHTEST02" == "drop" ] && [ "$SSHTEST03" == "drop" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0253 Check is ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0253 Check is error (排外，使用Firewalld)"
    fi
	
SSHTEST01=$(nft list table inet filter 2>/dev/null | awk '/chain input \{/,/\}/ { if (/type filter hook input priority filter/) { print } }' | awk '{ print $(NF)}')
SSHTEST02=$(nft list table inet filter 2>/dev/null | awk '/chain forward \{/,/\}/ { if (/type filter hook forward priority filter/) { print } }' | awk '{ print $(NF)}')
SSHTEST03=$(nft list table inet filter 2>/dev/null | awk '/chain output \{/,/\}/ { if (/type filter hook output priority filter/) { print } }' | awk '{ print $(NF)}')
    if [ "$SSHTEST01" == "drop;" ] && [ "$SSHTEST02" == "drop;" ] && [ "$SSHTEST03" == "drop;" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0254 Check is ok"
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0254 Check is error (排外，使用Firewalld)"
    fi
	
SSHTEST=$(grep -i "include" /etc/sysconfig/nftables.conf | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0255 include /etc/sysconfig/nftables.conf should be set to rm '#' (排外，使用Firewalld)"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0255 rm '#' is ok"
    fi
	
audit01=`rpm -q openssh-server | grep -q '尚未安裝' && echo 0 || echo 1`
audit02=`systemctl is-active sshd.service`
    if [ "$audit01" -eq "1" ] && [ "$audit02" == "active" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0262 install openssh-server & enable sshd.service"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0262 should be different to dnf install openssh-server & enable sshd.service"
    fi
	
ssh01=`awk '$1=="Protocol" {print $2}' /etc/ssh/sshd_config`
    if [ "$ssh01" == "2" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0263 Protocol 2"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0263  should be different to Protocol 2"
    fi

cramfs01=$(ls -l /etc/ssh/sshd_config | awk '{print $3 ":" $4}')
    if [ "$cramfs01" == "root:root" ] ; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0264 Check /etc/ssh/sshd_config is root:root ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0264 no root:root"
    fi
	
###	TWGCB-01-008-0265 ####
FRUIT=`if [ -f "/etc/ssh/sshd_config" ] ; then   echo "SUCC"; else   echo "FAIL"; fi`
case "$FRUIT" in

   "SUCC") 
   
    cramfs01=$(stat -c %a /etc/ssh/sshd_config)
    if [ $cramfs01 -le "600" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0265 Check /etc/ssh/sshd_config is 600 ok "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0265 no 600"
    fi
    
   ;;
   "FAIL") 
   
   echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0265 no /etc/cron.allow /etc/at.allow"
   
   ;;
esac
###	TWGCB-01-008-0265 ####

SSHTEST01=$(grep -i "AllowUsers" /etc/ssh/sshd_config | grep -v "#")
SSHTEST02=$(awk '$1 ~ /^(AllowUsers|AllowGroups|DenyUsers|DenyGroups)$/ {print $1,$2,$3,$4,$5}' /etc/ssh/sshd_config | paste -sd ";")
    if [ -z "$SSHTEST01" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0266 PasswordAuthentication should be set to 'AllowUsers ...(可設定)'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0266 "$SSHTEST02 
    fi
	
SSHTEST=$(ls -l /etc/ssh/ssh_host_*_key | awk '{print $3 ":" $4}' | paste -sd ";")
    if [ $SSHTEST == "root:ssh_keys;root:ssh_keys;root:ssh_keys" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0267 /etc/ssh/ssh_host_*_key Check is Linux 8: root:root Linux 9: root:ssh_keys "$SSHTEST
    else
	    echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0267 /etc/ssh/ssh_host_*_key should be set to Linux 8: root:root Linux 9: root:ssh_keys"
    fi
	
SSHTEST01=$(ls -l /etc/ssh/ssh_host_*_key | cut -c 1-10 | paste -sd ";")
    if [ "$SSHTEST01" == "-rw-r-----;-rw-r-----;-rw-r-----" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0268 PASS"
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0268 ERROR"
    fi
	
SSHTEST01=`ls -l /etc/ssh/ssh_host_*_key.pub | awk '{print $3 ":" $4}' | paste -sd ";" | grep -q "root:root;root:root;root:root" && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0269 PASS "
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0269 ERROR"
    fi
	
SSHTEST01=`ls -l /etc/ssh/ssh_host_*_key.pub | cut -c 1-10 | paste -sd ";" | grep -q '^[-]'"rw-r--r--;-rw-r--r--;-rw-r--r--" && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0270 PASS "	
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0270 ERROR"
    fi
	
SSHTEST01=`awk '$1=="Ciphers" {print $2}' /etc/ssh/sshd_config | head -n 1 | grep -q "aes128-ctr,aes192-ctr,aes256-ctr" && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0271 PASS "	
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0271 ERROR"
    fi
	
SSHTEST=$(grep -i "LogLevel VERBOSE" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0272 LogLevel should be set to 'VERBOSE'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0272 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "X11Forwarding no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0273 X11Forwarding should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0273 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "MaxAuthTries 4" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0274 MaxAuthTries should be set to '4'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0274 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "IgnoreRhosts yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0275 IgnoreRhosts should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0275 "$SSHTEST
    fi	
	
SSHTEST=$(grep -i "HostbasedAuthentication no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0276 HostbasedAuthentication should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0276 $SSHTEST (可手動設定)"
    fi
	
SSHTEST=$(grep -i "PermitRootLogin no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0277 PermitRootLogin should be set to no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0277 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "PermitEmptyPasswords no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0278 PermitEmptyPasswords should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0278 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "PermitUserEnvironment no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0279 PermitUserEnvironment should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0279 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "ClientAliveInterval 600" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0280 ClientAliveInterval should be set to '600'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0280 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "LoginGraceTime 60" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0281 ClientAliveCountMax should be set to '60'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0281 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "UsePAM yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0282 ClientAliveCountMax should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0282 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "AllowTcpForwarding no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0283 AllowTcpForwarding should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0283 "$SSHTEST
    fi

SSHTEST=$(grep -i "maxstartups 10:30:60" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0284 maxstartups should be set to '10:30:60'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0284 "$SSHTEST
    fi

SSHTEST=$(grep -i "MaxSessions 4" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0285 MaxSessions should be set to '4'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0285 "$SSHTEST
    fi

SSHTEST=$(grep -i "StrictModes yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0286 StrictModes should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0286 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "Compression no" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0287 Compression should be set to 'no'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0287 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "IgnoreUserKnownHosts yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0288 TCPKeepAlive should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0288 "$SSHTEST
    fi
	
SSHTEST=$(grep -i "PrintLastLog yes" /etc/ssh/sshd_config | grep -v "#")
    if [ -z "$SSHTEST" ]; then
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0289 PrintLastLog should be set to 'yes'"
    else
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0289 "$SSHTEST
    fi
	
SSHTEST01=`find / -name shosts.equiv 2>/dev/null && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0290 PASS "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0290 ERROR"
    fi
	
SSHTEST01=`find / -name *.shosts 2>/dev/null && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0291 PASS "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0291 ERROR"
    fi
	
SSHTEST01=`awk '$1 ~ /^CRYPTO_POLICY/ {print $0}' /etc/sysconfig/sshd | paste -sd ";" | grep -q ""  && echo 0 || echo 1`  
    if [ "$SSHTEST01" == "0" ]; then
        echo -e " [\e[1;32mOK\e[0m] TWGCB-01-008-0292 PASS "
		
    else
        echo -e " [\e[1;31mKO\e[0m] TWGCB-01-008-0292 ERROR"
    fi
































######################################################################################################

sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
###################################################################################################### 

           show_menu;
        ;;
        15) clear;
            option_picked "Option 15 Picked";

######################################################################################################
echo
echo "#########################################################################"
echo -e "\e[0;33m 15. Install Apache HTTP Server 2.4 GCB (2024/12/08)/////// \e[0m"
echo "#########################################################################"
echo
echo "Starting in 3 seconds"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1
START=$(date +%s)
echo
echo "#########################################################################"
echo
echo "step 0 GCB"
yum install httpd -y
yum install mod_ssl openssl -y
echo "step 1 GCB"
cp /etc/httpd/conf/httpd.conf  /etc/httpd/conf/httpd.conf.bak
rm -rf /etc/httpd/conf/httpd.conf
cp /root/GCB/httpd.conf /etc/httpd/conf/httpd.conf
echo "step 2 GCB"
cp /etc/httpd/conf.d/welcome.conf /etc/httpd/conf.d/welcome.conf.bak
rm -rf /etc/httpd/conf.d/welcome.conf
cp /root/GCB/welcome.conf /etc/httpd/conf.d/welcome.conf
echo "step 3 GCB"
cp /etc/httpd/conf.d/ssl.conf /etc/httpd/conf.d/ssl.conf.bak
rm -rf /etc/httpd/conf.d/ssl.conf
cp /root/GCB/ssl.conf /etc/httpd/conf.d/ssl.conf
echo "step 4 GCB"
cp /root/GCB/server.key /etc/pki/tls/private/server.key
cp /root/GCB/server.crt /etc/pki/tls/certs/server.crt
chmod 0400 /etc/pki/tls/private/server.key
chown root:root /etc/pki/tls/private/server.key
chmod 0644 /etc/pki/tls/certs/server.crt
chown root:root /etc/pki/tls/certs/server.crt
mkdir /etc/httpd/logs/dump
mkdir /var/www/html/redhat9




echo "請重新啟動httpd Service後，再重新開機...."





######################################################################################################

sleep 1
echo "#########################################################################"
echo
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Script completed in" $DIFF "seconds"
echo
echo "Executed on :"
echo
echo "Check GCB hostname is" $HOSTNAME
date
echo
echo "#########################################################################"
echo
###################################################################################################### 
























            show_menu;
        ;;
        x)exit;
        ;;
        \n)exit;
        ;;
        *)clear;
            option_picked "Pick an option from the menu";
            show_menu;
        ;;
      esac
    fi
done

